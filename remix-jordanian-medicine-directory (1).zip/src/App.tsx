import React, { useState, useMemo, useEffect } from 'react';
import { Header } from './components/Header';
import { SearchAndFilter } from './components/SearchAndFilter';
import { MedicineCard } from './components/MedicineCard';
import { MedicineDetailModal } from './components/MedicineDetailModal';
import { CompareMedicinesModal } from './components/CompareMedicinesModal';
import { CompareFloatingBar } from './components/CompareFloatingBar';
import { MEDICINES_DATA } from './data/medicines';
import { translations } from './data/translations';
import { CategoryKey, Language, Medicine } from './types';
import {
  Pill,
  ShieldCheck,
  Building2,
  PhoneCall,
  SearchX,
  BookOpen,
  Headphones,
  CheckCircle,
  ArrowLeftRight,
  LayoutGrid,
  List,
} from 'lucide-react';
import { stopSpeech } from './utils/speech';

export default function App() {
  const [language, setLanguage] = useState<Language>('ar');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryKey>('all');
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);
  const [currentSpeakingId, setCurrentSpeakingId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [pageSize, setPageSize] = useState<number>(36);

  // Compare Medicines State (supports selecting up to two medicines)
  const [compareList, setCompareList] = useState<Medicine[]>([]);
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);
  const [compareAlert, setCompareAlert] = useState<string | null>(null);

  // Reset pagination when search or category changes
  useEffect(() => {
    setPageSize(36);
  }, [searchQuery, selectedCategory]);

  // Synchronize document direction and language attribute
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  // Handle URL deep-linking on initial load and back/forward browser history
  useEffect(() => {
    const parseUrlMedicine = () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const medId = params.get('med');
        if (medId) {
          const found = MEDICINES_DATA.find((m) => m.id.toLowerCase() === medId.toLowerCase());
          if (found) {
            setSelectedMedicine(found);
            return;
          }
        }
        if (window.location.hash) {
          const hashId = window.location.hash.replace('#med-', '').replace('#', '');
          const found = MEDICINES_DATA.find((m) => m.id.toLowerCase() === hashId.toLowerCase());
          if (found) {
            setSelectedMedicine(found);
            return;
          }
        }
      } catch (err) {
        console.error('URL parse error:', err);
      }
    };

    parseUrlMedicine();

    const handlePopState = () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const medId = params.get('med');
        if (medId) {
          const found = MEDICINES_DATA.find((m) => m.id.toLowerCase() === medId.toLowerCase());
          setSelectedMedicine(found || null);
        } else {
          setSelectedMedicine(null);
        }
      } catch (err) {
        console.error('Popstate error:', err);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleSelectMedicine = (medicine: Medicine) => {
    setSelectedMedicine(medicine);
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('med', medicine.id);
      url.hash = '';
      window.history.pushState({ medId: medicine.id }, '', url.toString());
    } catch {
      // Safe fallback
    }
  };

  const handleCloseMedicine = () => {
    setSelectedMedicine(null);
    try {
      const url = new URL(window.location.href);
      url.searchParams.delete('med');
      url.hash = '';
      window.history.pushState({}, '', url.pathname + (url.search ? url.search : ''));
    } catch {
      // Safe fallback
    }
  };

  const t = translations[language];

  const handleToggleLanguage = () => {
    stopSpeech();
    setCurrentSpeakingId(null);
    setLanguage((prev) => (prev === 'ar' ? 'en' : 'ar'));
  };

  // Compare Handlers
  const handleToggleCompare = (medicine: Medicine) => {
    setCompareList((prev) => {
      const exists = prev.some((m) => m.id === medicine.id);
      if (exists) {
        return prev.filter((m) => m.id !== medicine.id);
      }
      if (prev.length >= 2) {
        // Automatically replace the second medicine so the user doesn't get blocked
        setCompareAlert(t.maxCompareReached);
        setTimeout(() => setCompareAlert(null), 3000);
        return [prev[0], medicine];
      }
      return [...prev, medicine];
    });
  };

  const handleRemoveFromCompare = (medicineId: string) => {
    setCompareList((prev) => prev.filter((m) => m.id !== medicineId));
  };

  const handleAddMedicineToCompare = (medicine: Medicine) => {
    setCompareList((prev) => {
      if (prev.some((m) => m.id === medicine.id)) return prev;
      if (prev.length >= 2) return [prev[0], medicine];
      return [...prev, medicine];
    });
  };

  const handleClearAllCompare = () => {
    setCompareList([]);
  };

  const handleSwapCompareMedicines = () => {
    setCompareList((prev) => (prev.length === 2 ? [prev[1], prev[0]] : prev));
  };

  const handleOpenCompareModal = () => {
    setIsCompareModalOpen(true);
  };

  // Quick preset comparisons
  const handleQuickCompare = (id1: string, id2: string) => {
    const m1 = MEDICINES_DATA.find((m) => m.id === id1);
    const m2 = MEDICINES_DATA.find((m) => m.id === id2);
    if (m1 && m2) {
      setCompareList([m1, m2]);
      setIsCompareModalOpen(true);
    }
  };

  // Compute category counts
  const categoryCounts = useMemo(() => {
    const counts: Record<CategoryKey, number> = {
      all: MEDICINES_DATA.length,
      painkillers: 0,
      antibiotics: 0,
      vitamins: 0,
      chronic: 0,
      cold_flu: 0,
      digestive: 0,
    };

    MEDICINES_DATA.forEach((med) => {
      if (counts[med.category] !== undefined) {
        counts[med.category] += 1;
      }
    });

    return counts;
  }, []);

  // Filter medicines based on category and search query
  const filteredMedicines = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    return MEDICINES_DATA.filter((med) => {
      // Category match
      if (selectedCategory !== 'all' && med.category !== selectedCategory) {
        return false;
      }

      // Query match
      if (!query) return true;

      const nameEn = med.name.en.toLowerCase();
      const nameAr = med.name.ar.toLowerCase();
      const genericEn = med.genericName.en.toLowerCase();
      const genericAr = med.genericName.ar.toLowerCase();
      const manufacturerEn = med.manufacturer.en.toLowerCase();
      const manufacturerAr = med.manufacturer.ar.toLowerCase();

      const ingredientsMatch =
        med.activeIngredients.en.some((i) => i.toLowerCase().includes(query)) ||
        med.activeIngredients.ar.some((i) => i.toLowerCase().includes(query));

      const indicationsMatch =
        med.benefitsAndIndications.en.some((i) => i.toLowerCase().includes(query)) ||
        med.benefitsAndIndications.ar.some((i) => i.toLowerCase().includes(query));

      return (
        nameEn.includes(query) ||
        nameAr.includes(query) ||
        genericEn.includes(query) ||
        genericAr.includes(query) ||
        manufacturerEn.includes(query) ||
        manufacturerAr.includes(query) ||
        ingredientsMatch ||
        indicationsMatch
      );
    });
  }, [searchQuery, selectedCategory]);

  const paginatedMedicines = useMemo(() => {
    return filteredMedicines.slice(0, pageSize);
  }, [filteredMedicines, pageSize]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50/80 selection:bg-teal-500 selection:text-white pb-24 sm:pb-20">
      {/* Top Navigation & Header */}
      <Header
        language={language}
        onToggleLanguage={handleToggleLanguage}
        compareCount={compareList.length}
        onOpenCompare={() => {
          if (compareList.length === 0) {
            // Pre-fill with two popular Jordanian medications to give instant value
            const revanin = MEDICINES_DATA.find((m) => m.id === 'revanin') || MEDICINES_DATA[0];
            const profinal = MEDICINES_DATA.find((m) => m.id === 'profinal') || MEDICINES_DATA[1];
            setCompareList([revanin, profinal]);
          }
          setIsCompareModalOpen(true);
        }}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
        {/* Notice Alert for Compare if triggered */}
        {compareAlert && (
          <div className="rounded-xl bg-teal-800 text-teal-50 px-4 py-2 text-xs flex items-center justify-between animate-in fade-in">
            <span>{compareAlert}</span>
            <button
              type="button"
              onClick={() => setCompareAlert(null)}
              className="text-teal-300 hover:text-white"
            >
              ✕
            </button>
          </div>
        )}

        {/* Subtle Welcome & Info Section */}
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-teal-900 via-teal-800 to-cyan-900 text-white p-6 sm:p-9 shadow-lg shadow-teal-950/15">
          {/* Decorative glowing circles */}
          <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 rounded-full bg-teal-400/10 blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 -mb-8 -ml-8 w-64 h-64 rounded-full bg-cyan-400/10 blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-3xl space-y-3 sm:space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-white/10 backdrop-blur-md text-teal-200 border border-white/15 flex-wrap">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
              <span>
                {language === 'ar'
                  ? 'دليل الأدوية الموثق للمملكة الأردنية الهاشمية'
                  : 'Verified Pharmaceutical Reference for Jordan'}
              </span>
              <span className="text-white/40">•</span>
              <span className="text-amber-300 font-semibold">made by osamaabualia</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
              {language === 'ar'
                ? 'ابحث، استمع وتعرف على الأدوية الأردنية بوضوح'
                : 'Search, Listen & Understand Jordanian Medications with Confidence'}
            </h2>

            <p className="text-sm sm:text-base text-teal-100/90 leading-relaxed max-w-2xl font-normal">
              {language === 'ar'
                ? 'دليلك الصيدلاني المتكامل للتعرف على التركيبات العلمية، دواعي الاستعمال، الأعراض الجانبية، والجرعات المعتمدة، مع ميزة النطق الصوتي ومقارنة الأدوية جنباً إلى جنب.'
                : 'Your comprehensive pharmaceutical guide to active ingredients, therapeutic indications, side effects, and approved dosage guidance with instant voice pronunciation and side-by-side drug comparison.'}
            </p>

            {/* Quick Actions & Feature Badges */}
            <div className="pt-2 flex flex-wrap items-center gap-2.5 sm:gap-4 text-xs font-medium text-teal-200">
              <span className="flex items-center gap-1.5 bg-black/20 px-2.5 py-1 rounded-lg border border-white/10">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>{language === 'ar' ? 'أدوية محلية وعالمية شهيرة' : 'Local & Global Top Brands'}</span>
              </span>
              <span className="flex items-center gap-1.5 bg-black/20 px-2.5 py-1 rounded-lg border border-white/10">
                <Headphones className="w-3.5 h-3.5 text-cyan-300" />
                <span>{language === 'ar' ? 'نطق صوتي إنجليزي بشري ودقيق' : 'Clear English Voice Pronunciation'}</span>
              </span>
              <button
                type="button"
                onClick={() => handleQuickCompare('revanin', 'profinal')}
                className="flex items-center gap-1.5 bg-teal-500/25 hover:bg-teal-500/40 text-white px-2.5 py-1 rounded-lg border border-teal-400/40 cursor-pointer transition-colors"
              >
                <ArrowLeftRight className="w-3.5 h-3.5 text-teal-300" />
                <span>
                  {language === 'ar'
                    ? 'تجربة مقارنة: ريفانين ضد بروفينال'
                    : 'Compare: Revanin vs Profinal'}
                </span>
              </button>
            </div>
          </div>
        </section>

        {/* Search & Category Filter Section */}
        <section className="space-y-4">
          <SearchAndFilter
            language={language}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            categoryCounts={categoryCounts}
            totalResults={filteredMedicines.length}
          />
        </section>

        {/* Medicines List / Grid Section */}
        <section className="space-y-4">
          {filteredMedicines.length > 0 && (
            <div className="flex items-center justify-between gap-3 px-1">
              <div className="text-xs sm:text-sm text-slate-600 font-medium">
                {language === 'ar' ? (
                  <span>
                    يعرض <strong className="text-teal-700 font-bold">{Math.min(paginatedMedicines.length, filteredMedicines.length)}</strong> من أصل <strong className="text-slate-900 font-bold">{filteredMedicines.length.toLocaleString()}</strong> دواء
                  </span>
                ) : (
                  <span>
                    Showing <strong className="text-teal-700 font-bold">{Math.min(paginatedMedicines.length, filteredMedicines.length)}</strong> of <strong className="text-slate-900 font-bold">{filteredMedicines.length.toLocaleString()}</strong> medications
                  </span>
                )}
              </div>

              {/* View Switcher: Grid vs Compact List */}
              <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200 shadow-2xs">
                <button
                  type="button"
                  onClick={() => setViewMode('grid')}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    viewMode === 'grid'
                      ? 'bg-white text-teal-800 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                  title={language === 'ar' ? 'عرض الكروت' : 'Grid View'}
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{language === 'ar' ? 'شبكة كروت' : 'Grid'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('list')}
                  className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    viewMode === 'list'
                      ? 'bg-white text-teal-800 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                  title={language === 'ar' ? 'قائمة مدمجة وسريعة للهاتف' : 'Compact Mobile List'}
                >
                  <List className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{language === 'ar' ? 'قائمة سريعة للهاتف' : 'List'}</span>
                </button>
              </div>
            </div>
          )}

          {filteredMedicines.length > 0 ? (
            <>
              {viewMode === 'grid' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                  {paginatedMedicines.map((medicine) => (
                    <MedicineCard
                      key={medicine.id}
                      medicine={medicine}
                      language={language}
                      viewMode="grid"
                      onSelect={handleSelectMedicine}
                      currentSpeakingId={currentSpeakingId}
                      setCurrentSpeakingId={setCurrentSpeakingId}
                      isCompared={compareList.some((m) => m.id === medicine.id)}
                      onToggleCompare={handleToggleCompare}
                    />
                  ))}
                </div>
              ) : (
                <div className="flex flex-col space-y-2.5">
                  {paginatedMedicines.map((medicine) => (
                    <MedicineCard
                      key={medicine.id}
                      medicine={medicine}
                      language={language}
                      viewMode="list"
                      onSelect={handleSelectMedicine}
                      currentSpeakingId={currentSpeakingId}
                      setCurrentSpeakingId={setCurrentSpeakingId}
                      isCompared={compareList.some((m) => m.id === medicine.id)}
                      onToggleCompare={handleToggleCompare}
                    />
                  ))}
                </div>
              )}

              {/* Pagination Load More Controls */}
              {pageSize < filteredMedicines.length && (
                <div className="pt-6 pb-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => setPageSize((prev) => prev + 48)}
                    className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm shadow-md shadow-teal-700/15 transition-all cursor-pointer active:scale-95"
                  >
                    {language === 'ar'
                      ? `عرض المزيد من الأدوية (+48 دواء) • متبقي ${(filteredMedicines.length - pageSize).toLocaleString()}`
                      : `Load More Medications (+48) • ${(filteredMedicines.length - pageSize).toLocaleString()} remaining`}
                  </button>

                  <button
                    type="button"
                    onClick={() => setPageSize(filteredMedicines.length)}
                    className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs border border-slate-200 transition-colors cursor-pointer"
                  >
                    {language === 'ar' ? 'عرض الكل دفعة واحدة' : 'Show All at Once'}
                  </button>
                </div>
              )}
            </>
          ) : (
            <div className="rounded-3xl bg-white p-12 text-center border border-slate-200 max-w-lg mx-auto space-y-4 shadow-sm">
              <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mx-auto">
                <SearchX className="w-7 h-7" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">{t.noResultsTitle}</h3>
              <p className="text-sm text-slate-500 leading-relaxed">{t.noResultsDesc}</p>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                }}
                className="px-4 py-2 rounded-xl text-sm font-semibold bg-teal-600 hover:bg-teal-700 text-white transition-colors"
              >
                {t.resetFilters}
              </button>
            </div>
          )}
        </section>

        {/* Information Grid: Jordanian Medical & Pharmacy Highlights */}
        <section className="rounded-2xl bg-white p-6 sm:p-7 border border-slate-200 shadow-2xs space-y-4">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-teal-600" />
            <h3 className="text-base sm:text-lg font-bold text-slate-900">
              {language === 'ar'
                ? 'عن قطاع الصناعات الدوائية في الأردن ومقارنة الأدوية'
                : 'About the Jordanian Pharmaceutical Sector & Drug Comparison'}
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs sm:text-sm text-slate-600">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/60 space-y-1.5">
              <strong className="text-slate-900 block font-semibold">
                {language === 'ar' ? 'مقارنة التكافؤ الحيوي' : 'Bioequivalence & Generic Substitution'}
              </strong>
              <p className="leading-relaxed text-slate-600">
                {language === 'ar'
                  ? 'توفر الصناعة الدوائية الأردنية بدائل جنيسة عالية الفعالية تكافئ تماماً الأدوية العالمية المبتكرة وبأسعار مناسبة للمواطن.'
                  : 'Jordanian pharmaceutical producers supply bioequivalent generic therapeutics that match innovator drugs in efficacy and safety at accessible prices.'}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/60 space-y-1.5">
              <strong className="text-slate-900 block font-semibold">
                {language === 'ar' ? 'تجنب تكرار المواد الفعالة' : 'Avoiding Duplicate Active Ingredients'}
              </strong>
              <p className="leading-relaxed text-slate-600">
                {language === 'ar'
                  ? 'استخدم ميزة مقارنة الأدوية للتأكد من عدم تناول دوائين تجاريين مختلفين يحملان نفس المادة الفعالة مثل الباراسيتامول لتفادي الجرعات الزائدة.'
                  : 'Use the comparison tool to verify that you are not accidentally taking two brand-name products containing the same active ingredient.'}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/60 space-y-1.5">
              <strong className="text-slate-900 block font-semibold">
                {language === 'ar' ? 'الاستخدام الرشيد للأدوية' : 'Rational Use of Medicines'}
              </strong>
              <p className="leading-relaxed text-slate-600">
                {language === 'ar'
                  ? 'تجنب تناول المضادات الحيوية دون وصفة طبية، واحرص دائماً على استشارة الصيدلاني عند الجمع بين أكثر من مسكن لتفادي إجهاد الكبد أو المعدة.'
                  : 'Avoid antibiotic self-medication and always consult your licensed community pharmacist before combining multiple painkillers.'}
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2 flex-wrap">
            <Pill className="w-4 h-4 text-teal-600" />
            <span className="font-semibold text-slate-800">
              {language === 'ar' ? 'دليل الأدوية الأردني' : 'Jordanian Medicine Directory'}
            </span>
            <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
              made by osamaabualia
            </span>
            <span>•</span>
            <span>{language === 'ar' ? 'المرجع الطبي التثقيفي' : 'Medical Educational Directory'}</span>
          </div>

          <div className="flex items-center gap-4 text-slate-500">
            <span>{t.emergencyHotline}: <strong className="text-slate-800">{t.emergencyNumber}</strong></span>
          </div>
        </div>
      </footer>

      {/* Detail Modal View */}
      <MedicineDetailModal
        medicine={selectedMedicine}
        language={language}
        onClose={handleCloseMedicine}
        currentSpeakingId={currentSpeakingId}
        setCurrentSpeakingId={setCurrentSpeakingId}
        isCompared={selectedMedicine ? compareList.some((m) => m.id === selectedMedicine.id) : false}
        onToggleCompare={handleToggleCompare}
        onOpenCompareView={() => setIsCompareModalOpen(true)}
      />

      {/* Floating Bottom Comparison Action Bar */}
      <CompareFloatingBar
        compareList={compareList}
        language={language}
        onOpenCompare={handleOpenCompareModal}
        onRemoveFromCompare={handleRemoveFromCompare}
        onClearAll={handleClearAllCompare}
      />

      {/* Side-by-Side Compare Medicines Modal */}
      <CompareMedicinesModal
        isOpen={isCompareModalOpen}
        selectedMedicines={compareList}
        language={language}
        onClose={() => setIsCompareModalOpen(false)}
        onRemoveMedicine={handleRemoveFromCompare}
        onAddMedicine={handleAddMedicineToCompare}
        onSwapMedicines={handleSwapCompareMedicines}
        currentSpeakingId={currentSpeakingId}
        setCurrentSpeakingId={setCurrentSpeakingId}
      />
    </div>
  );
}
