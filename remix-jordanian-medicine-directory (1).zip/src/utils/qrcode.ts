import QRCode from 'qrcode';

/**
 * Returns the canonical URL for a given medicine in the directory.
 */
export function getMedicineUrl(medicineId: string): string {
  if (typeof window === 'undefined') {
    return `https://ais-pre-zcyj3mdgfxqwxmkiz3lef2-527561681138.europe-west2.run.app/?med=${medicineId}`;
  }

  const url = new URL(window.location.href);
  // Ensure the query parameter ?med=<id> is set
  url.searchParams.set('med', medicineId);
  // Remove hash if any
  url.hash = '';
  return url.toString();
}

/**
 * Generates a high-resolution PNG Data URL for a QR Code.
 */
export async function generateQRCodeDataUrl(
  text: string,
  options?: {
    width?: number;
    margin?: number;
    darkColor?: string;
    lightColor?: string;
  }
): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      errorCorrectionLevel: 'M',
      margin: options?.margin ?? 1,
      width: options?.width ?? 320,
      color: {
        dark: options?.darkColor ?? '#0f172a',
        light: options?.lightColor ?? '#ffffff',
      },
    });
  } catch (err) {
    console.error('Failed to generate QR Code Data URL:', err);
    return '';
  }
}

/**
 * Generates an SVG string representation of a QR Code.
 */
export async function generateQRCodeSvg(
  text: string,
  options?: {
    margin?: number;
    darkColor?: string;
    lightColor?: string;
  }
): Promise<string> {
  try {
    return await QRCode.toString(text, {
      type: 'svg',
      errorCorrectionLevel: 'M',
      margin: options?.margin ?? 1,
      color: {
        dark: options?.darkColor ?? '#0f172a',
        light: options?.lightColor ?? '#ffffff',
      },
    });
  } catch (err) {
    console.error('Failed to generate QR Code SVG:', err);
    return '';
  }
}
