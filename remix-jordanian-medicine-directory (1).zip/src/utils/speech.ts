import { Language } from '../types';

let currentUtterance: SpeechSynthesisUtterance | null = null;

export interface SpeakOptions {
  text: string;
  lang: Language | 'en-US';
  rate?: number;
  pitch?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (error: unknown) => void;
}

export function stopSpeech(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
      currentUtterance = null;
    } catch {
      // Ignore cancel errors
    }
  }
}

export function speakMedicineName({
  text,
  lang,
  rate,
  pitch = 1.0,
  onStart,
  onEnd,
  onError,
}: SpeakOptions): boolean {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    onError?.(new Error('Speech synthesis is not supported in this browser environment.'));
    return false;
  }

  try {
    // Cancel any ongoing speech first
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    currentUtterance = utterance;

    // Pick best matching voice
    const voices = window.speechSynthesis.getVoices?.() || [];
    const isEn = lang === 'en' || lang === 'en-US';

    const preferredVoice = voices.find((v) => {
      const vLang = v.lang.toLowerCase();
      if (!isEn) {
        return (
          vLang.startsWith('ar-jo') ||
          vLang.startsWith('ar-sa') ||
          vLang.startsWith('ar-ae') ||
          vLang.startsWith('ar')
        );
      }
      // Prioritize natural English medical voices
      return (
        vLang.startsWith('en-us') ||
        vLang.startsWith('en-gb') ||
        vLang.startsWith('en-ca') ||
        vLang.startsWith('en')
      );
    });

    if (preferredVoice) {
      utterance.voice = preferredVoice;
      utterance.lang = preferredVoice.lang;
    } else {
      utterance.lang = isEn ? 'en-US' : 'ar-SA';
    }

    // Default rate: 0.88 for English phonetic clarity, 0.9 for Arabic
    utterance.rate = rate ?? (isEn ? 0.88 : 0.9);
    utterance.pitch = pitch;

    utterance.onstart = () => {
      onStart?.();
    };

    utterance.onend = () => {
      currentUtterance = null;
      onEnd?.();
    };

    utterance.onerror = (e) => {
      if (e.error !== 'interrupted' && e.error !== 'canceled') {
        onError?.(e);
      }
      currentUtterance = null;
      onEnd?.();
    };

    window.speechSynthesis.speak(utterance);
    return true;
  } catch (err) {
    onError?.(err);
    currentUtterance = null;
    return false;
  }
}

export function isSpeechSynthesisSupported(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}
