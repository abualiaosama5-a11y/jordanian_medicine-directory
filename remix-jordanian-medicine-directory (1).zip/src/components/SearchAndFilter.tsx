import React from 'react';
import { Search, X, Activity, ShieldAlert, Zap, Layers, HeartPulse, ThermometerSnowflake, Flame } from 'lucide-react';
import { CategoryKey, Language } from '../types';
import { translations } from '../data/translations';

interface SearchAndFilterProps {
  language: Language;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategory: CategoryKey;
  onSelectCategory: (category: CategoryKey) => void;
  categoryCounts: Record<CategoryKey, number>;
  totalResults: number;
}

export const SearchAndFilter: React.FC<SearchAndFilterProps> = ({
  language,
  searchQuery,
  onSearchChange,
  selectedCategory,
  onSelectCategory,
  categoryCounts,
  totalResults,
}) => {
  const t = translations[language];

  const categories: Array<{
    key: CategoryKey;
    label: string;
    icon: React.ReactNode;
    color: string;
    activeColor: string;
  }> = [
    {
      key: 'all',
      label: t.allCategories,
      icon: <Layers className="w-4 h-4" />,
      color: 'hover:bg-slate-100 text-slate-700 border-slate-200',
      activeColor: 'bg-slate-900 text-white border-slate-900 shadow-sm',
    },
    {
      key: 'painkillers',
      label: t.painkillers,
      icon: <Activity className="w-4 h-4" />,
      color: 'hover:bg-teal-50 text-teal-800 border-teal-200',
      activeColor: 'bg-teal-700 text-white border-teal-700 shadow-sm shadow-teal-700/20',
    },
    {
      key: 'antibiotics',
      label: t.antibiotics,
      icon: <ShieldAlert className="w-4 h-4" />,
      color: 'hover:bg-cyan-50 text-cyan-800 border-cyan-200',
      activeColor: 'bg-cyan-700 text-white border-cyan-700 shadow-sm shadow-cyan-700/20',
    },
    {
      key: 'cold_flu',
      label: t.cold_flu,
      icon: <ThermometerSnowflake className="w-4 h-4" />,
      color: 'hover:bg-emerald-50 text-emerald-800 border-emerald-200',
      activeColor: 'bg-emerald-700 text-white border-emerald-700 shadow-sm shadow-emerald-700/20',
    },
    {
      key: 'digestive',
      label: t.digestive,
      icon: <Flame className="w-4 h-4" />,
      color: 'hover:bg-purple-50 text-purple-800 border-purple-200',
      activeColor: 'bg-purple-700 text-white border-purple-700 shadow-sm shadow-purple-700/20',
    },
    {
      key: 'chronic',
      label: t.chronic,
      icon: <HeartPulse className="w-4 h-4" />,
      color: 'hover:bg-indigo-50 text-indigo-800 border-indigo-200',
      activeColor: 'bg-indigo-700 text-white border-indigo-700 shadow-sm shadow-indigo-700/20',
    },
    {
      key: 'vitamins',
      label: t.vitamins,
      icon: <Zap className="w-4 h-4" />,
      color: 'hover:bg-amber-50 text-amber-800 border-amber-200',
      activeColor: 'bg-amber-600 text-white border-amber-600 shadow-sm shadow-amber-600/20',
    },
  ];

  return (
    <div className="w-full space-y-4">
      {/* Prominent Search Bar */}
      <div className="relative w-full max-w-4xl mx-auto">
        <div className="relative flex items-center">
          <div className="absolute inset-y-0 start-0 flex items-center ps-4 pointer-events-none text-teal-600">
            <Search className="w-5 h-5" />
          </div>

          <input
            id="medicine-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full ps-11 pe-12 py-3.5 sm:py-4 text-base sm:text-lg bg-white/95 backdrop-blur-md rounded-2xl border border-slate-300 focus:border-teal-500 focus:ring-4 focus:ring-teal-500/15 transition-all text-slate-800 placeholder-slate-400 shadow-sm"
          />

          {searchQuery && (
            <button
              id="clear-search-button"
              type="button"
              onClick={() => onSearchChange('')}
              className="absolute inset-y-0 end-0 flex items-center pe-3.5 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
              title={t.clearSearch}
              aria-label={t.clearSearch}
            >
              <div className="p-1.5 rounded-full hover:bg-slate-100">
                <X className="w-4 h-4" />
              </div>
            </button>
          )}
        </div>
      </div>

      {/* Category Pills and Results Status */}
      <div className="w-full max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3 pt-2">
        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 w-full md:w-auto" role="tablist">
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat.key;
            const count = categoryCounts[cat.key] || 0;

            return (
              <button
                key={cat.key}
                id={`filter-category-${cat.key}`}
                type="button"
                role="tab"
                aria-selected={isSelected}
                onClick={() => onSelectCategory(cat.key)}
                className={`inline-flex items-center gap-1.5 sm:gap-2 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs sm:text-sm font-semibold border transition-all duration-200 cursor-pointer ${
                  isSelected ? cat.activeColor : `bg-white ${cat.color}`
                }`}
              >
                <span>{cat.icon}</span>
                <span className="whitespace-nowrap">{cat.label}</span>
                <span
                  className={`text-[11px] px-1.5 py-0.5 rounded-full font-mono font-bold ${
                    isSelected ? 'bg-white/25 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Results Counter badge */}
        <div className="text-xs sm:text-sm font-medium text-slate-500 whitespace-nowrap">
          {t.resultsCount(totalResults)}
        </div>
      </div>
    </div>
  );
};
