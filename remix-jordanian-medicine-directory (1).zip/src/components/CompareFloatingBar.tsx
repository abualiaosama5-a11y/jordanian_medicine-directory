import React from 'react';
import { ArrowLeftRight, X } from 'lucide-react';
import { Medicine, Language } from '../types';
import { translations } from '../data/translations';

interface CompareFloatingBarProps {
  compareList: Medicine[];
  language: Language;
  onOpenCompare: () => void;
  onRemoveFromCompare: (medicineId: string) => void;
  onClearAll: () => void;
}

export const CompareFloatingBar: React.FC<CompareFloatingBarProps> = ({
  compareList,
  language,
  onOpenCompare,
  onRemoveFromCompare,
  onClearAll,
}) => {
  if (compareList.length === 0) return null;

  const t = translations[language];

  return (
    <aside
      id="compare-floating-bar"
      aria-label={t.compareMedicines}
      className="fixed bottom-4 inset-x-4 sm:inset-x-auto sm:end-6 sm:bottom-6 z-40 max-w-xl mx-auto rounded-2xl bg-slate-900/90 backdrop-blur-xl border border-teal-500/30 text-white shadow-2xl p-3 sm:p-4 transition-all duration-300 animate-in slide-in-from-bottom-5"
    >
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Left / Start: Selected items chips */}
        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-300 flex items-center justify-center shrink-0 border border-teal-500/30">
            <ArrowLeftRight className="w-4 h-4" />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto py-0.5">
            {compareList.map((med) => (
              <div
                key={med.id}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white/10 border border-white/15 text-xs font-medium"
              >
                <img
                  src={med.image}
                  alt={med.name[language]}
                  referrerPolicy="no-referrer"
                  className="w-5 h-5 rounded-full object-cover shrink-0"
                />
                <span className="truncate max-w-[90px] sm:max-w-[110px]">
                  {med.name[language]}
                </span>
                <button
                  type="button"
                  onClick={() => onRemoveFromCompare(med.id)}
                  className="p-0.5 text-slate-400 hover:text-rose-300 transition-colors"
                  aria-label={t.removeFromCompare}
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}

            {compareList.length === 1 && (
              <div className="px-2.5 py-1 rounded-xl border border-dashed border-white/30 text-[11px] text-teal-200/80 italic whitespace-nowrap">
                + {language === 'ar' ? 'اختر دواءً ثانياً' : 'Add 1 more to compare'}
              </div>
            )}
          </div>
        </div>

        {/* Right / End: Actions */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <button
            type="button"
            onClick={onClearAll}
            className="text-xs text-slate-400 hover:text-white px-2 py-1 transition-colors cursor-pointer"
          >
            {t.clearAllCompare}
          </button>

          <button
            id="open-compare-modal-btn"
            type="button"
            onClick={onOpenCompare}
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-400 hover:to-cyan-400 text-slate-950 shadow-md shadow-teal-500/20 transition-all cursor-pointer active:scale-95"
          >
            <ArrowLeftRight className="w-4 h-4" />
            <span>{t.compareNow}</span>
            <span className="bg-slate-950/20 px-1.5 py-0.5 rounded-full text-[11px] font-mono">
              {compareList.length}/2
            </span>
          </button>
        </div>
      </div>
    </aside>
  );
};
