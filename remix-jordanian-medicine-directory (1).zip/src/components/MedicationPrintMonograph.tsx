import React from 'react';
import { Medicine, Language } from '../types';
import { translations } from '../data/translations';
import { ShieldCheck, AlertTriangle, Printer, PhoneCall, CheckCircle2 } from 'lucide-react';
import { MedicineQRCode } from './MedicineQRCode';

interface MedicationPrintMonographProps {
  medicine: Medicine;
  lang: Language;
  onClose?: () => void;
}

export const MedicationPrintMonograph: React.FC<MedicationPrintMonographProps> = ({
  medicine,
  lang,
  onClose,
}) => {
  const t = translations[lang];
  const isAr = lang === 'ar';
  const currentDate = new Date().toLocaleDateString(isAr ? 'ar-JO' : 'en-GB', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white text-slate-900 font-sans print:p-0 print:m-0">
      {/* Interactive Toolbar for Preview - Hidden in print */}
      <div className="no-print bg-slate-900 text-white p-4 rounded-t-2xl flex flex-wrap items-center justify-between gap-3 shadow-md border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold">
            A4
          </div>
          <div>
            <h3 className="font-semibold text-sm text-slate-100">{t.printPreviewTitle}</h3>
            <p className="text-xs text-slate-400">{t.printA4Help}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            id="modal-print-action-btn"
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-sm rounded-xl transition shadow-sm active:scale-95 cursor-pointer"
          >
            <Printer size={16} />
            <span>{t.printNow}</span>
          </button>
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-2 text-slate-300 hover:text-white text-sm rounded-xl hover:bg-slate-800 transition"
            >
              {t.close}
            </button>
          )}
        </div>
      </div>

      {/* Printable Clinical Monograph Content */}
      <div
        id="printable-monograph-section"
        className="p-6 md:p-8 bg-white border border-slate-200 print:border-none print:p-0"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        {/* Official Header */}
        <header className="border-b-2 border-teal-800 pb-4 mb-5 flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-teal-800 mb-1">
              <ShieldCheck size={16} className="text-teal-700" />
              <span>{isAr ? 'المملكة الأردنية الهاشمية • المؤسسة العامة للغذاء والدواء (JFDA)' : 'Hashemite Kingdom of Jordan • JFDA Standards'}</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 leading-tight">
              {medicine.name[lang]}
            </h1>
            <p className="text-sm font-semibold text-slate-600 mt-0.5">
              {isAr ? 'الاسم العلمي والتركيبة المعتمدة: ' : 'Generic International Name: '}
              <span className="text-teal-900 font-bold">{medicine.genericName[lang]}</span>
            </p>
            {/* Pronunciation block on print */}
            <div className="inline-flex items-center gap-2 mt-2 px-2.5 py-1 bg-teal-50 border border-teal-200 rounded text-xs text-teal-900 font-mono">
              <span className="font-bold">🗣️ {medicine.englishPhonetic}</span>
              {medicine.englishPronunciationGuide && (
                <span className="text-slate-600 font-sans border-s border-teal-300 ps-2">
                  {medicine.englishPronunciationGuide[lang]}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="text-end">
              <span
                className={`inline-block px-3 py-1 text-xs font-black uppercase rounded border mb-1.5 ${
                  medicine.prescriptionRequired
                    ? 'bg-amber-100 text-amber-900 border-amber-300'
                    : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                }`}
              >
                {medicine.prescriptionRequired ? 'Rx - يتطلب وصفة طبية' : 'OTC - متاح دون وصفة'}
              </span>
              <div className="text-[11px] text-slate-500">
                <div>{t.dateDispensed}: <span className="font-semibold text-slate-700">{currentDate}</span></div>
                {medicine.jfdaRegistrationNumber && (
                  <div>{t.jfdaRefNumber}: <span className="font-mono text-slate-700">{medicine.jfdaRegistrationNumber}</span></div>
                )}
              </div>
            </div>

            {/* Scannable QR Code for Mobile Access in Printed Monograph */}
            <div className="print:block">
              <MedicineQRCode
                medicine={medicine}
                lang={lang}
                variant="print"
                size={82}
              />
            </div>
          </div>
        </header>

        {/* Quick Specs Grid */}
        <section className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs mb-5">
          <div>
            <span className="text-slate-500 block font-medium">{t.dosageForm}</span>
            <span className="font-bold text-slate-800">{medicine.dosageForm[lang]} ({medicine.strength})</span>
          </div>
          <div>
            <span className="text-slate-500 block font-medium">{t.manufacturer}</span>
            <span className="font-bold text-slate-800">{medicine.manufacturer[lang]}</span>
          </div>
          <div>
            <span className="text-slate-500 block font-medium">{t.origin}</span>
            <span className="font-bold text-slate-800">{medicine.origin[lang]}</span>
          </div>
          <div>
            <span className="text-slate-500 block font-medium">{t.approxPrice}</span>
            <span className="font-bold text-teal-800">{medicine.approxPriceJOD || 'N/A'}</span>
          </div>
        </section>

        {/* Max Safe Daily Allowance Banner */}
        {medicine.maxSafeDailyDose && (
          <section className="bg-amber-50 border-s-4 border-amber-600 p-3 rounded-e-md mb-5 flex items-start gap-3">
            <AlertTriangle className="text-amber-700 shrink-0 mt-0.5" size={18} />
            <div>
              <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wide">
                {t.maxDailyLimit}
              </h4>
              <p className="text-xs font-semibold text-amber-950 mt-0.5">
                {medicine.maxSafeDailyDose[lang]}
              </p>
            </div>
          </section>
        )}

        {/* 2-Column Monograph Body */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
          {/* Active Ingredients & Composition */}
          <div className="border border-slate-200 rounded-lg p-3.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-teal-900 border-b border-slate-200 pb-1.5 mb-2 flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-teal-600" />
              <span>{t.scientificComposition}</span>
            </h3>
            <ul className="text-xs space-y-1.5 text-slate-700 list-disc list-inside">
              {medicine.activeIngredients[lang].map((item, idx) => (
                <li key={idx} className="leading-relaxed">
                  <span className="font-medium text-slate-900">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Clinical Indications */}
          <div className="border border-slate-200 rounded-lg p-3.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-teal-900 border-b border-slate-200 pb-1.5 mb-2 flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-teal-600" />
              <span>{t.benefitsAndIndications}</span>
            </h3>
            <ul className="text-xs space-y-1 text-slate-700 list-disc list-inside">
              {medicine.benefitsAndIndications[lang].slice(0, 4).map((item, idx) => (
                <li key={idx} className="leading-relaxed">{item}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Directions for Dosage */}
        <section className="border border-slate-200 rounded-lg p-3.5 mb-5 bg-teal-50/40">
          <h3 className="text-xs font-bold uppercase tracking-wider text-teal-950 mb-1">
            {t.dosageAndUsage}
          </h3>
          <p className="text-xs text-slate-800 leading-relaxed font-medium">
            {medicine.dosageAndUsage[lang]}
          </p>
        </section>

        {/* Warnings & Adverse Effects */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
          <div className="border border-rose-200 bg-rose-50/30 rounded-lg p-3.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-rose-900 border-b border-rose-200 pb-1 mb-2">
              {t.warningsAndPrecautions}
            </h3>
            <ul className="text-xs space-y-1 text-slate-700 list-disc list-inside">
              {medicine.warningsAndPrecautions[lang].map((warn, idx) => (
                <li key={idx} className="leading-relaxed">{warn}</li>
              ))}
            </ul>
          </div>

          <div className="border border-slate-200 rounded-lg p-3.5">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 border-b border-slate-200 pb-1 mb-2">
              {t.sideEffectsAndComplications}
            </h3>
            <ul className="text-xs space-y-1 text-slate-700 list-disc list-inside">
              {medicine.sideEffectsAndComplications[lang].slice(0, 3).map((effect, idx) => (
                <li key={idx} className="leading-relaxed">{effect}</li>
              ))}
            </ul>
          </div>
        </div>

        {/* Pharmacist Dispensing Box for Prescription Slip */}
        <section className="border-2 border-dashed border-slate-300 rounded-lg p-4 mb-5 bg-slate-50/60">
          <div className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center justify-between">
            <span>{isAr ? 'بيانات صرف الدواء للمريض (تعبأ من قبل الصيدلاني)' : 'Pharmacy Dispensing Record'}</span>
            <span className="text-[11px] font-normal text-slate-500">A4 Clinical Copy</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-xs">
            <div className="border-b border-slate-400 pb-1">
              <span className="text-slate-500 block text-[10px]">{t.patientName}:</span>
              <span className="text-slate-400 italic">...................................................</span>
            </div>
            <div className="border-b border-slate-400 pb-1">
              <span className="text-slate-500 block text-[10px]">{t.patientInstructions}:</span>
              <span className="text-slate-400 italic">...................................................</span>
            </div>
            <div className="border border-slate-300 rounded p-2 text-center bg-white">
              <span className="text-slate-500 block text-[10px] mb-4">{t.pharmacistSignature}</span>
              <span className="text-slate-300 text-[10px]">[ الختم والتوقيع الرسمي ]</span>
            </div>
          </div>
        </section>

        {/* Footer & Emergency Poison Hotline */}
        <footer className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-500">
          <div className="flex items-center gap-1.5 text-rose-800 font-semibold">
            <PhoneCall size={13} />
            <span>{t.emergencyHotline}: {t.emergencyNumber}</span>
          </div>
          <div>
            <span>{t.storageInstructions}: {medicine.storage[lang]}</span>
          </div>
          <div>
            <span>{t.ministryOfHealth}</span>
          </div>
        </footer>
      </div>
    </div>
  );
};
