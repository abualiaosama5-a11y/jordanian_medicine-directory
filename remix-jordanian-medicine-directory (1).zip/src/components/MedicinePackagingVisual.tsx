import React from 'react';
import { Pill, ShieldCheck, Zap, Activity, HeartPulse, ThermometerSnowflake, Flame } from 'lucide-react';
import { Medicine, Language } from '../types';

interface MedicinePackagingVisualProps {
  medicine: Medicine;
  language: Language;
  size?: 'sm' | 'md' | 'lg' | 'detail';
  className?: string;
}

export const MedicinePackagingVisual: React.FC<MedicinePackagingVisualProps> = ({
  medicine,
  language,
  size = 'md',
  className = '',
}) => {
  const primaryName = medicine.name[language];
  const secondaryName = language === 'ar' ? medicine.name.en : medicine.name.ar;
  const isArabic = language === 'ar';

  // Distinct elegant clinical color palettes based on medicine category
  const categoryThemes: Record<
    string,
    {
      gradient: string;
      accentBg: string;
      accentBorder: string;
      textAccent: string;
      tagBg: string;
      icon: React.ReactNode;
    }
  > = {
    painkillers: {
      gradient: 'from-teal-800 via-teal-900 to-slate-950',
      accentBg: 'bg-teal-500/20',
      accentBorder: 'border-teal-400/40',
      textAccent: 'text-teal-300',
      tagBg: 'bg-teal-400/20 text-teal-200 border-teal-400/30',
      icon: <Activity className="w-3.5 h-3.5" />,
    },
    cold_flu: {
      gradient: 'from-emerald-800 via-emerald-900 to-slate-950',
      accentBg: 'bg-emerald-500/20',
      accentBorder: 'border-emerald-400/40',
      textAccent: 'text-emerald-300',
      tagBg: 'bg-emerald-400/20 text-emerald-200 border-emerald-400/30',
      icon: <ThermometerSnowflake className="w-3.5 h-3.5" />,
    },
    digestive: {
      gradient: 'from-purple-800 via-purple-900 to-slate-950',
      accentBg: 'bg-purple-500/20',
      accentBorder: 'border-purple-400/40',
      textAccent: 'text-purple-300',
      tagBg: 'bg-purple-400/20 text-purple-200 border-purple-400/30',
      icon: <Flame className="w-3.5 h-3.5" />,
    },
    vitamins: {
      gradient: 'from-amber-700 via-amber-850 to-slate-950',
      accentBg: 'bg-amber-500/20',
      accentBorder: 'border-amber-400/40',
      textAccent: 'text-amber-300',
      tagBg: 'bg-amber-400/20 text-amber-200 border-amber-400/30',
      icon: <Zap className="w-3.5 h-3.5" />,
    },
    antibiotics: {
      gradient: 'from-cyan-800 via-cyan-900 to-slate-950',
      accentBg: 'bg-cyan-500/20',
      accentBorder: 'border-cyan-400/40',
      textAccent: 'text-cyan-300',
      tagBg: 'bg-cyan-400/20 text-cyan-200 border-cyan-400/30',
      icon: <ShieldCheck className="w-3.5 h-3.5" />,
    },
    chronic: {
      gradient: 'from-indigo-800 via-indigo-900 to-slate-950',
      accentBg: 'bg-indigo-500/20',
      accentBorder: 'border-indigo-400/40',
      textAccent: 'text-indigo-300',
      tagBg: 'bg-indigo-400/20 text-indigo-200 border-indigo-400/30',
      icon: <HeartPulse className="w-3.5 h-3.5" />,
    },
  };

  const theme = categoryThemes[medicine.category] || categoryThemes.painkillers;

  if (size === 'sm') {
    return (
      <div
        className={`relative rounded-xl bg-gradient-to-br ${theme.gradient} text-white p-2.5 flex flex-col justify-between overflow-hidden shadow-xs border ${theme.accentBorder} select-none ${className}`}
        dir={isArabic ? 'rtl' : 'ltr'}
      >
        <div className="flex items-center justify-between text-[10px] font-mono opacity-80 mb-1">
          <span className="font-bold tracking-wider">OTC</span>
          <span className="truncate max-w-[90px]">{medicine.strength}</span>
        </div>
        <div className="font-black text-xs leading-snug tracking-wide text-white truncate">
          {primaryName}
        </div>
      </div>
    );
  }

  if (size === 'detail') {
    return (
      <div
        className={`relative w-full rounded-2xl bg-gradient-to-br ${theme.gradient} text-white p-6 shadow-md border-2 ${theme.accentBorder} overflow-hidden select-none ${className}`}
        dir={isArabic ? 'rtl' : 'ltr'}
      >
        {/* Subtle background geometric pharmaceutical pill watermarks */}
        <div className="absolute -end-10 -bottom-10 opacity-10 pointer-events-none transform rotate-12">
          <Pill className="w-48 h-48 text-white" />
        </div>
        <div className="absolute end-1/3 -top-12 opacity-5 pointer-events-none">
          <Pill className="w-36 h-36 text-white" />
        </div>

        {/* Package Header Row */}
        <div className="relative z-10 flex items-center justify-between border-b border-white/15 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider bg-emerald-500 text-slate-950 shadow-xs">
              OTC • بدون وصفة
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${theme.tagBg} flex items-center gap-1`}>
              {theme.icon}
              <span>{medicine.strength}</span>
            </span>
          </div>

          <div className="text-[11px] font-mono text-white/60">
            {medicine.dosageForm[language]}
          </div>
        </div>

        {/* Big Bold Typography Trade Name on Packaging */}
        <div className="relative z-10 space-y-1.5 my-2">
          <div className="flex items-baseline gap-2.5 flex-wrap">
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight drop-shadow-sm">
              {primaryName}
            </h2>
            <span className="text-lg font-bold text-white/70">
              ({secondaryName})
            </span>
          </div>

          <p className={`text-sm font-semibold ${theme.textAccent} tracking-wide flex items-center gap-1.5`}>
            <span>{medicine.genericName[language]}</span>
          </p>
        </div>

        {/* Package Footer Seal */}
        <div className="relative z-10 pt-4 mt-4 border-t border-white/10 flex items-center justify-between text-xs text-white/70">
          <span className="truncate max-w-[65%] font-medium">
            {medicine.manufacturer[language]}
          </span>
          <span className="font-mono text-[11px] text-white/50">
            {medicine.origin[language]}
          </span>
        </div>
      </div>
    );
  }

  // Default 'md' size: Used on the mobile-friendly card header
  return (
    <div
      className={`relative w-full rounded-t-2xl bg-gradient-to-br ${theme.gradient} text-white p-3.5 sm:p-4 overflow-hidden shadow-inner select-none ${className}`}
      dir={isArabic ? 'rtl' : 'ltr'}
    >
      {/* Subtle pill watermark in background */}
      <div className="absolute -end-6 -bottom-6 opacity-10 pointer-events-none transform -rotate-12">
        <Pill className="w-28 h-28 text-white" />
      </div>

      {/* Top micro badges */}
      <div className="relative z-10 flex items-center justify-between mb-1.5">
        <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-emerald-500/90 text-slate-950 shadow-2xs">
          OTC
        </span>

        <span className="text-[11px] font-bold font-mono px-2 py-0.5 rounded bg-white/10 border border-white/15 text-white/90">
          {medicine.strength}
        </span>
      </div>

      {/* Prominently Printed Medicine Name */}
      <div className="relative z-10 py-1">
        <div className="flex items-baseline gap-1.5 flex-wrap">
          <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-tight drop-shadow-xs">
            {primaryName}
          </h3>
          <span className="text-xs font-semibold text-white/60">
            ({secondaryName})
          </span>
        </div>
        <p className={`text-xs font-semibold ${theme.textAccent} truncate mt-0.5`}>
          {medicine.genericName[language]}
        </p>
      </div>

      {/* Form & Origin Strip */}
      <div className="relative z-10 pt-1.5 mt-1 border-t border-white/10 flex items-center justify-between text-[11px] text-white/65">
        <span className="truncate max-w-[60%]">{medicine.dosageForm[language]}</span>
        <span className="truncate max-w-[38%] text-end font-mono text-[10px] text-white/50">
          {medicine.manufacturer[language].split('/')[0].trim()}
        </span>
      </div>
    </div>
  );
};
