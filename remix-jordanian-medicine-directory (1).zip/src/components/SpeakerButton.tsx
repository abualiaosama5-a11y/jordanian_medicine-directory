import React, { useState } from 'react';
import { Volume2 } from 'lucide-react';
import { Language } from '../types';
import { speakMedicineName, stopSpeech } from '../utils/speech';

interface SpeakerButtonProps {
  id?: string;
  nameToSpeak: string;
  lang: Language;
  forceLang?: Language | 'en-US';
  rate?: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  activeMedicineId?: string;
  currentSpeakingId?: string | null;
  setCurrentSpeakingId?: (id: string | null) => void;
  title?: string;
  label?: string;
}

export const SpeakerButton: React.FC<SpeakerButtonProps> = ({
  id,
  nameToSpeak,
  lang,
  forceLang,
  rate,
  size = 'md',
  className = '',
  activeMedicineId,
  currentSpeakingId,
  setCurrentSpeakingId,
  title,
  label,
}) => {
  const [internalSpeaking, setInternalSpeaking] = useState(false);

  const effectiveLang = forceLang || lang;
  const isSpeaking = currentSpeakingId && activeMedicineId
    ? currentSpeakingId === (activeMedicineId + (forceLang ? `-${forceLang}` : ''))
    : internalSpeaking;

  const handleToggleSpeak = (e: React.MouseEvent) => {
    e.stopPropagation();

    if (isSpeaking) {
      stopSpeech();
      setInternalSpeaking(false);
      if (setCurrentSpeakingId) setCurrentSpeakingId(null);
      return;
    }

    const uniqueId = (activeMedicineId || nameToSpeak) + (forceLang ? `-${forceLang}` : '');
    if (setCurrentSpeakingId) setCurrentSpeakingId(uniqueId);
    setInternalSpeaking(true);

    const success = speakMedicineName({
      text: nameToSpeak,
      lang: effectiveLang,
      rate,
      onStart: () => {
        setInternalSpeaking(true);
        if (setCurrentSpeakingId) setCurrentSpeakingId(uniqueId);
      },
      onEnd: () => {
        setInternalSpeaking(false);
        if (setCurrentSpeakingId) setCurrentSpeakingId(null);
      },
      onError: () => {
        setInternalSpeaking(false);
        if (setCurrentSpeakingId) setCurrentSpeakingId(null);
      },
    });

    if (!success) {
      setInternalSpeaking(false);
      if (setCurrentSpeakingId) setCurrentSpeakingId(null);
    }
  };

  const sizeClasses = {
    sm: 'p-1.5 text-xs',
    md: 'p-2 text-sm',
    lg: 'p-2.5 text-base',
  };

  const iconSizes = {
    sm: 15,
    md: 18,
    lg: 22,
  };

  return (
    <button
      id={id}
      type="button"
      onClick={handleToggleSpeak}
      title={title || (effectiveLang === 'ar' ? 'استمع إلى نطق الاسم بالعربية' : 'Listen to native English pronunciation')}
      aria-label={label || (effectiveLang === 'ar' ? `استمع لنطق ${nameToSpeak}` : `Pronounce ${nameToSpeak}`)}
      className={`relative inline-flex items-center justify-center gap-1.5 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-1 cursor-pointer ${
        isSpeaking
          ? 'bg-teal-600 text-white shadow-md shadow-teal-600/30 scale-105'
          : 'bg-teal-50 text-teal-700 hover:bg-teal-100 hover:text-teal-900 border border-teal-200/80 shadow-xs'
      } ${sizeClasses[size]} ${className}`}
    >
      {isSpeaking ? (
        <>
          <span className="absolute -inset-1 rounded-full animate-ping bg-teal-400 opacity-40" />
          <Volume2 size={iconSizes[size]} className="animate-pulse relative z-10" />
        </>
      ) : (
        <Volume2 size={iconSizes[size]} className="transition-transform group-hover:scale-110" />
      )}
      {label && <span className="font-semibold text-xs leading-none">{label}</span>}
    </button>
  );
};
