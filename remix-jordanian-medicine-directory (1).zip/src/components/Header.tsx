import React from 'react';
import { Pill, Globe, PhoneCall, ShieldCheck, ArrowLeftRight } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../data/translations';

interface HeaderProps {
  language: Language;
  onToggleLanguage: () => void;
  compareCount?: number;
  onOpenCompare?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onToggleLanguage,
  compareCount = 0,
  onOpenCompare,
}) => {
  const t = translations[language];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/85 backdrop-blur-md transition-all shadow-xs">
      {/* Top micro banner for national medical registration badge */}
      <div className="bg-gradient-to-r from-teal-900 via-teal-800 to-cyan-900 text-teal-100 text-xs py-1.5 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center justify-center w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-medium tracking-wide">{t.badgeGov}</span>
          </div>

          <div className="hidden sm:flex items-center gap-4 text-[11px] text-teal-200">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-teal-300" />
              <span>{t.ministryOfHealth}</span>
            </span>
            <span className="text-teal-400">•</span>
            <span className="flex items-center gap-1.5">
              <PhoneCall className="w-3.5 h-3.5 text-amber-300" />
              <span>{t.emergencyHotline}: <strong className="text-white font-mono">{t.emergencyNumber}</strong></span>
            </span>
          </div>
        </div>
      </div>

      {/* Main navigation header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
        <div className="flex items-center justify-between gap-4">
          {/* Brand identity */}
          <div className="flex items-center gap-3.5">
            <div className="relative flex items-center justify-center w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-tr from-teal-600 to-cyan-600 text-white shadow-md shadow-teal-700/20">
              <Pill className="w-6 h-6 transform -rotate-45" />
              <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center text-[8px] font-bold text-white">
                JO
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
                  {t.appTitle}
                </h1>
                <span className="inline-block px-2 py-0.5 rounded-full text-[11px] font-semibold bg-teal-50 text-teal-700 border border-teal-200/70">
                  {language === 'ar' ? 'الأردن' : 'Jordan'}
                </span>
                <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                  made by osamaabualia
                </span>
              </div>
              <p className="text-xs text-slate-500 line-clamp-1 max-w-xl font-normal">
                {t.appSubtitle}
              </p>
            </div>
          </div>

          {/* Right Action buttons: Compare Shortcut & Bilingual Switcher */}
          <div className="flex items-center gap-2 sm:gap-3">
            {onOpenCompare && (
              <button
                id="header-compare-btn"
                type="button"
                onClick={onOpenCompare}
                className={`relative inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 border cursor-pointer ${
                  compareCount > 0
                    ? 'bg-teal-50 text-teal-800 border-teal-300 shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200/80 text-slate-700 border-slate-200'
                }`}
                title={t.compareMedicines}
              >
                <ArrowLeftRight className="w-4 h-4 text-teal-600" />
                <span className="hidden md:inline">{t.compare}</span>
                {compareCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-teal-600 text-white font-mono">
                    {compareCount}
                  </span>
                )}
              </button>
            )}

            <button
              id="language-toggle-button"
              type="button"
              onClick={onToggleLanguage}
              aria-label={language === 'ar' ? 'تبديل اللغة إلى الإنجليزية' : 'Switch language to Arabic'}
              className="relative group inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold transition-all duration-200 bg-slate-100 hover:bg-teal-50 text-slate-700 hover:text-teal-800 border border-slate-300 hover:border-teal-300 shadow-xs active:scale-95 cursor-pointer"
            >
              <Globe className="w-4 h-4 text-teal-600 transition-transform group-hover:rotate-12" />
              <div className="flex items-center gap-1.5 font-medium">
                <span className={`px-1.5 py-0.5 rounded text-xs transition-colors ${language === 'ar' ? 'bg-teal-600 text-white font-bold' : 'text-slate-500'}`}>
                  العربية
                </span>
                <span className="text-slate-300 text-xs">/</span>
                <span className={`px-1.5 py-0.5 rounded text-xs transition-colors ${language === 'en' ? 'bg-teal-600 text-white font-bold' : 'text-slate-500'}`}>
                  English
                </span>
              </div>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
