import React, { useEffect } from 'react';
import {
  X,
  ArrowLeftRight,
  Pill,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Building2,
  MapPin,
  Coins,
  ShieldCheck,
  Plus,
  Trash2,
  Printer,
  Info,
} from 'lucide-react';
import { Medicine, Language } from '../types';
import { translations } from '../data/translations';
import { SpeakerButton } from './SpeakerButton';
import { MEDICINES_DATA } from '../data/medicines';

interface CompareMedicinesModalProps {
  isOpen: boolean;
  selectedMedicines: Medicine[];
  language: Language;
  onClose: () => void;
  onRemoveMedicine: (medicineId: string) => void;
  onAddMedicine: (medicine: Medicine) => void;
  onSwapMedicines: () => void;
  currentSpeakingId: string | null;
  setCurrentSpeakingId: (id: string | null) => void;
}

export const CompareMedicinesModal: React.FC<CompareMedicinesModalProps> = ({
  isOpen,
  selectedMedicines,
  language,
  onClose,
  onRemoveMedicine,
  onAddMedicine,
  onSwapMedicines,
  currentSpeakingId,
  setCurrentSpeakingId,
}) => {
  const t = translations[language];

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = '';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const med1 = selectedMedicines[0];
  const med2 = selectedMedicines[1];

  const availableToAdd = MEDICINES_DATA.filter(
    (m) => !selectedMedicines.some((s) => s.id === m.id)
  );

  // Check for interesting clinical comparison highlights
  const bothParacetamol =
    med1 &&
    med2 &&
    (med1.id === 'revanin' || med1.id === 'panadol') &&
    (med2.id === 'revanin' || med2.id === 'panadol');

  const painkillerComparison =
    med1 &&
    med2 &&
    med1.category === 'painkillers' &&
    med2.category === 'painkillers' &&
    !bothParacetamol;

  return (
    <div
      id="compare-medicines-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="compare-medicines-modal"
        className="relative w-full max-w-5xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[94vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 z-30 flex items-center justify-between px-5 py-4 border-b border-slate-200/90 bg-white/95 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center border border-teal-200">
              <ArrowLeftRight className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900">
                {t.compareMedicines}
              </h2>
              <p className="text-xs text-slate-500 font-normal hidden sm:block">
                {t.compareSubtitle}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {selectedMedicines.length === 2 && (
              <button
                type="button"
                onClick={onSwapMedicines}
                title={t.swapMedicines}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-teal-50 hover:text-teal-800 transition-colors"
              >
                <ArrowLeftRight className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t.swapMedicines}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => window.print()}
              title={t.printLeaflet}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t.printLeaflet}</span>
            </button>

            <button
              id="close-compare-modal-btn"
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              aria-label={t.close}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Clinical Alert Banner if Both Contain Paracetamol or Painkillers */}
        {bothParacetamol && (
          <div className="bg-amber-500/10 border-b border-amber-200 px-5 py-2.5 flex items-center gap-2.5 text-xs text-amber-900 font-medium">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              {language === 'ar'
                ? 'تحذير سريري هام: كلا الدوائين يحتويان على نفس المادة الفعالة (الباراسيتامول). يمنع تناولهما معاً في نفس الوقت لتفادي خطر التسمم الكبدي أو الجرعة الزائدة.'
                : 'Clinical Alert: Both medications contain Paracetamol. Do NOT take both simultaneously to prevent accidental overdose and liver toxicity.'}
            </span>
          </div>
        )}

        {painkillerComparison && (
          <div className="bg-teal-500/10 border-b border-teal-200 px-5 py-2.5 flex items-center gap-2.5 text-xs text-teal-900 font-medium">
            <Info className="w-4 h-4 text-teal-600 shrink-0" />
            <span>
              {language === 'ar'
                ? 'فروقات علاجية: الباراسيتامول (ريفانين/بنادول) مسكن وخافض للحرارة لطيف على المعدة، بينما الإيبوبروفين (بروفينال) مضاد للالتهاب أقوى في تخفيف التورم لكنه يتطلب الحذر لمرضى المعدة.'
                : 'Therapeutic Note: Paracetamol is gentle on the gastric lining, while Ibuprofen provides stronger anti-inflammatory action for joint swelling but should be taken with food.'}
            </span>
          </div>
        )}

        {/* Scrollable Side-by-Side Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Top Columns: Medicine Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            {/* Slot 1 */}
            {med1 ? (
              <div className="relative rounded-2xl bg-gradient-to-br from-teal-50/50 to-white p-4 sm:p-5 border-2 border-teal-300 shadow-sm flex flex-col justify-between space-y-4">
                <div className="flex items-start gap-3.5">
                  <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden shrink-0 bg-slate-100 border border-slate-200">
                    <img
                      src={med1.image}
                      alt={med1.name[language]}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-teal-100 text-teal-800 border border-teal-200">
                        {t[med1.category]}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-md text-[11px] font-medium ${
                          med1.prescriptionRequired
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {med1.prescriptionRequired ? 'Rx' : 'OTC'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-1">
                      <h3 className="text-lg sm:text-xl font-bold text-slate-900 truncate">
                        {med1.name[language]}
                      </h3>
                      <SpeakerButton
                        id={`compare-speaker-1`}
                        nameToSpeak={med1.name[language]}
                        lang={language}
                        size="sm"
                        activeMedicineId={med1.id}
                        currentSpeakingId={currentSpeakingId}
                        setCurrentSpeakingId={setCurrentSpeakingId}
                      />
                    </div>
                    <p className="text-xs font-semibold text-teal-700">{med1.genericName[language]}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{med1.strength} • {med1.dosageForm[language]}</p>
                  </div>
                </div>

                <div className="pt-2 border-t border-teal-200/60 flex items-center justify-between text-xs text-slate-500">
                  <span className="font-medium">{med1.manufacturer[language]}</span>
                  {selectedMedicines.length > 1 && (
                    <button
                      type="button"
                      onClick={() => onRemoveMedicine(med1.id)}
                      className="text-rose-600 hover:text-rose-800 font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{t.removeFromCompare}</span>
                    </button>
                  )}
                </div>
              </div>
            ) : null}

            {/* Slot 2 */}
            {med2 ? (
              <div className="relative rounded-2xl bg-gradient-to-br from-cyan-50/50 to-white p-4 sm:p-5 border-2 border-cyan-300 shadow-sm flex flex-col justify-between space-y-4">
                <div className="flex items-start gap-3.5">
                  <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden shrink-0 bg-slate-100 border border-slate-200">
                    <img
                      src={med2.image}
                      alt={med2.name[language]}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-cyan-100 text-cyan-800 border border-cyan-200">
                        {t[med2.category]}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded-md text-[11px] font-medium ${
                          med2.prescriptionRequired
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {med2.prescriptionRequired ? 'Rx' : 'OTC'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-1">
                      <h3 className="text-lg sm:text-xl font-bold text-slate-900 truncate">
                        {med2.name[language]}
                      </h3>
                      <SpeakerButton
                        id={`compare-speaker-2`}
                        nameToSpeak={med2.name[language]}
                        lang={language}
                        size="sm"
                        activeMedicineId={med2.id}
                        currentSpeakingId={currentSpeakingId}
                        setCurrentSpeakingId={setCurrentSpeakingId}
                      />
                    </div>
                    <p className="text-xs font-semibold text-cyan-700">{med2.genericName[language]}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{med2.strength} • {med2.dosageForm[language]}</p>
                  </div>
                </div>

                <div className="pt-2 border-t border-cyan-200/60 flex items-center justify-between text-xs text-slate-500">
                  <span className="font-medium">{med2.manufacturer[language]}</span>
                  <button
                    type="button"
                    onClick={() => onRemoveMedicine(med2.id)}
                    className="text-rose-600 hover:text-rose-800 font-semibold inline-flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{t.removeFromCompare}</span>
                  </button>
                </div>
              </div>
            ) : (
              /* Slot 2 is empty -> Quick picker to add second medicine */
              <div className="rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50/70 p-5 flex flex-col justify-center items-center text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center">
                  <Plus className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-800 text-sm sm:text-base">
                    {t.selectSecondMedicine}
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {language === 'ar'
                      ? 'اختر دواءً آخر من الدليل لعرض المقارنة المباشرة'
                      : 'Choose another medicine from the directory to compare'}
                  </p>
                </div>

                {/* Quick Add Pills */}
                <div className="w-full flex flex-wrap justify-center gap-1.5 pt-1">
                  {availableToAdd.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => onAddMedicine(item)}
                      className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-white hover:bg-teal-600 hover:text-white text-slate-700 border border-slate-200 shadow-2xs transition-all cursor-pointer"
                    >
                      + {item.name[language]}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Detailed Side-by-Side Rows */}
          {med1 && med2 && (
            <div className="space-y-6 pt-4 border-t border-slate-200">
              {/* Row 1: Active Ingredients / Composition (التركيبة العلمية) */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900 bg-slate-100/90 py-2 px-3 rounded-xl">
                  <Pill className="w-4 h-4 text-teal-600" />
                  <span>{t.scientificComposition}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-teal-50/50 border border-teal-200/80">
                    <strong className="block text-xs font-bold text-teal-900 mb-2">
                      {med1.name[language]}
                    </strong>
                    <ul className="space-y-1.5 text-xs text-slate-700">
                      {med1.activeIngredients[language].map((ing, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-teal-600 mt-1.5 shrink-0" />
                          <span>{ing}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-4 rounded-xl bg-cyan-50/50 border border-cyan-200/80">
                    <strong className="block text-xs font-bold text-cyan-900 mb-2">
                      {med2.name[language]}
                    </strong>
                    <ul className="space-y-1.5 text-xs text-slate-700">
                      {med2.activeIngredients[language].map((ing, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-600 mt-1.5 shrink-0" />
                          <span>{ing}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Row 2: Benefits and Indications (الفوائد ودواعي الاستعمال) */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900 bg-slate-100/90 py-2 px-3 rounded-xl">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>{t.benefitsAndIndications}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-2xs space-y-2">
                    <strong className="block text-xs font-bold text-slate-800">
                      {med1.name[language]}
                    </strong>
                    <ul className="space-y-2 text-xs text-slate-600">
                      {med1.benefitsAndIndications[language].map((ind, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                            ✓
                          </span>
                          <span className="leading-relaxed">{ind}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-2xs space-y-2">
                    <strong className="block text-xs font-bold text-slate-800">
                      {med2.name[language]}
                    </strong>
                    <ul className="space-y-2 text-xs text-slate-600">
                      {med2.benefitsAndIndications[language].map((ind, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="w-4 h-4 rounded-full bg-cyan-100 text-cyan-800 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                            ✓
                          </span>
                          <span className="leading-relaxed">{ind}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Row 3: Side Effects & Complications (الأعراض الجانبية والمضاعفات) */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-rose-900 bg-rose-50/90 py-2 px-3 rounded-xl border border-rose-100">
                  <AlertTriangle className="w-4 h-4 text-rose-600" />
                  <span>{t.sideEffectsAndComplications}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-2xs space-y-2">
                    <strong className="block text-xs font-bold text-slate-800">
                      {med1.name[language]}
                    </strong>
                    <ul className="space-y-1.5 text-xs text-slate-600">
                      {med1.sideEffectsAndComplications[language].map((eff, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                          <span className="leading-relaxed">{eff}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-2xs space-y-2">
                    <strong className="block text-xs font-bold text-slate-800">
                      {med2.name[language]}
                    </strong>
                    <ul className="space-y-1.5 text-xs text-slate-600">
                      {med2.sideEffectsAndComplications[language].map((eff, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                          <span className="leading-relaxed">{eff}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Row 4: Dosage, Price & Manufacturer Overview */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900 bg-slate-100/90 py-2 px-3 rounded-xl">
                  <Clock className="w-4 h-4 text-teal-600" />
                  <span>{t.dosageAndUsage} & {t.quickFacts}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2.5 text-xs">
                    <div>
                      <span className="font-bold text-slate-800 block mb-0.5">{t.dosageAndUsage}:</span>
                      <p className="text-slate-600 leading-relaxed">{med1.dosageAndUsage[language]}</p>
                    </div>
                    <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-slate-600">
                      <span>{t.approxPrice}:</span>
                      <strong className="text-slate-900 font-mono">{med1.approxPriceJOD}</strong>
                    </div>
                    <div className="flex items-center justify-between text-slate-600">
                      <span>{t.origin}:</span>
                      <span className="text-slate-800 font-medium">{med1.origin[language]}</span>
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2.5 text-xs">
                    <div>
                      <span className="font-bold text-slate-800 block mb-0.5">{t.dosageAndUsage}:</span>
                      <p className="text-slate-600 leading-relaxed">{med2.dosageAndUsage[language]}</p>
                    </div>
                    <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-slate-600">
                      <span>{t.approxPrice}:</span>
                      <strong className="text-slate-900 font-mono">{med2.approxPriceJOD}</strong>
                    </div>
                    <div className="flex items-center justify-between text-slate-600">
                      <span>{t.origin}:</span>
                      <span className="text-slate-800 font-medium">{med2.origin[language]}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="sticky bottom-0 z-20 flex items-center justify-between px-5 py-3 border-t border-slate-200 bg-slate-50/95 backdrop-blur-md">
          <div className="text-xs text-slate-500 hidden sm:flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-teal-600" />
            <span>{t.medicalDisclaimer}</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="ms-auto px-5 py-2.5 rounded-xl text-sm font-semibold bg-teal-600 hover:bg-teal-700 text-white shadow-sm transition-colors cursor-pointer"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
