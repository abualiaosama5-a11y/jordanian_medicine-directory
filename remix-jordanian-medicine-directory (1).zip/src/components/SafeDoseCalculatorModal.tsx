import React, { useState } from 'react';
import { Medicine, Language } from '../types';
import { translations } from '../data/translations';
import { Calculator, AlertTriangle, CheckCircle, X, ShieldAlert, Clock } from 'lucide-react';

interface SafeDoseCalculatorModalProps {
  medicine: Medicine;
  lang: Language;
  isOpen: boolean;
  onClose: () => void;
}

export const SafeDoseCalculatorModal: React.FC<SafeDoseCalculatorModalProps> = ({
  medicine,
  lang,
  isOpen,
  onClose,
}) => {
  const [tabletsTaken, setTabletsTaken] = useState<number>(1);
  const t = translations[lang];
  const isAr = lang === 'ar';

  if (!isOpen) return null;

  // Derive strength in mg from strength string
  const strengthMatch = medicine.strength.match(/(\d+)\s*mg/i);
  const strengthMg = strengthMatch ? parseInt(strengthMatch[1], 10) : 500;

  // Maximum mg thresholds
  let maxSafeMg = 4000;
  if (medicine.id === 'cataflam') maxSafeMg = 150;
  else if (medicine.id === 'profinal') maxSafeMg = 1200;
  else if (medicine.id === 'voltaren') maxSafeMg = 150;
  else if (medicine.id === 'fludrex') maxSafeMg = 2000;
  else if (medicine.id === 'augmentin') maxSafeMg = 2000;
  else if (medicine.id === 'spasmonore') maxSafeMg = 80;
  else if (medicine.id === 'concor') maxSafeMg = 10;
  else if (medicine.id === 'glucophage') maxSafeMg = 2550;
  else if (medicine.id === 'cecon-vitaminc') maxSafeMg = 2000;

  const currentTotalMg = tabletsTaken * strengthMg;
  const percentageOfMax = Math.min(Math.round((currentTotalMg / maxSafeMg) * 100), 180);

  const isExceeded = currentTotalMg > maxSafeMg;
  const isNearLimit = currentTotalMg >= maxSafeMg * 0.75 && !isExceeded;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-700 to-cyan-800 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-white/10 backdrop-blur-md">
              <Calculator size={22} className="text-teal-200" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight flex items-center gap-2">
                <span>{t.safeDosageCalculator}</span>
              </h3>
              <p className="text-xs text-teal-100/90">{medicine.name[lang]} ({medicine.strength})</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white rounded-full hover:bg-white/10 transition"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Daily Limit Info */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
            <span className="text-slate-600 font-medium">{t.maxDailyLimit}:</span>
            <span className="font-bold text-teal-900 bg-teal-100/80 px-2.5 py-1 rounded-md">
              {maxSafeMg} mg / 24h
            </span>
          </div>

          {/* Interactive Input */}
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              {isAr ? 'كم قرصاً / جرعة تم تناولها خلال اليوم حتى الآن؟' : 'How many tablets taken today so far?'}
            </label>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setTabletsTaken(Math.max(1, tabletsTaken - 1))}
                className="w-12 h-12 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xl flex items-center justify-center active:scale-95 transition"
              >
                -
              </button>
              <div className="flex-1 text-center py-2 px-4 bg-teal-50/50 border-2 border-teal-500/30 rounded-xl">
                <span className="text-2xl font-black text-teal-950">{tabletsTaken}</span>
                <span className="text-xs font-semibold text-teal-800 block">
                  {isAr ? 'أقراص / جرعات' : 'Tablets / Doses'} ({currentTotalMg} mg)
                </span>
              </div>
              <button
                type="button"
                onClick={() => setTabletsTaken(tabletsTaken + 1)}
                className="w-12 h-12 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xl flex items-center justify-center active:scale-95 transition shadow-sm"
              >
                +
              </button>
            </div>
          </div>

          {/* Progress / Status Gauge */}
          <div>
            <div className="flex justify-between text-xs font-semibold mb-1.5">
              <span className="text-slate-600">
                {isAr ? 'مؤشر استهلاك الحد الأقصى' : 'Cumulative Daily Intake'}
              </span>
              <span className={`font-bold ${isExceeded ? 'text-rose-600' : isNearLimit ? 'text-amber-600' : 'text-emerald-600'}`}>
                {percentageOfMax}%
              </span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-3.5 overflow-hidden p-0.5 border border-slate-200">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  isExceeded
                    ? 'bg-rose-500'
                    : isNearLimit
                    ? 'bg-amber-500'
                    : 'bg-emerald-500'
                }`}
                style={{ width: `${Math.min(percentageOfMax, 100)}%` }}
              />
            </div>
          </div>

          {/* Dynamic Safety Alert */}
          {isExceeded ? (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3 text-rose-900 animate-in fade-in">
              <ShieldAlert className="text-rose-600 shrink-0 mt-0.5" size={22} />
              <div className="text-xs">
                <p className="font-bold text-sm text-rose-950">
                  {isAr ? '⚠️ تحذير: تجاوزت الحد الأقصى الآمن المسموح به!' : '⚠️ Warning: Exceeded Maximum Safe Limit!'}
                </p>
                <p className="mt-1 leading-relaxed">
                  {isAr
                    ? `تجاوز جرعة ${maxSafeMg} ملغم خلال 24 ساعة قد يؤدي إلى مضاعفات خطيرة على صحتك أو تلف الكبد/المعدة. يرجى التوقف فوراً والاتصال بطوارئ التسمم الدوائي 193 أو الدفاع المدني 911.`
                    : `Exceeding ${maxSafeMg} mg in 24 hours poses high clinical risks. Stop taking more doses and immediately contact Jordan Poison Control at 193 or 911.`}
                </p>
              </div>
            </div>
          ) : isNearLimit ? (
            <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3 text-amber-900">
              <AlertTriangle className="text-amber-600 shrink-0 mt-0.5" size={20} />
              <div className="text-xs leading-relaxed">
                <p className="font-bold">{isAr ? 'تنبيه: اقتربت من الحد الأقصى اليومي' : 'Caution: Near Daily Limit'}</p>
                <p className="mt-0.5">
                  {isAr
                    ? 'لا تتناول أي أقراص إضافية قبل مرور 6 إلى 8 ساعات كاملة، وتجنب الجمع مع أدوية مماثلة.'
                    : 'Do not take another dose before at least 6 to 8 hours. Avoid taking other combined medicines.'}
                </p>
              </div>
            </div>
          ) : (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3 text-emerald-900">
              <CheckCircle className="text-emerald-600 shrink-0 mt-0.5" size={20} />
              <div className="text-xs leading-relaxed">
                <p className="font-bold">{isAr ? 'ضمن النطاق العلاجي الآمن والمسموح' : 'Safe Therapeutic Range'}</p>
                <p className="mt-0.5">
                  {isAr
                    ? 'الجرعة الحالية آمنة. احرص دائماً على الفصل الزمني الكافي (4-6 ساعات) بين الجرعات.'
                    : 'Current dosage is within safe medical limits. Maintain adequate 4-6 hour intervals between doses.'}
                </p>
              </div>
            </div>
          )}

          {/* Timing recommendation */}
          <div className="flex items-center gap-2 text-xs text-slate-500 pt-2 border-t border-slate-100">
            <Clock size={14} className="text-teal-700" />
            <span>
              {isAr
                ? 'الفترة الزمنية الدنيا الموصى بها بين الجرعات: من 4 إلى 6 ساعات مع شرب الماء.'
                : 'Recommended interval between consecutive doses: 4 to 6 hours with a glass of water.'}
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3.5 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold rounded-xl transition"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
