import React, { useEffect, useState } from 'react';
import {
  X,
  Pill,
  AlertTriangle,
  Info,
  Building2,
  MapPin,
  Clock,
  Printer,
  ShieldCheck,
  CheckCircle2,
  Coins,
  Package,
  ArrowLeftRight,
  Check,
  Calculator,
  Volume2,
  PhoneCall,
  QrCode,
} from 'lucide-react';
import { Medicine, Language } from '../types';
import { translations } from '../data/translations';
import { SpeakerButton } from './SpeakerButton';
import { SafeDoseCalculatorModal } from './SafeDoseCalculatorModal';
import { MedicationPrintMonograph } from './MedicationPrintMonograph';
import { MedicineQRCode } from './MedicineQRCode';
import { MedicinePackagingVisual } from './MedicinePackagingVisual';

interface MedicineDetailModalProps {
  medicine: Medicine | null;
  language: Language;
  onClose: () => void;
  currentSpeakingId: string | null;
  setCurrentSpeakingId: (id: string | null) => void;
  isCompared?: boolean;
  onToggleCompare?: (medicine: Medicine) => void;
  onOpenCompareView?: () => void;
}

export const MedicineDetailModal: React.FC<MedicineDetailModalProps> = ({
  medicine,
  language,
  onClose,
  currentSpeakingId,
  setCurrentSpeakingId,
  isCompared = false,
  onToggleCompare,
  onOpenCompareView,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'indications' | 'safety' | 'dosage'>('overview');
  const [imageLoaded, setImageLoaded] = useState(false);
  const [showSafeCalculator, setShowSafeCalculator] = useState(false);
  const [showPrintPreview, setShowPrintPreview] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (showPrintPreview) {
          setShowPrintPreview(false);
        } else if (showSafeCalculator) {
          setShowSafeCalculator(false);
        } else if (showQRModal) {
          setShowQRModal(false);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose, showPrintPreview, showSafeCalculator, showQRModal]);

  // Lock body scroll when modal is open
  useEffect(() => {
    if (medicine) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [medicine]);

  if (!medicine) return null;

  const t = translations[language];
  const primaryName = medicine.name[language];
  const secondaryName = language === 'ar' ? medicine.name.en : medicine.name.ar;
  const genericName = medicine.genericName[language];
  const categoryLabel = t[medicine.category] || medicine.category;

  const handlePrint = () => {
    window.print();
  };

  return (
    <>
      {/* Hidden container exclusively rendered during window.print() */}
      <div className="hidden print:block">
        <MedicationPrintMonograph medicine={medicine} lang={language} />
      </div>

      {/* Main Interactive Detail Modal */}
      <div
        id="medicine-detail-modal-backdrop"
        className="no-print fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto bg-slate-950/65 backdrop-blur-sm transition-opacity animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div
          id="medicine-detail-modal-container"
          className="relative w-full max-w-4xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Sticky Modal Header */}
          <div className="sticky top-0 z-20 flex items-center justify-between px-5 py-3.5 border-b border-slate-200/80 bg-white/95 backdrop-blur-md">
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                  {primaryName}
                </h2>
                <span className="text-sm text-slate-400 font-normal">({secondaryName})</span>
              </div>

              {/* Phonetic Badge */}
              <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md font-mono text-xs font-bold text-teal-900 bg-teal-50 border border-teal-200/80">
                🗣️ {medicine.englishPhonetic}
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Safe Dose Calculator Button */}
              <button
                type="button"
                onClick={() => setShowSafeCalculator(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-teal-800 bg-teal-50 hover:bg-teal-100 border border-teal-200 transition-colors cursor-pointer shadow-2xs"
                title={t.safeDosageCalculator}
              >
                <Calculator size={14} className="text-teal-600" />
                <span className="hidden md:inline">{t.safeDosageCalculator}</span>
              </button>

              {/* QR Code Quick Access Button */}
              <button
                id="modal-header-qr-btn"
                type="button"
                onClick={() => setShowQRModal(true)}
                title={t.qrCodeTitle}
                aria-label={t.qrCodeTitle}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-teal-900 bg-teal-50 hover:bg-teal-100 border border-teal-200 transition-colors cursor-pointer shadow-2xs"
              >
                <QrCode size={14} className="text-teal-700" />
                <span className="hidden sm:inline">{t.qrCodeTitle}</span>
              </button>

              {/* Compare Toggle */}
              {onToggleCompare && (
                <button
                  type="button"
                  onClick={() => onToggleCompare(medicine)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all border shadow-xs cursor-pointer ${
                    isCompared
                      ? 'bg-teal-600 text-white border-teal-500'
                      : 'bg-slate-100 hover:bg-teal-50 text-slate-700 hover:text-teal-800 border-slate-200'
                  }`}
                  title={isCompared ? t.removeFromCompare : t.addToCompare}
                >
                  {isCompared ? <Check className="w-3.5 h-3.5" /> : <ArrowLeftRight className="w-3.5 h-3.5" />}
                  <span>{isCompared ? (language === 'ar' ? 'محدد' : 'Selected') : t.compare}</span>
                </button>
              )}

              {/* Print Button */}
              <button
                id="modal-header-print-btn"
                type="button"
                onClick={() => setShowPrintPreview(true)}
                title={t.printOfficialMonograph}
                aria-label={t.printOfficialMonograph}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer shadow-2xs"
              >
                <Printer size={15} className="text-teal-700" />
                <span className="hidden sm:inline">{t.printLeaflet}</span>
              </button>

              {/* Close Button */}
              <button
                id="close-medicine-modal-btn"
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                aria-label={t.close}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Scrollable Content Area */}
          <div className="flex-1 overflow-y-auto p-5 sm:p-7 space-y-6">
            {/* Pronunciation & Phonetic Audio Banner */}
            <div className="rounded-2xl bg-gradient-to-r from-teal-900 to-cyan-950 text-white p-4 sm:p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-teal-500/30 text-teal-200 font-mono text-xs font-bold">
                    {medicine.englishPhonetic}
                  </span>
                  <span className="text-xs text-teal-300 font-semibold">
                    {t.englishPronunciation}
                  </span>
                </div>
                <h4 className="text-sm font-bold text-slate-100">
                  {medicine.englishPronunciationGuide?.[language] || `How to say: ${medicine.englishPhonetic} (${medicine.name.en})`}
                </h4>
                <p className="text-xs text-slate-300">
                  {language === 'ar'
                    ? 'استمع إلى النطق الإنجليزي الطبي الدقيق للاسم التجاري والمادة الفعالة حسب المعايير الدولية:'
                    : 'Listen to native medical English pronunciation of the brand and generic substance:'}
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0 flex-wrap">
                {/* English Pronunciation Button */}
                <SpeakerButton
                  id={`detail-speak-en-${medicine.id}`}
                  nameToSpeak={medicine.audioEnglishText || medicine.name.en}
                  lang="en"
                  forceLang="en"
                  rate={0.82}
                  size="md"
                  label={t.listenEnglish}
                  activeMedicineId={medicine.id}
                  currentSpeakingId={currentSpeakingId}
                  setCurrentSpeakingId={setCurrentSpeakingId}
                  className="bg-teal-500 text-slate-950 hover:bg-teal-400 font-bold px-3 py-2 rounded-xl"
                />

                {/* Arabic Pronunciation Button */}
                <SpeakerButton
                  id={`detail-speak-ar-${medicine.id}`}
                  nameToSpeak={medicine.name.ar}
                  lang="ar"
                  forceLang="ar"
                  rate={0.9}
                  size="md"
                  label={t.listenArabic}
                  activeMedicineId={medicine.id}
                  currentSpeakingId={currentSpeakingId}
                  setCurrentSpeakingId={setCurrentSpeakingId}
                  className="bg-white/10 text-white hover:bg-white/20 border border-white/20 px-3 py-2 rounded-xl"
                />
              </div>
            </div>

            {/* Hero Banner with Image & Key Badges */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start rounded-2xl bg-gradient-to-br from-slate-50 via-teal-50/30 to-cyan-50/20 p-4 sm:p-5 border border-slate-200/80">
              {/* Medicine Packaging Visual */}
              <div className="md:col-span-5 relative rounded-2xl overflow-hidden shadow-sm border border-slate-200/90">
                <MedicinePackagingVisual medicine={medicine} language={language} size="detail" />
              </div>

              {/* Quick Meta Data Grid */}
              <div className="md:col-span-7 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                        medicine.prescriptionRequired
                          ? 'bg-rose-100 text-rose-800 border border-rose-200'
                          : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      }`}
                    >
                      {medicine.prescriptionRequired ? t.prescriptionRequired : t.otcAvailable}
                    </span>

                    <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-teal-100/70 text-teal-800 border border-teal-200">
                      {medicine.strength}
                    </span>

                    {medicine.approxPriceJOD && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200">
                        <Coins className="w-3 h-3 text-amber-600" />
                        <span>{medicine.approxPriceJOD}</span>
                      </span>
                    )}

                    {medicine.pregnancyRiskCategory && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-50 text-purple-800 border border-purple-200">
                        <ShieldCheck className="w-3 h-3 text-purple-600" />
                        <span>{medicine.pregnancyRiskCategory}</span>
                      </span>
                    )}
                  </div>

                  <h3 className="text-xl font-bold text-slate-900 mb-1">{genericName}</h3>
                  <p className="text-xs text-slate-500 font-medium">{medicine.dosageForm[language]}</p>
                </div>

                {/* Maximum Safe Daily Allowance Highlight */}
                {medicine.maxSafeDailyDose && (
                  <div className="p-3 rounded-xl bg-amber-50/80 border border-amber-200 text-xs flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2">
                      <AlertTriangle size={16} className="text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-amber-900 block">{t.maxDailyLimit}:</span>
                        <span className="text-amber-950 font-medium">{medicine.maxSafeDailyDose[language]}</span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowSafeCalculator(true)}
                      className="shrink-0 px-2.5 py-1 bg-amber-200 hover:bg-amber-300 text-amber-950 font-bold rounded-lg text-[11px] transition"
                    >
                      {t.safeDosageCalculator}
                    </button>
                  </div>
                )}

                {/* Manufacturing & Origin Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="p-3 rounded-xl bg-white border border-slate-200/80 shadow-2xs">
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-700 mb-1">
                      <Building2 className="w-3.5 h-3.5 text-teal-600" />
                      <span>{t.manufacturer}</span>
                    </div>
                    <p className="text-xs text-slate-600 font-medium leading-relaxed">
                      {medicine.manufacturer[language]}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-white border border-slate-200/80 shadow-2xs">
                    <div className="flex items-center gap-2 text-xs font-bold text-slate-700 mb-1">
                      <MapPin className="w-3.5 h-3.5 text-cyan-600" />
                      <span>{t.origin}</span>
                    </div>
                    <p className="text-xs text-slate-600 font-medium leading-relaxed">
                      {medicine.origin[language]}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Scannable Mobile Access QR Code Section */}
            <MedicineQRCode
              medicine={medicine}
              lang={language}
              variant="card"
              size={135}
            />

            {/* Nav Tabs for Detailed Breakdown */}
            <div className="flex border-b border-slate-200 space-x-2 rtl:space-x-reverse text-sm font-semibold overflow-x-auto">
              <button
                type="button"
                onClick={() => setActiveTab('overview')}
                className={`pb-3 px-3 transition-colors border-b-2 whitespace-nowrap cursor-pointer ${
                  activeTab === 'overview'
                    ? 'border-teal-600 text-teal-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {t.fullDescription} & {t.scientificComposition}
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('indications')}
                className={`pb-3 px-3 transition-colors border-b-2 whitespace-nowrap cursor-pointer ${
                  activeTab === 'indications'
                    ? 'border-teal-600 text-teal-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {t.benefitsAndIndications}
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('safety')}
                className={`pb-3 px-3 transition-colors border-b-2 whitespace-nowrap cursor-pointer ${
                  activeTab === 'safety'
                    ? 'border-rose-600 text-rose-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {t.sideEffectsAndComplications}
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('dosage')}
                className={`pb-3 px-3 transition-colors border-b-2 whitespace-nowrap cursor-pointer ${
                  activeTab === 'dosage'
                    ? 'border-teal-600 text-teal-700'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {t.dosageAndUsage}
              </button>
            </div>

            {/* TAB 1: Full Description & Active Ingredients / Composition */}
            {activeTab === 'overview' && (
              <div className="space-y-6 animate-in fade-in duration-150">
                {/* 1. Full Description (وصف الدواء) */}
                <div className="rounded-2xl bg-white p-5 border border-slate-200/90 shadow-xs space-y-3">
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                    <Info className="w-4 h-4 text-teal-600" />
                    <h4>{t.fullDescription}</h4>
                  </div>
                  <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
                    {medicine.description[language]}
                  </p>
                </div>

                {/* 2. Active Ingredients / Composition (التركيبة العلمية) */}
                <div className="rounded-2xl bg-teal-50/50 p-5 border border-teal-200/70 shadow-xs space-y-3">
                  <div className="flex items-center gap-2 text-sm font-bold text-teal-950">
                    <Pill className="w-4 h-4 text-teal-700" />
                    <h4>{t.scientificComposition}</h4>
                  </div>
                  <ul className="space-y-2">
                    {medicine.activeIngredients[language].map((ingredient, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm text-slate-700 font-medium">
                        <span className="w-1.5 h-1.5 rounded-full bg-teal-600 mt-2 shrink-0" />
                        <span>{ingredient}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {/* TAB 2: Benefits and Indications (الفوائد ودواعي الاستعمال) */}
            {activeTab === 'indications' && (
              <div className="rounded-2xl bg-white p-5 border border-slate-200/90 shadow-xs space-y-4 animate-in fade-in duration-150">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <h4>{t.benefitsAndIndications}</h4>
                </div>
                <p className="text-xs text-slate-500">
                  {language === 'ar'
                    ? 'الحالات المرضية والأعراض السريرية الموصى باستخدام الدواء لعلاجها:'
                    : 'Clinical conditions, symptoms, and approved medical uses:'}
                </p>
                <div className="grid grid-cols-1 gap-2.5">
                  {medicine.benefitsAndIndications[language].map((indication, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 hover:bg-teal-50/40 border border-slate-200/70 transition-colors"
                    >
                      <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                        {idx + 1}
                      </div>
                      <span className="text-sm font-medium text-slate-800 leading-relaxed">
                        {indication}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 3: Side Effects & Complications (الأعراض الجانبية والمضاعفات) */}
            {activeTab === 'safety' && (
              <div className="rounded-2xl bg-white p-5 border border-slate-200/90 shadow-xs space-y-5 animate-in fade-in duration-150">
                <div className="flex items-center gap-2 text-sm font-bold text-rose-900">
                  <AlertTriangle className="w-4 h-4 text-rose-600" />
                  <h4>{t.sideEffectsAndComplications}</h4>
                </div>

                <div className="p-4 rounded-xl bg-rose-50/70 border border-rose-200 text-xs sm:text-sm text-rose-900">
                  {language === 'ar'
                    ? 'كما هو الحال مع كافة المستحضرات الصيدلانية، قد تظهر بعض الأعراض الجانبية لدى نسبة من المرضى:'
                    : 'Like all pharmaceutical products, adverse reactions may manifest in a subset of patients:'}
                </div>

                <div className="space-y-2.5">
                  {medicine.sideEffectsAndComplications[language].map((effect, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200/80"
                    >
                      <span className="w-2 h-2 rounded-full bg-rose-500 mt-2 shrink-0" />
                      <span className="text-sm font-medium text-slate-700 leading-relaxed">
                        {effect}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Warnings and Contraindications */}
                <div className="pt-3 border-t border-slate-200 space-y-3">
                  <h5 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    {t.warningsAndPrecautions}
                  </h5>
                  <ul className="space-y-2">
                    {medicine.warningsAndPrecautions[language].map((warning, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-600 font-medium">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-500 mt-0.5 shrink-0" />
                        <span>{warning}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {/* TAB 4: Dosage, Usage & Storage */}
            {activeTab === 'dosage' && (
              <div className="space-y-5 animate-in fade-in duration-150">
                {/* Directions */}
                <div className="rounded-2xl bg-white p-5 border border-slate-200/90 shadow-xs space-y-3">
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                    <Clock className="w-4 h-4 text-teal-600" />
                    <h4>{t.dosageAndUsage}</h4>
                  </div>
                  <p className="text-sm sm:text-base text-slate-700 leading-relaxed p-3.5 rounded-xl bg-slate-50 border border-slate-200/70">
                    {medicine.dosageAndUsage[language]}
                  </p>
                </div>

                {/* Storage */}
                <div className="rounded-2xl bg-white p-5 border border-slate-200/90 shadow-xs space-y-3">
                  <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                    <Package className="w-4 h-4 text-cyan-600" />
                    <h4>{t.storageInstructions}</h4>
                  </div>
                  <p className="text-sm text-slate-700 font-medium">
                    {medicine.storage[language]}
                  </p>
                </div>
              </div>
            )}

            {/* Medical Disclaimer Banner */}
            <div className="rounded-2xl bg-amber-50/80 border border-amber-200/80 p-4 text-amber-900 text-xs flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <strong className="block font-semibold">{t.medicalDisclaimerTitle}</strong>
                <p className="text-amber-800 leading-relaxed font-normal">
                  {t.medicalDisclaimer}
                </p>
              </div>
            </div>

            {/* Jordan Emergency Poison Hotline banner */}
            <div className="rounded-2xl bg-slate-900 text-white p-4 text-xs flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-rose-500/20 text-rose-400">
                  <PhoneCall size={18} />
                </div>
                <div>
                  <span className="font-bold text-slate-200 block">{t.emergencyHotline}</span>
                  <span className="text-rose-400 font-bold">{t.emergencyNumber}</span>
                </div>
              </div>
              <span className="text-slate-400 text-[11px]">{t.ministryOfHealth}</span>
            </div>
          </div>

          {/* Modal Footer */}
          <div className="sticky bottom-0 z-20 flex items-center justify-between gap-3 px-5 py-3.5 border-t border-slate-200 bg-slate-50/95 backdrop-blur-md">
            <div className="flex items-center gap-2">
              {/* Print Official Monograph button */}
              <button
                type="button"
                onClick={() => setShowPrintPreview(true)}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold bg-slate-900 hover:bg-slate-800 text-white transition-colors cursor-pointer shadow-xs"
              >
                <Printer className="w-4 h-4 text-teal-400" />
                <span>{t.printOfficialMonograph}</span>
              </button>

              {onOpenCompareView && (
                <button
                  type="button"
                  onClick={() => {
                    if (!isCompared && onToggleCompare) {
                      onToggleCompare(medicine);
                    }
                    onOpenCompareView();
                  }}
                  className="hidden md:inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 transition-colors cursor-pointer"
                >
                  <ArrowLeftRight className="w-4 h-4" />
                  <span>{t.compareMedicines}</span>
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl text-sm font-semibold bg-teal-600 hover:bg-teal-700 text-white shadow-sm transition-colors cursor-pointer"
            >
              {t.close}
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Safe Dose Calculator Modal */}
      <SafeDoseCalculatorModal
        medicine={medicine}
        lang={language}
        isOpen={showSafeCalculator}
        onClose={() => setShowSafeCalculator(false)}
      />

      {/* Print Preview Modal */}
      {showPrintPreview && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
            <div className="flex-1 overflow-y-auto">
              <MedicationPrintMonograph
                medicine={medicine}
                lang={language}
                onClose={() => setShowPrintPreview(false)}
              />
            </div>
          </div>
        </div>
      )}

      {/* Dedicated Focused QR Code Modal */}
      {showQRModal && (
        <div
          className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150"
          onClick={() => setShowQRModal(false)}
        >
          <div
            className="relative w-full max-w-md bg-slate-900 text-white rounded-3xl shadow-2xl p-5 sm:p-6 border border-slate-700/80 space-y-4"
            dir={language === 'ar' ? 'rtl' : 'ltr'}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-teal-500/20 text-teal-400">
                  <QrCode size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-100">{t.qrCodeTitle}</h3>
                  <p className="text-xs text-slate-400">{primaryName}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowQRModal(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                aria-label={t.close}
              >
                <X size={18} />
              </button>
            </div>

            <MedicineQRCode
              medicine={medicine}
              lang={language}
              variant="card"
              size={180}
            />

            <div className="text-center pt-1">
              <button
                type="button"
                onClick={() => setShowQRModal(false)}
                className="px-6 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 transition cursor-pointer"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
