import React from 'react';
import { Pill, ChevronRight, ChevronLeft, ArrowLeftRight, Check } from 'lucide-react';
import { Medicine, Language } from '../types';
import { translations } from '../data/translations';
import { SpeakerButton } from './SpeakerButton';
import { MedicinePackagingVisual } from './MedicinePackagingVisual';

interface MedicineCardProps {
  medicine: Medicine;
  language: Language;
  onSelect: (medicine: Medicine) => void;
  currentSpeakingId: string | null;
  setCurrentSpeakingId: (id: string | null) => void;
  isCompared?: boolean;
  onToggleCompare?: (medicine: Medicine) => void;
  viewMode?: 'grid' | 'list';
}

export const MedicineCard: React.FC<MedicineCardProps> = ({
  medicine,
  language,
  onSelect,
  currentSpeakingId,
  setCurrentSpeakingId,
  isCompared = false,
  onToggleCompare,
  viewMode = 'grid',
}) => {
  const t = translations[language];
  const primaryName = medicine.name[language];
  const secondaryName = language === 'ar' ? medicine.name.en : medicine.name.ar;
  const genericName = medicine.genericName[language];
  const categoryLabel = t[medicine.category] || medicine.category;

  const categoryColorMap: Record<string, string> = {
    painkillers: 'bg-teal-50 text-teal-800 border-teal-200',
    antibiotics: 'bg-cyan-50 text-cyan-800 border-cyan-200',
    vitamins: 'bg-amber-50 text-amber-800 border-amber-200',
    chronic: 'bg-indigo-50 text-indigo-800 border-indigo-200',
    cold_flu: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    digestive: 'bg-purple-50 text-purple-800 border-purple-200',
  };

  const ArrowIcon = language === 'ar' ? ChevronLeft : ChevronRight;

  // COMPACT MOBILE LIST VIEW (Ultra-fast scrolling on phones)
  if (viewMode === 'list') {
    return (
      <div
        id={`medicine-row-${medicine.id}`}
        onClick={() => onSelect(medicine)}
        className={`group relative flex items-center justify-between p-3 sm:p-3.5 rounded-2xl bg-white border transition-all duration-200 cursor-pointer select-none active:scale-[0.99] ${
          isCompared
            ? 'ring-2 ring-teal-500 border-teal-500/80 shadow-md shadow-teal-500/10'
            : 'border-slate-200 hover:border-teal-400 hover:shadow-md'
        }`}
      >
        {/* Left: Mini Typographic Package & Names */}
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <div className="w-12 h-12 shrink-0 rounded-xl overflow-hidden shadow-2xs">
            <MedicinePackagingVisual medicine={medicine} language={language} size="sm" className="w-full h-full p-1.5" />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h4 className="font-bold text-sm sm:text-base text-slate-900 group-hover:text-teal-700 transition-colors truncate">
                {primaryName}
              </h4>
              <span className="text-[11px] text-slate-400 font-medium truncate">
                ({secondaryName})
              </span>
            </div>
            <p className="text-xs text-slate-500 truncate mt-0.5">
              {genericName} • <span className="font-semibold text-slate-700">{medicine.strength}</span>
            </p>
          </div>
        </div>

        {/* Right: Category badge, Audio, Compare & Arrow */}
        <div className="flex items-center gap-2 shrink-0 ps-2" onClick={(e) => e.stopPropagation()}>
          <span
            className={`hidden md:inline-block px-2 py-0.5 rounded-md text-[11px] font-semibold border ${
              categoryColorMap[medicine.category] || 'bg-slate-50 text-slate-700 border-slate-200'
            }`}
          >
            {categoryLabel}
          </span>

          <SpeakerButton
            id={`speaker-list-${medicine.id}`}
            nameToSpeak={medicine.audioEnglishText || medicine.name.en}
            lang="en"
            forceLang="en"
            rate={0.85}
            activeMedicineId={medicine.id}
            currentSpeakingId={currentSpeakingId}
            setCurrentSpeakingId={setCurrentSpeakingId}
            title={language === 'ar' ? `استمع لنطق ${medicine.name.en}` : 'Pronounce in English'}
            className="p-1.5 rounded-lg bg-slate-100 hover:bg-teal-50 text-slate-700 hover:text-teal-700 transition-colors"
          />

          {onToggleCompare && (
            <button
              type="button"
              onClick={() => onToggleCompare(medicine)}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                isCompared
                  ? 'bg-teal-600 text-white border-teal-500'
                  : 'bg-slate-100 hover:bg-white text-slate-600 hover:text-teal-700 border-slate-200'
              }`}
              title={isCompared ? t.removeFromCompare : t.addToCompare}
            >
              {isCompared ? <Check className="w-3.5 h-3.5 stroke-[2.5]" /> : <ArrowLeftRight className="w-3.5 h-3.5" />}
            </button>
          )}

          <button
            type="button"
            onClick={() => onSelect(medicine)}
            className="p-1.5 rounded-lg text-slate-400 group-hover:text-teal-600 transition-colors cursor-pointer"
            aria-label={t.viewDetails}
          >
            <ArrowIcon className="w-5 h-5 transform transition-transform group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5" />
          </button>
        </div>
      </div>
    );
  }

  // COMPACT CARD GRID VIEW (Optimized for effortless mobile scrolling)
  return (
    <div
      id={`medicine-card-${medicine.id}`}
      onClick={() => onSelect(medicine)}
      className={`group relative flex flex-col justify-between rounded-2xl bg-white border shadow-xs hover:shadow-lg transition-all duration-200 overflow-hidden cursor-pointer select-none active:scale-[0.99] ${
        isCompared
          ? 'ring-2 ring-teal-500 border-teal-500/80 shadow-md shadow-teal-500/10'
          : 'border-slate-200 hover:border-teal-300'
      }`}
    >
      {/* Visual Typographic Medication Package: Displays Medicine Name clearly on the package without photos! */}
      <MedicinePackagingVisual medicine={medicine} language={language} size="md" />

      {/* Compact Card Content Body (Free from heavy paragraphs so scrolling is light and quick) */}
      <div className="p-3.5 sm:p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          {/* Active substance & Category Row */}
          <div className="flex items-center justify-between gap-2">
            <span
              className={`px-2 py-0.5 rounded-md text-[11px] font-semibold border ${
                categoryColorMap[medicine.category] || 'bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              {categoryLabel}
            </span>

            {/* English Phonetic Tag */}
            <span className="font-mono text-[10px] font-semibold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200 truncate max-w-[140px]">
              🗣️ {medicine.englishPhonetic}
            </span>
          </div>

          {/* Generic Name */}
          <div className="mt-2 text-xs font-medium text-slate-700 line-clamp-1">
            <span className="text-slate-400">{t.activeIngredient}: </span>
            <span className="text-teal-800 font-semibold">{genericName}</span>
          </div>
        </div>

        {/* Action Controls Footer */}
        <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {/* Audio pronunciation speaker */}
            <SpeakerButton
              id={`speaker-btn-en-${medicine.id}`}
              nameToSpeak={medicine.audioEnglishText || medicine.name.en}
              lang="en"
              forceLang="en"
              rate={0.85}
              title={language === 'ar' ? `استمع للنطق الإنجليزي: ${medicine.name.en}` : 'Pronounce in English'}
              activeMedicineId={medicine.id}
              currentSpeakingId={currentSpeakingId}
              setCurrentSpeakingId={setCurrentSpeakingId}
              className="p-1.5 rounded-lg bg-slate-100 hover:bg-teal-50 text-slate-700 hover:text-teal-700 transition-colors cursor-pointer"
            />

            {/* Compare toggle button */}
            {onToggleCompare && (
              <button
                type="button"
                onClick={() => onToggleCompare(medicine)}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                  isCompared
                    ? 'bg-teal-600 text-white border-teal-500'
                    : 'bg-slate-100 hover:bg-white text-slate-700 hover:text-teal-700 border-slate-200'
                }`}
                title={isCompared ? t.removeFromCompare : t.addToCompare}
              >
                {isCompared ? <Check className="w-3.5 h-3.5 stroke-[2.5]" /> : <ArrowLeftRight className="w-3.5 h-3.5" />}
                <span className="hidden sm:inline">{isCompared ? (language === 'ar' ? 'محدد' : 'Selected') : t.compare}</span>
              </button>
            )}
          </div>

          {/* View Details button */}
          <button
            type="button"
            onClick={() => onSelect(medicine)}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-teal-700 bg-teal-50 group-hover:bg-teal-600 group-hover:text-white transition-all cursor-pointer shadow-2xs"
          >
            <span>{t.viewDetails}</span>
            <ArrowIcon className="w-3.5 h-3.5 transform transition-transform group-hover:translate-x-0.5 rtl:group-hover:-translate-x-0.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
