import React, { useEffect, useState } from 'react';
import { QrCode, Copy, Check, Download, ExternalLink, Smartphone } from 'lucide-react';
import { Medicine, Language } from '../types';
import { translations } from '../data/translations';
import { generateQRCodeDataUrl, getMedicineUrl } from '../utils/qrcode';

interface MedicineQRCodeProps {
  medicine: Medicine;
  lang: Language;
  variant?: 'card' | 'print' | 'modal' | 'compact';
  size?: number;
  className?: string;
  showActions?: boolean;
}

export const MedicineQRCode: React.FC<MedicineQRCodeProps> = ({
  medicine,
  lang,
  variant = 'card',
  size,
  className = '',
  showActions = true,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  const t = translations[lang];
  const medicineUrl = getMedicineUrl(medicine.id);

  const defaultSize = variant === 'print' ? 100 : variant === 'compact' ? 120 : 160;
  const qrSize = size ?? defaultSize;

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    generateQRCodeDataUrl(medicineUrl, {
      width: qrSize * 2, // 2x for retina / sharp print resolution
      margin: 1,
      darkColor: '#0f172a',
      lightColor: '#ffffff',
    }).then((dataUrl) => {
      if (isMounted) {
        setQrDataUrl(dataUrl);
        setLoading(false);
      }
    });

    return () => {
      isMounted = false;
    };
  }, [medicine.id, medicineUrl, qrSize]);

  const handleCopyLink = async () => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(medicineUrl);
      } else {
        // Fallback for older browsers / iframe restrictions
        const textarea = document.createElement('textarea');
        textarea.value = medicineUrl;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      console.error('Failed to copy link:', err);
    }
  };

  const handleDownloadQR = () => {
    if (!qrDataUrl) return;
    const link = document.createElement('a');
    link.href = qrDataUrl;
    link.download = `${medicine.id}-qrcode.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // PRINT VARIANT: Designed specifically for crisp physical A4 print rendering
  if (variant === 'print') {
    return (
      <div
        className={`flex items-center gap-3 p-2.5 bg-white border-2 border-slate-300 rounded-xl max-w-[280px] ${className}`}
        dir={lang === 'ar' ? 'rtl' : 'ltr'}
      >
        <div className="shrink-0 bg-white p-1 rounded-lg border border-slate-200">
          {qrDataUrl ? (
            <img
              src={qrDataUrl}
              alt={`QR code for ${medicine.name[lang]}`}
              width={qrSize}
              height={qrSize}
              className="block aspect-square object-contain"
            />
          ) : (
            <div
              style={{ width: qrSize, height: qrSize }}
              className="bg-slate-100 animate-pulse flex items-center justify-center text-slate-400"
            >
              <QrCode size={32} />
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0 text-start">
          <div className="flex items-center gap-1 text-[11px] font-bold text-teal-900 mb-0.5">
            <Smartphone size={13} className="text-teal-700 shrink-0" />
            <span>{t.quickAccessOnMobile}</span>
          </div>
          <p className="text-[10px] text-slate-600 leading-snug font-medium mb-1">
            {t.scanWithMobile}
          </p>
          <span className="block text-[8px] font-mono text-slate-400 truncate max-w-[150px]">
            {medicineUrl.replace(/^https?:\/\//, '')}
          </span>
        </div>
      </div>
    );
  }

  // CARD VARIANT: For embedding inside MedicineDetailModal
  return (
    <div
      id={`medicine-qr-container-${medicine.id}`}
      className={`rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-teal-950 text-white p-4 sm:p-5 shadow-md border border-slate-700/60 ${className}`}
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
    >
      <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
        {/* The QR Code Graphic Frame */}
        <div className="relative shrink-0 p-2.5 bg-white rounded-2xl shadow-lg shadow-black/20 border-2 border-teal-400/50 group">
          {loading || !qrDataUrl ? (
            <div
              style={{ width: qrSize, height: qrSize }}
              className="bg-slate-100 rounded-xl animate-pulse flex items-center justify-center text-slate-400"
            >
              <QrCode size={36} />
            </div>
          ) : (
            <img
              src={qrDataUrl}
              alt={`QR Code for ${medicine.name[lang]}`}
              width={qrSize}
              height={qrSize}
              className="block rounded-lg aspect-square object-contain"
            />
          )}

          <div className="absolute -bottom-2 inset-x-0 flex justify-center pointer-events-none">
            <span className="px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider bg-teal-600 text-white rounded-full shadow-xs">
              JFDA • QR
            </span>
          </div>
        </div>

        {/* Informative details & actions */}
        <div className="flex-1 min-w-0 text-center sm:text-start space-y-2.5">
          <div className="space-y-1">
            <div className="flex items-center justify-center sm:justify-start gap-1.5 text-xs font-bold text-teal-300">
              <Smartphone size={15} />
              <span>{t.qrCodeTitle}</span>
            </div>
            <h4 className="text-base font-bold text-slate-100">
              {medicine.name[lang]}
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              {t.qrCodeSubtitle}
            </p>
          </div>

          {/* URL preview */}
          <div className="px-3 py-1.5 bg-slate-950/60 rounded-xl border border-slate-700/80 text-[11px] font-mono text-teal-300/90 truncate max-w-full">
            {medicineUrl}
          </div>

          {/* Interactive buttons */}
          {showActions && (
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
              <button
                id={`copy-med-link-btn-${medicine.id}`}
                type="button"
                onClick={handleCopyLink}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer ${
                  copied
                    ? 'bg-emerald-600 text-white'
                    : 'bg-teal-500 hover:bg-teal-400 text-slate-950 active:scale-95'
                }`}
                title={t.copyMedicineLink}
              >
                {copied ? <Check size={14} className="stroke-[2.5]" /> : <Copy size={14} />}
                <span>{copied ? t.linkCopied : t.copyMedicineLink}</span>
              </button>

              <button
                id={`download-med-qr-btn-${medicine.id}`}
                type="button"
                onClick={handleDownloadQR}
                disabled={!qrDataUrl}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-all cursor-pointer disabled:opacity-50"
                title={t.downloadQR}
              >
                <Download size={14} />
                <span>{t.downloadQR}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
