import { Language } from '../types';

export interface Translations {
  appTitle: string;
  appSubtitle: string;
  badgeGov: string;
  switchLang: string;
  searchPlaceholder: string;
  clearSearch: string;
  allCategories: string;
  painkillers: string;
  antibiotics: string;
  vitamins: string;
  chronic: string;
  cold_flu: string;
  digestive: string;
  resultsCount: (count: number) => string;
  noResultsTitle: string;
  noResultsDesc: string;
  resetFilters: string;
  listenTooltip: string;
  speakingTooltip: string;
  viewDetails: string;
  activeIngredient: string;
  dosageForm: string;
  manufacturer: string;
  origin: string;
  prescriptionRequired: string;
  otcAvailable: string;
  fullDescription: string;
  scientificComposition: string;
  benefitsAndIndications: string;
  sideEffectsAndComplications: string;
  dosageAndUsage: string;
  warningsAndPrecautions: string;
  storageInstructions: string;
  approxPrice: string;
  medicalDisclaimerTitle: string;
  medicalDisclaimer: string;
  close: string;
  printLeaflet: string;
  printOfficialMonograph: string;
  printPreviewTitle: string;
  printNow: string;
  quickFacts: string;
  safetySummary: string;
  emergencyHotline: string;
  emergencyNumber: string;
  ministryOfHealth: string;
  compare: string;
  compareMedicines: string;
  compareSubtitle: string;
  addToCompare: string;
  removeFromCompare: string;
  compareBarSelected: (count: number) => string;
  compareNow: string;
  clearAllCompare: string;
  selectSecondMedicine: string;
  selectMedicinePlaceholder: string;
  maxCompareReached: string;
  featuresComparison: string;
  keyDifferences: string;
  swapMedicines: string;
  // New pronunciation & print features
  englishPronunciation: string;
  listenEnglish: string;
  listenArabic: string;
  pronounceBoth: string;
  safeDosageCalculator: string;
  maxDailyLimit: string;
  patientName: string;
  dateDispensed: string;
  pharmacistSignature: string;
  doctorNotes: string;
  patientInstructions: string;
  jfdaRefNumber: string;
  pregnancyRisk: string;
  printA4Help: string;
  qrCodeTitle: string;
  qrCodeSubtitle: string;
  scanWithMobile: string;
  copyMedicineLink: string;
  linkCopied: string;
  downloadQR: string;
  qrDirectAccess: string;
  quickAccessOnMobile: string;
}

export const translations: Record<Language, Translations> = {
  ar: {
    appTitle: 'دليل الأدوية الأردني',
    appSubtitle: 'المرجع الطبي الموثوق للأدوية والتركيبات العلمية ودواعي الاستعمال المتداولة في الصيدليات الأردنية',
    badgeGov: 'المملكة الأردنية الهاشمية • دليل الأدوية المعتمدة (JFDA)',
    switchLang: 'English (LTR)',
    searchPlaceholder: 'ابحث باسم الدواء (عربي/إنجليزي)، المادة الفعالة، أو دواعي الاستعمال...',
    clearSearch: 'مسح البحث',
    allCategories: 'جميع الأدوية',
    painkillers: 'مسكنات وخافضات حرارة',
    antibiotics: 'المضادات الحيوية',
    vitamins: 'فيتامينات ومكملات',
    chronic: 'أدوية الضغط والسكري',
    cold_flu: 'الزكام والحساسية',
    digestive: 'المعدة والجهاز الهضمي',
    resultsCount: (count) => `تم العثور على ${count} دواء مسجل`,
    noResultsTitle: 'لم يتم العثور على أدوية مطابقة',
    noResultsDesc: 'يرجى التأكد من كتابة الاسم بدقة، أو مسح كلمات البحث لتصفح القائمة كاملة.',
    resetFilters: 'إعادة ضبط البحث والتصنيف',
    listenTooltip: 'استمع إلى النطق الصوتي الصحيح',
    speakingTooltip: 'جاري القراءة الصوتية...',
    viewDetails: 'عرض التفاصيل الطبية الكاملة',
    activeIngredient: 'التركيبة الفعالة',
    dosageForm: 'الشكل الصيدلاني',
    manufacturer: 'الشركة المصنعة',
    origin: 'بلد المنشأ والاعتماد',
    prescriptionRequired: 'يتطلب وصفة طبية (Rx)',
    otcAvailable: 'متوفر دون وصفة (OTC)',
    fullDescription: 'وصف الدواء والمعلومات العامة',
    scientificComposition: 'التركيبة العلمية والمكونات الفعالة',
    benefitsAndIndications: 'الفوائد ودواعي الاستعمال',
    sideEffectsAndComplications: 'الأعراض الجانبية والمضاعفات المحتملة',
    dosageAndUsage: 'الجرعة المقررة وطريقة الاستخدام',
    warningsAndPrecautions: 'التحذيرات وموانع الاستخدام',
    storageInstructions: 'ظروف الحفظ والتخزين السليم',
    approxPrice: 'السعر التقريبي بالصيدليات',
    medicalDisclaimerTitle: 'تنويه وإرشاد طبي رسمي',
    medicalDisclaimer: 'المعلومات الواردة في هذا الدليل مخصصة للأغراض التثقيفية والمعرفية فقط. لا تغني أبداً عن الاستشارة الطبية المباشرة من الطبيب أو الصيدلاني في الأردن.',
    close: 'إغلاق النافذة',
    printLeaflet: 'طباعة النشرة الطبية',
    printOfficialMonograph: 'طباعة نشرة الدواء المعتمدة (A4)',
    printPreviewTitle: 'معاينة النشرة الطبية الجاهزة للطباعة',
    printNow: 'إرسال إلى الطابعة / حفظ كـ PDF',
    quickFacts: 'بطاقة الدواء السريعة',
    safetySummary: 'إرشادات السلامة للمريض',
    emergencyHotline: 'طوارئ التسمم الدوائي (الأردن)',
    emergencyNumber: '193 / الدفاع المدني 911',
    ministryOfHealth: 'متوافق مع معايير المؤسسة العامة للغذاء والدواء (JFDA)',
    compare: 'مقارنة',
    compareMedicines: 'مقارنة الأدوية جنباً إلى جنب',
    compareSubtitle: 'مقارنة تفصيلية دقيقة بين دوائين تشمل التركيبة العلمية، دواعي الاستعمال، الأعراض الجانبية والأسعار',
    addToCompare: 'إضافة للمقارنة',
    removeFromCompare: 'إزالة من المقارنة',
    compareBarSelected: (count) => `تم اختيار ${count} من أصل 2 للمقارنة`,
    compareNow: 'مقارنة الدوائين الآن',
    clearAllCompare: 'إلغاء التحديد',
    selectSecondMedicine: 'اختر دواءً ثانياً للمقارنة',
    selectMedicinePlaceholder: 'اختر دواءً لإضافته للمقارنة...',
    maxCompareReached: 'يمكنك اختيار دوائين كحد أقصى للمقارنة في المرة الواحدة',
    featuresComparison: 'مقارنة الخصائص والتركيب',
    keyDifferences: 'فروقات علاجية هامة',
    swapMedicines: 'تبديل الترتيب',
    englishPronunciation: 'النطق الإنجليزي الصحيح حرفياً',
    listenEnglish: 'استمع بالإنجليزية الفصيحة',
    listenArabic: 'استمع بالعربية',
    pronounceBoth: 'النطق الصوتي ثنائي اللغة',
    safeDosageCalculator: 'حاسبة الجرعة والحد اليومي الآمن',
    maxDailyLimit: 'الحد الأقصى اليومي المسموح به',
    patientName: 'اسم المريض',
    dateDispensed: 'تاريخ الصرف',
    pharmacistSignature: 'ختم وتوقيع الصيدلاني المرخص',
    doctorNotes: 'ملاحظات الطبيب المعالج / الصيدلي',
    patientInstructions: 'إرشادات الجرعة المقررة للمريض',
    jfdaRefNumber: 'رقم التسجيل الدوائي (JFDA)',
    pregnancyRisk: 'فئة الأمان أثناء الحمل',
    printA4Help: 'تصميم عالي الوضوح مخصص لطباعة ورقة مقاس A4 متوافقة مع متطلبات الصيدليات والعيادات',
    qrCodeTitle: 'رمز الاستجابة السريعة (QR Code)',
    qrCodeSubtitle: 'امسح الرمز بكاميرا هاتفك المحمول لفتح بطاقة الدواء المباشرة في أي وقت',
    scanWithMobile: 'امسح بواسطة كاميرا الهاتف للوصول السريع',
    copyMedicineLink: 'نسخ رابط الدواء',
    linkCopied: 'تم نسخ الرابط بنجاح!',
    downloadQR: 'تنزيل رمز QR',
    qrDirectAccess: 'رمز QR المباشر لبطاقة الدواء',
    quickAccessOnMobile: 'الوصول السريع عبر الهاتف الذكي',
  },
  en: {
    appTitle: 'Jordanian Medicine Directory',
    appSubtitle: 'The comprehensive medical directory for registered pharmaceutical products, scientific compositions, and patient guidance across Jordan.',
    badgeGov: 'Hashemite Kingdom of Jordan • JFDA Registered Reference',
    switchLang: 'العربية (RTL)',
    searchPlaceholder: 'Search by brand name, active generic ingredient, or indication...',
    clearSearch: 'Clear search',
    allCategories: 'All Medications',
    painkillers: 'Painkillers & Antipyretics',
    antibiotics: 'Antibiotics',
    vitamins: 'Vitamins & Supplements',
    chronic: 'Hypertension & Diabetes',
    cold_flu: 'Cold, Flu & Allergy',
    digestive: 'Digestive & Stomach',
    resultsCount: (count) => `${count} registered medication${count === 1 ? '' : 's'} found`,
    noResultsTitle: 'No matching medications found',
    noResultsDesc: 'Try checking your spelling, using generic drug names, or resetting your filter choices.',
    resetFilters: 'Reset filters & search',
    listenTooltip: 'Listen to native pronunciation',
    speakingTooltip: 'Speaking aloud...',
    viewDetails: 'View Full Medication Details',
    activeIngredient: 'Active Substance',
    dosageForm: 'Dosage Form',
    manufacturer: 'Manufacturer',
    origin: 'Country of Origin / Registration',
    prescriptionRequired: 'Prescription Required (Rx)',
    otcAvailable: 'Over the Counter (OTC)',
    fullDescription: 'Medication Description',
    scientificComposition: 'Active Ingredients & Composition',
    benefitsAndIndications: 'Benefits & Indications',
    sideEffectsAndComplications: 'Side Effects & Potential Complications',
    dosageAndUsage: 'Dosage & Directions for Use',
    warningsAndPrecautions: 'Warnings & Clinical Precautions',
    storageInstructions: 'Storage & Handling Conditions',
    approxPrice: 'Approximate Pharmacy Price',
    medicalDisclaimerTitle: 'Official Medical Disclaimer',
    medicalDisclaimer: 'The medical information provided is strictly for educational and informational purposes. Always consult a licensed physician or pharmacist in Jordan before taking any pharmaceutical product.',
    close: 'Close Window',
    printLeaflet: 'Print Patient Leaflet',
    printOfficialMonograph: 'Print Official Drug Monograph (A4)',
    printPreviewTitle: 'Print-Ready Clinical Monograph Preview',
    printNow: 'Print Now / Save as PDF',
    quickFacts: 'Quick Drug Facts',
    safetySummary: 'Patient Safety Guidelines',
    emergencyHotline: 'Jordan Poison Control Hotline',
    emergencyNumber: '193 / Civil Defense 911',
    ministryOfHealth: 'In accordance with Jordan FDA (JFDA) standards',
    compare: 'Compare',
    compareMedicines: 'Side-by-Side Medicine Comparison',
    compareSubtitle: 'Detailed clinical comparison of active ingredients, indications, side effects, and pricing between two medications',
    addToCompare: 'Add to Compare',
    removeFromCompare: 'Remove from Compare',
    compareBarSelected: (count) => `${count} of 2 medications selected for comparison`,
    compareNow: 'Compare Side-by-Side',
    clearAllCompare: 'Clear Selection',
    selectSecondMedicine: 'Select a second medication to compare',
    selectMedicinePlaceholder: 'Choose a medication to compare...',
    maxCompareReached: 'You can compare up to two medicines at a time',
    featuresComparison: 'Features & Composition Comparison',
    keyDifferences: 'Key Clinical Differences',
    swapMedicines: 'Swap Order',
    englishPronunciation: 'Literal English Pronunciation',
    listenEnglish: 'Listen in English (Medical)',
    listenArabic: 'Listen in Arabic',
    pronounceBoth: 'Bilingual Audio Pronunciation',
    safeDosageCalculator: 'Daily Limit & Safe Dose Checker',
    maxDailyLimit: 'Maximum Safe Daily Allowance',
    patientName: 'Patient Name',
    dateDispensed: 'Date Dispensed',
    pharmacistSignature: 'Licensed Pharmacist Signature & Stamp',
    doctorNotes: 'Physician / Pharmacist Notes',
    patientInstructions: 'Patient Administration Directions',
    jfdaRefNumber: 'JFDA Registration No.',
    pregnancyRisk: 'Pregnancy Safety Class',
    printA4Help: 'Clean, high-contrast A4 print layout formatted for pharmacies, hospitals, and patient records',
    qrCodeTitle: 'Quick Access QR Code',
    qrCodeSubtitle: 'Scan with your mobile camera to open this medicine directly anytime',
    scanWithMobile: 'Scan with mobile camera for quick access',
    copyMedicineLink: 'Copy Medicine Link',
    linkCopied: 'Link copied to clipboard!',
    downloadQR: 'Download QR Code',
    qrDirectAccess: 'Direct Medicine QR Code',
    quickAccessOnMobile: 'Quick Access on Mobile Device',
  },
};
