import { Medicine } from '../types';
import { generateFullOTCDirectory } from './otcCatalog';

const FLAGSHIP_MEDICINES: Medicine[] = [
  {
    id: 'revanin',
    name: {
      en: 'Revanin',
      ar: 'ريفانين',
    },
    genericName: {
      en: 'Paracetamol',
      ar: 'باراسيتامول (أسيتامينوفين)',
    },
    englishPhonetic: '[REV-uh-nin]',
    englishPronunciationGuide: {
      en: 'Pronounced as: REV-uh-nin (Stress on first syllable)',
      ar: 'يُنطق بالإنجليزية: رِف-اَ-نِن مع نبرة على المقطع الأول',
    },
    audioEnglishText: 'Revanin. Active ingredient: Paracetamol five hundred milligrams.',
    category: 'painkillers',
    dosageForm: {
      en: 'Film-Coated Tablets & Syrup',
      ar: 'أقراص مغلفة وشراب معلق',
    },
    strength: '500 mg',
    manufacturer: {
      en: 'The Arab Pharmaceutical Manufacturing (APM) / Hikma',
      ar: 'الشركة العربية لصناعة الأدوية (APM) / الحكمة',
    },
    origin: {
      en: 'Jordan (Al-Salt / Amman)',
      ar: 'الأردن (السلط / عمّان)',
    },
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-emerald-500 to-teal-700',
    approxPriceJOD: '0.75 - 1.20 JOD',
    barcode: '6251004100128',
    jfdaRegistrationNumber: 'JFDA-DRG-01124/JO',
    pregnancyRiskCategory: 'Category B - Safe under physician advice',
    maxSafeDailyDose: {
      en: '4,000 mg (8 tablets) maximum within 24 hours',
      ar: '4000 ملغم (8 أقراص) كحد أقصى خلال 24 ساعة',
    },
    description: {
      en: 'Revanin is one of the most widely used and trusted pain-relieving and antipyretic medications manufactured locally in Jordan. It provides fast and effective relief from mild to moderate pain and reduces high fever with minimal gastric irritation.',
      ar: 'ريفانين هو أحد أشهر وأعرق الأدوية المسكنة للألم والخافضة للحرارة المصنعة محلياً في الأردن. يتميز بفعاليته السريعة في تخفيف الآلام الخفيفة إلى المتوسطة وخفض درجة الحرارة دون التسبب في تهيج جدار المعدة.',
    },
    activeIngredients: {
      en: ['Paracetamol (Acetaminophen) 500 mg per tablet', 'Microcrystalline cellulose, povidone, magnesium stearate'],
      ar: ['باراسيتامول (أسيتامينوفين) بتركيز 500 ملغم لكل قرص', 'سليلوز دقيق التبلور، بوفيدون، ستيرات المغنيسيوم كمواد سواغ'],
    },
    benefitsAndIndications: {
      en: [
        'Relief of mild to moderate headache and migraine pain.',
        'Effective reduction of fever associated with common colds and viral infections.',
        'Alleviation of toothaches, post-dental extraction discomfort, and gum inflammation.',
        'Easing musculoskeletal pains, backache, and osteoarthritis stiffness.',
        'Safe first-line analgesic during pregnancy (under physician guidance).',
      ],
      ar: [
        'تسكين الصداع العادي والصداع النصفي (الشقيقة).',
        'تخفيض درجات الحرارة المرتفعة المصاحبة لنزلات البرد والإنفلونزا والعدوى الفيروسية.',
        'تسكين آلام الأسنان، وبعد العمليات الجراحية السنية، والتهاب اللثة.',
        'علاج آلام العضلات والمفاصل وآلام الظهر والفقرات.',
        'مسكن آمن ومفضل خلال فترات الحمل والرضاعة (تحت إشراف طبي).',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Generally very well tolerated at therapeutic dosages.',
        'Rare: Skin rash, urticaria, or allergic hypersensitivity.',
        'Severe (at overdose): Acute hepatic necrosis and liver toxicity.',
        'Caution: Chronic high doses may affect renal function.',
      ],
      ar: [
        'جيد التحمل بشكل ممتاز ونادر الأعراض عند الالتزام بالجرعات الدوائية الموصى بها.',
        'نادر: طفح جلدي خفيف، حكة، أو تحسس جلدي.',
        'خطير (عند الجرعات الزائدة): قصور كبدي حاد وتسمم في خلايا الكبد.',
        'تحذير: الاستهلاك المفرط والمستمر قد يؤثر على وظائف الكلى.',
      ],
    },
    dosageAndUsage: {
      en: 'Adults and children over 12 years: 1 to 2 tablets (500mg - 1000mg) every 4 to 6 hours as needed. Maximum daily dose must not exceed 4,000 mg (8 tablets) within 24 hours. Can be taken with or without food.',
      ar: 'للبالغين والأطفال فوق سن 12 عاماً: قرص إلى قرصين (500 - 1000 ملغم) كل 4 إلى 6 ساعات عند الحاجة. يجب ألا تتجاوز الجرعة القصوى 4000 ملغم (8 أقراص) خلال 24 ساعة. يمكن تناوله مع الطعام أو على معدة فارغة.',
    },
    warningsAndPrecautions: {
      en: [
        'Do not take simultaneously with other medications containing paracetamol to prevent accidental overdose.',
        'Patients with chronic hepatic impairment or severe renal impairment should consult their physician.',
        'Keep out of reach of children.',
      ],
      ar: [
        'يمنع تناوله تزامناً مع أي مستحضرات دوائية أخرى تحتوي على الباراسيتامول لتجنب الجرعة الزائدة.',
        'يجب استشارة الطبيب لمرضى القصور الكبدي أو الفشل الكلوي المزمن قبل الاستخدام.',
        'يحفظ بعيداً عن متناول أيدي الأطفال.',
      ],
    },
    storage: {
      en: 'Store below 25°C in a dry place, away from direct sunlight and moisture.',
      ar: 'يحفظ في مكان جاف في درجة حرارة أقل من 25 مئوية، بعيداً عن أشعة الشمس المباشرة والرطوبة.',
    },
  },
  {
    id: 'cataflam',
    name: {
      en: 'Cataflam',
      ar: 'كاتافلام',
    },
    genericName: {
      en: 'Diclofenac Potassium',
      ar: 'ديكلوفيناك البوتاسيوم',
    },
    englishPhonetic: '[KAT-uh-flam]',
    englishPronunciationGuide: {
      en: 'Pronounced as: KAT-uh-flam (rhymes with cat - a - flam)',
      ar: 'يُنطق بالإنجليزية: كَات-اَ-فلام بسرعة وانسيابية',
    },
    audioEnglishText: 'Cataflam. Active ingredient: Diclofenac potassium fifty milligrams.',
    category: 'painkillers',
    dosageForm: {
      en: 'Sugar-Coated Rapid Action Tablets',
      ar: 'أقراص ملبسة سريعة التحرر والتسكين',
    },
    strength: '50 mg',
    manufacturer: {
      en: 'Novartis Pharma / Distributed in Jordan',
      ar: 'نوفارتس العالمية / توزيع وكلاء الأردن المعتمدين',
    },
    origin: {
      en: 'Switzerland / Registered in Jordan Pharmacies',
      ar: 'سويسرا / معتمد ومتداول في صيدليات الأردن',
    },
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-rose-500 to-red-700',
    approxPriceJOD: '2.85 - 3.40 JOD',
    barcode: '7680506370198',
    jfdaRegistrationNumber: 'JFDA-DRG-03481/JO',
    pregnancyRiskCategory: 'Category C (Avoid in 3rd trimester)',
    maxSafeDailyDose: {
      en: '150 mg (3 tablets) maximum in 24 hours',
      ar: '150 ملغم (3 أقراص) كحد أقصى خلال 24 ساعة',
    },
    description: {
      en: 'Cataflam contains diclofenac potassium, a fast-absorbing non-steroidal anti-inflammatory drug (NSAID). Highly popular in Jordan for rapid dental toothache relief, sudden migraines, acute menstrual pain, and post-traumatic soft tissue inflammation.',
      ar: 'كاتافلام يحتوي على ديكلوفيناك البوتاسيوم سريع الامتصاص، وهو مسكن ألم ومضاد للالتهاب فائق السرعة. يفضله الأردنيون لتسكين آلام الأسنان الشديدة بعد الحشو أو الخلع، نوبات الصداع النصفي المفاجئة، وآلام الطمث الحادة.',
    },
    activeIngredients: {
      en: ['Diclofenac Potassium 50 mg per sugar-coated tablet', 'Calcium phosphate, maize starch, magnesium stearate'],
      ar: ['ديكلوفيناك البوتاسيوم 50 ملغم لكل قرص ملبس بالسكر', 'فوسفات الكالسيوم، نشاء الذرة، ستيرات المغنيسيوم'],
    },
    benefitsAndIndications: {
      en: [
        'Rapid relief of acute painful inflammatory conditions (dental pain, surgery, trauma).',
        'Acute migraine attacks with or without aura.',
        'Severe primary dysmenorrhea (menstrual cramps).',
        'Acute gout attacks and joint flare-ups.',
        'Sprains, strains, and sports-related tendon injuries.',
      ],
      ar: [
        'تسكين فوري وسريع للآلام الالتهابية الحادة (آلام الأسنان، بعد العمليات، والرضوض).',
        'علاج نوبات الشقيقة والصداع النصفي الحاد.',
        'علاج آلام وتقلصات الدورة الشهرية الحادة.',
        'نوبات النقرس الحادة والتهاب المفاصل الرثياني.',
        'التواء المفاصل والتمزق العضلي والتهاب الأوتار.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Gastric discomfort, heartburn, nausea, and abdominal fullness.',
        'Risk of gastric ulceration or bleeding with prolonged unmonitored use.',
        'Dizziness, mild headache, or lightheadedness.',
        'Contraindicated in active stomach ulcers or severe renal/cardiac failure.',
      ],
      ar: [
        'حرقة المعدة، عسر الهضم، غثيان، والشعور بامتلاء البطن.',
        'خطر حدوث قرحة هضمية أو نزيف في المعدة عند الاستخدام المطول غير المنضبط.',
        'دوار خفيف أو صداع عابر.',
        'ممنوع لمرضى قرحة المعدة النشطة أو القصور القلبي والكلوي المتقدم.',
      ],
    },
    dosageAndUsage: {
      en: 'Adults: 1 tablet (50 mg) two to three times daily. For acute pain, initial dose can be 100 mg followed by 50 mg every 8 hours. Take immediately after meals with plenty of water. Do not exceed 150 mg daily.',
      ar: 'للبالغين: قرص واحد (50 ملغم) مرتين إلى 3 مرات يومياً. في حالات الألم الشديد يمكن البدء بقرصين معاً ثم قرص كل 8 ساعات. يؤخذ مباشرة بعد وجبة الطعام مع كوب ماء كبير. لا تتجاوز 150 ملغم يومياً.',
    },
    warningsAndPrecautions: {
      en: [
        'Always take with food or milk to safeguard gastric mucosa.',
        'Do not combine with other NSAIDs (such as Profinal or Voltaren) to prevent gastric damage.',
        'Asthmatic patients should monitor for bronchospasm.',
      ],
      ar: [
        'يجب دائماً تناوله بعد الأكل أو مع كوب حليب لحماية جدار المعدة.',
        'يمنع الجمع بينه وبين مسكنات بروفينال أو فولتارين لتجنب مضاعفة الضرر على المعدة.',
        'يجب الحذر لمرضى الربو والحساسية الصدرية.',
      ],
    },
    storage: {
      en: 'Store below 30°C in a dry place away from heat and moisture.',
      ar: 'يحفظ بدرجة حرارة أقل من 30 مئوية في مكان جاف ومحمي من الرطوبة.',
    },
  },
  {
    id: 'panadol',
    name: {
      en: 'Panadol (Advance / Extra)',
      ar: 'بنادول (أدفانس / إكسترا)',
    },
    genericName: {
      en: 'Paracetamol with Optizorb',
      ar: 'باراسيتامول مع تقنية أوبتيزورب',
    },
    englishPhonetic: '[PAN-uh-dawl ad-VANS]',
    englishPronunciationGuide: {
      en: 'Pronounced as: PAN-uh-dawl (short "a" like pan)',
      ar: 'يُنطق بالإنجليزية: بَان-اَ-دول برقة وانسياب',
    },
    audioEnglishText: 'Panadol Advance. Active ingredient: Paracetamol five hundred milligrams with Optizorb.',
    category: 'painkillers',
    dosageForm: {
      en: 'Film-Coated Fast-Acting Tablets',
      ar: 'أقراص سريعة الامتصاص مغلفة',
    },
    strength: '500 mg (Regular) / 500mg + 65mg Caffeine (Extra)',
    manufacturer: {
      en: 'Haleon / GlaxoSmithKline Consumer Healthcare',
      ar: 'هاليون / جلاكسو سميث كلاين للرعاية الصحية',
    },
    origin: {
      en: 'Ireland / Distributed in Jordan Pharmacies',
      ar: 'إيرلندا / متوفر في جميع الصيدليات الأردنية',
    },
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1550572017-ed2300b0e5bc?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-blue-500 to-indigo-700',
    approxPriceJOD: '1.20 - 1.85 JOD',
    barcode: '5000347061218',
    jfdaRegistrationNumber: 'JFDA-DRG-01932/JO',
    pregnancyRiskCategory: 'Category B - Safe under physician advice',
    maxSafeDailyDose: {
      en: '4,000 mg (8 tablets) maximum within 24 hours',
      ar: '4000 ملغم (8 أقراص) كحد أقصى خلال 24 ساعة',
    },
    description: {
      en: 'Panadol Advance features patented Optizorb technology for rapid disintegration and absorption in the stomach within 5 minutes. Gentle on the stomach and effectively targets headaches, fever, and bodily aches without triggering gastric acid reflux.',
      ar: 'يتميز بنادول أدفانس بتقنية "أوبتيزورب" المبتكرة التي تضمن تفكك القرص وامتصاصه في المعدة خلال 5 دقائق فقط لتسكين فائق السرعة. لطيف جداً على المعدة ولا يسبب حموضة أو قرحة، ومناسب لمعظم المرضى وكبار السن.',
    },
    activeIngredients: {
      en: ['Paracetamol 500 mg per tablet', 'Optizorb disintegration complex (calcium carbonate, alginic acid)'],
      ar: ['باراسيتامول 500 ملغم لكل قرص', 'مركب أوبتيزورب المسرع للتحلل (كربونات الكالسيوم وحمض الألجينيك)'],
    },
    benefitsAndIndications: {
      en: [
        'Fast soothing of tension headaches and throbbing migraines.',
        'Body temperature reduction during fever and viral colds.',
        'Management of dysmenorrhea and period cramps.',
        'Relief of sore throat, sinus pressure, and muscular aches.',
        'Safe pain reliever for patients with prior history of peptic ulcers.',
      ],
      ar: [
        'تسكين سريع لصداع التوتر والشقيقة المزعجة.',
        'خفض الحرارة السريع والفعال أثناء نزلات البرد.',
        'تسكين آلام الدورة الشهرية وتقلصات الطمث لدى الإناث.',
        'تخفيف آلام الحلق واحتقان الجيوب وآلام العضلات.',
        'مسكن آمن ومثالي لمرضى قرحة المعدة والارتجاع المريئي.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Very safe when taken as indicated.',
        'Extremely rare: Thrombocytopenia or leukopenia with prolonged massive misuse.',
        'Allergic skin reactions in highly sensitive individuals.',
        'Overdose can lead to permanent hepatotoxicity.',
      ],
      ar: [
        'آمن جداً بدرجة عالية عند الالتزام بالجرعة المقررة.',
        'نادر للغاية: انخفاض الصفائح الدموية في حالات الاستخدام المفرط الطويل.',
        'حساسية جلدية طفيفة للأشخاص شديدي التحسس للمادة.',
        'الجرعات المفرطة تسبب أضراراً بالغة وتسمماً لخلايا الكبد.',
      ],
    },
    dosageAndUsage: {
      en: 'Adults and adolescents 12 years and older: 1 to 2 tablets swallowed with water every 4 to 6 hours as needed. Do not exceed 8 tablets (4000 mg) in 24 hours. Safe to consume on an empty stomach.',
      ar: 'للبالغين والمراهقين من سن 12 عاماً فما فوق: 1 إلى 2 قرص مع كوب من الماء كل 4 إلى 6 ساعات حسب الحاجة. يجب عدم تجاوز 8 أقراص (4000 ملغم) خلال 24 ساعة. آمن للتناول على معدة فارغة.',
    },
    warningsAndPrecautions: {
      en: [
        'Never combine with other paracetamol products or cold remedies containing acetaminophen.',
        'Consult a healthcare professional if symptoms persist beyond 3 consecutive days.',
      ],
      ar: [
        'لا تتناوله مع أدوية البرد والرشح الأخرى التي تحتوي على الباراسيتامول منعاً لازدواج الجرعة.',
        'استشر الطبيب أو الصيدلاني إذا استمرت الحرارة أو الألم لأكثر من 3 أيام متتالية.',
      ],
    },
    storage: {
      en: 'Store below 30°C in a dry environment away from heat.',
      ar: 'يحفظ في درجة حرارة الغرفة دون 30 مئوية في مكان جاف وبعيداً عن الحرارة.',
    },
  },
  {
    id: 'profinal',
    name: {
      en: 'Profinal',
      ar: 'بروفينال',
    },
    genericName: {
      en: 'Ibuprofen',
      ar: 'إيبوبروفين',
    },
    englishPhonetic: '[PRO-fy-nal]',
    englishPronunciationGuide: {
      en: 'Pronounced as: PRO-fy-nal (rhymes with professional / final)',
      ar: 'يُنطق بالإنجليزية: برُو-فاي-نال بمد الصوت',
    },
    audioEnglishText: 'Profinal. Active ingredient: Ibuprofen four hundred milligrams.',
    category: 'painkillers',
    dosageForm: {
      en: 'Sugar-Coated Tablets & Pediatric Suspension',
      ar: 'أقراص مغلفة بالسكر وشراب معلق للأطفال',
    },
    strength: '400 mg & 600 mg / 100mg per 5ml',
    manufacturer: {
      en: 'Julphar (Gulf Pharmaceutical Industries) / Widely Supplied in Jordan',
      ar: 'جلفار (الخليج للصناعات الدوائية) / متوفر في صيدليات ومستشفيات الأردن',
    },
    origin: {
      en: 'UAE / Fully Registered by JFDA (Jordan Food and Drug Administration)',
      ar: 'الإمارات / مسجل رسمياً لدى المؤسسة العامة للغذاء والدواء الأردنية',
    },
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-amber-500 to-rose-700',
    approxPriceJOD: '1.45 - 2.10 JOD',
    barcode: '6291100340112',
    jfdaRegistrationNumber: 'JFDA-DRG-02581/JO',
    pregnancyRiskCategory: 'Category C (Strictly avoid in 3rd trimester)',
    maxSafeDailyDose: {
      en: '1,200 mg OTC (up to 2,400 mg under direct medical supervision)',
      ar: '1200 ملغم للاستخدام الذاتي (وحتى 2400 ملغم تحت إشراف طبي)',
    },
    description: {
      en: 'Profinal is an anti-inflammatory drug (NSAID) with pronounced analgesic, anti-inflammatory, and antipyretic properties. Exceptionally effective in Jordan for inflammatory joint pain, dental surgery recovery, sports injuries, and dysmenorrhea.',
      ar: 'بروفينال هو دواء مضاد للالتهاب غير ستيرويدي (NSAID) يتميز بخصائص ثلاثية قوية: مسكن للألم، مضاد للالتهاب، وخافض للحرارة. يحظى بانتشار واسع في الأردن لعلاج التهاب المفاصل، آلام الأسنان الشديدة، الإصابات الرياضية، وآلام الطمث.',
    },
    activeIngredients: {
      en: ['Ibuprofen 400 mg (or 600 mg) per tablet', 'Lactose monohydrate, maize starch, colloidal silicon dioxide'],
      ar: ['إيبوبروفين 400 ملغم (أو 600 ملغم) لكل قرص', 'لاكتوز أحادي الهيدرات، نشاء الذرة، وسيليكا غروية'],
    },
    benefitsAndIndications: {
      en: [
        'Potent reduction of acute inflammation and edema in sprains and muscular injuries.',
        'Relief of moderate to severe dental pain and inflammation after tooth extraction.',
        'Primary dysmenorrhea (painful menstrual periods).',
        'Rheumatoid arthritis, osteoarthritis, and ankylosing spondylitis.',
        'Fever reduction when fever fails to respond to paracetamol alone.',
      ],
      ar: [
        'تخفيف الالتهاب الحاد والتورم الناتج عن الالتواءات والإصابات الرياضية.',
        'تسكين آلام الأسنان المتوسطة إلى الشديدة والتهاب العصب بعد خلع الضرس.',
        'علاج آلام وتقلصات الدورة الشهرية (عسر الطمث الأولي).',
        'التهاب المفاصل الروماتويدي والتهاب المفاصل التنكسي (الروماتيزم).',
        'خفض الحمى العالية التي لا تستجيب للباراسيتامول بمفرده.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Gastrointestinal irritation: Dyspepsia, heartburn, epigastric pain, and potential ulceration.',
        'Fluid retention, mild hypertension, or mild peripheral edema.',
        'Risk of bronchospasm in aspirin-sensitive asthmatic patients.',
        'Increased cardiovascular and renal risk with prolonged high-dose usage.',
      ],
      ar: [
        'اضطراب الجهاز الهضمي: حرقة المعدة، عسر الهضم، ألم فم المعدة، وخطر القرحة عند الاستخدام المزمن.',
        'احتباس السوائل بالجسم وارتفاع طفيف في ضغط الدم.',
        'خطر حدوث ضيق في التنفس لمرضى الربو الذين يعانون من حساسية الأسبرين.',
        'زيادة العبء على الكلى والقلب عند الاستخدام الطويل بجرعات عالية.',
      ],
    },
    dosageAndUsage: {
      en: 'Adults: 400 mg every 6 to 8 hours as required, preferably taken immediately after meals or with milk to safeguard stomach lining. Maximum daily dose is 1,200 mg for OTC self-medication (up to 2,400 mg under medical supervision).',
      ar: 'للبالغين: قرص واحد 400 ملغم كل 6 إلى 8 ساعات عند اللزوم، ويفضل تناوله مباشرة بعد الوجبات أو مع كوب حليب لحماية بطانة المعدة. الجرعة القصوى للاستخدام الشخصي 1200 ملغم يومياً (وتصل لـ 2400 ملغم فقط تحت إشراف الطبيب).',
    },
    warningsAndPrecautions: {
      en: [
        'Strictly avoid in active gastric or duodenal ulcers and gastrointestinal bleeding.',
        'Not recommended during the third trimester of pregnancy.',
        'Asthmatic patients must use caution due to risk of bronchospasm.',
      ],
      ar: [
        'ممنوع تماماً لمن يعانون من قرحة نشطة في المعدة أو الاثني عشر أو نزيف هضمي.',
        'لا ينصح باستخدامه خلال الثلث الأخير من الحمل.',
        'يجب الحذر لمرضى الربو والأزمة الصدرية.',
      ],
    },
    storage: {
      en: 'Store below 25°C away from humidity and direct heat.',
      ar: 'يحفظ في درجة حرارة أقل من 25 مئوية بعيداً عن الرطوبة والحرارة المباشرة.',
    },
  },
  {
    id: 'fludrex',
    name: {
      en: 'Fludrex',
      ar: 'فلودريكس',
    },
    genericName: {
      en: 'Paracetamol + Pseudoephedrine + Chlorpheniramine + Caffeine',
      ar: 'باراسيتامول + سودوإيفيدرين + كلورفينيرامين + كافيين',
    },
    englishPhonetic: '[FLOO-dreks]',
    englishPronunciationGuide: {
      en: 'Pronounced as: FLOO-dreks (Flu - drex)',
      ar: 'يُنطق بالإنجليزية: فلو-درِكس بوضوح تام',
    },
    audioEnglishText: 'Fludrex. Cold and flu remedy containing Paracetamol, Pseudoephedrine, Chlorpheniramine, and Caffeine.',
    category: 'cold_flu',
    dosageForm: {
      en: 'Film-Coated Tablets',
      ar: 'أقراص مغلفة',
    },
    strength: '500mg / 30mg / 2mg / 32mg',
    manufacturer: {
      en: 'The Arab Pharmaceutical Manufacturing (APM) / Hikma',
      ar: 'الشركة العربية لصناعة الأدوية (APM) / الحكمة',
    },
    origin: {
      en: 'Jordan (Al-Salt / Amman)',
      ar: 'الأردن (السلط / عمّان)',
    },
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-teal-600 to-emerald-800',
    approxPriceJOD: '1.15 - 1.60 JOD',
    barcode: '6251004100456',
    jfdaRegistrationNumber: 'JFDA-DRG-01490/JO',
    pregnancyRiskCategory: 'Category C (Avoid without physician consent)',
    maxSafeDailyDose: {
      en: '6 to 8 tablets max in 24 hours (due to pseudoephedrine and paracetamol)',
      ar: '6 إلى 8 أقراص كحد أقصى في 24 ساعة',
    },
    description: {
      en: 'Fludrex is the household multi-symptom cold and flu tablet formulated in Jordan. It combines four synergistic ingredients: paracetamol for pain/fever, pseudoephedrine for sinus decongestion, chlorpheniramine for runny nose and sneezing, and caffeine to reduce drowsiness.',
      ar: 'فلودريكس هو الدواء المنزلي الأشهر في الأردن لعلاج أعراض الإنفلونزا والرشح ونزلات البرد الشديدة. يجمع بين 4 مواد فعالة: باراسيتامول لتسكين الصداع وخفض الحرارة، سودوإيفيدرين لفتح انسداد الأنف والجيوب، كلورفينيرامين لوقف الرشح والعطاس، وكافيين لمنع النعاس.',
    },
    activeIngredients: {
      en: [
        'Paracetamol 500 mg (analgesic & antipyretic)',
        'Pseudoephedrine Hydrochloride 30 mg (nasal decongestant)',
        'Chlorpheniramine Maleate 2 mg (antihistamine for allergy & sneezing)',
        'Caffeine Anhydrous 32 mg (reduces fatigue and drowsiness)',
      ],
      ar: [
        'باراسيتامول 500 ملغم (مسكن للألم وخافض للحرارة)',
        'سودوإيفيدرين هيدروكلوريد 30 ملغم (مزيل لاحتقان وانسداد الأنف والجيوب)',
        'كلورفينيرامين ماليات 2 ملغم (مضاد للهستامين لوقف سيلان الأنف والعطاس)',
        'كافيين لامائي 32 ملغم (منبه لتنشيط الجسم ومقاومة الخمول)',
      ],
    },
    benefitsAndIndications: {
      en: [
        'Clearing blocked nasal passages and sinus congestion in acute colds.',
        'Relief of fever, shivering, and systemic body aches during influenza.',
        'Stopping excessive rhinorrhea (runny nose) and allergic sneezing.',
        'Relieving throbbing sinus pressure headaches.',
      ],
      ar: [
        'فتح انسداد الممرات الأنفية وتخفيف احتقان الجيوب الأنفية.',
        'خفض الحرارة وعلاج القشعريرة وتكسير العظام الناتج عن الإنفلونزا.',
        'وقف سيلان الأنف والعطاس المتكرر وإدماع العينين.',
        'تسكين صداع الجيوب الأنفية والضغط فوق الحاجبين.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'May cause mild drowsiness or alternatively insomnia if taken late at night.',
        'Elevated blood pressure or palpitations due to pseudoephedrine.',
        'Dry mouth, throat dryness, or mild urinary retention in elderly males.',
      ],
      ar: [
        'قد يسبب نعاساً خفيفاً أو على العكس أرقاً وخفقاناً إذا أخذ في وقت متأخر من الليل.',
        'ارتفاع طفيف في ضغط الدم أو تسارع ضربات القلب بسبب مزيل الاحتقان.',
        'جفاف بالفم والحلق وصعوبة مؤقتة في التبول لكبار السن.',
      ],
    },
    dosageAndUsage: {
      en: 'Adults and adolescents over 12: 1 to 2 tablets every 6 to 8 hours as needed. Maximum 8 tablets in 24 hours. Drink with a full glass of water.',
      ar: 'للبالغين والأطفال فوق 12 سنة: قرص إلى قرصين كل 6 إلى 8 ساعات عند الحاجة. لا تتجاوز 8 أقراص خلال 24 ساعة. يُشرب مع كوب ماء كامل.',
    },
    warningsAndPrecautions: {
      en: [
        'Contraindicated in severe uncontrolled hypertension or coronary artery disease.',
        'Caution when operating machinery or driving if drowsiness occurs.',
        'Do not take with other paracetamol medicines.',
      ],
      ar: [
        'يمنع لمرضى الضغط المرتفع غير المنضبط أو أمراض الشرايين التاجية.',
        'يجب الحذر عند القيادة أو تشغيل الآلات في حال الشعور بالنعاس.',
        'لا تتناوله مع أدوية باراسيتامول أخرى منعاً لمضاعفة الجرعة.',
      ],
    },
    storage: {
      en: 'Store below 25°C in a dry place away from sunlight.',
      ar: 'يحفظ بدرجة حرارة أقل من 25 مئوية في مكان جاف بعيداً عن أشعة الشمس.',
    },
  },
  {
    id: 'augmentin',
    name: {
      en: 'Augmentin',
      ar: 'أوجمنتين',
    },
    genericName: {
      en: 'Amoxicillin + Clavulanic Acid',
      ar: 'أموكسيسيلين + حمض الكلافولانيك',
    },
    englishPhonetic: '[AUG-men-tin]',
    englishPronunciationGuide: {
      en: 'Pronounced as: AUG-men-tin (stress on first syllable AUG)',
      ar: 'يُنطق بالإنجليزية: أوج-مِن-تِن مع تفخيم المقطع الأول',
    },
    audioEnglishText: 'Augmentin. Broad spectrum antibiotic combining Amoxicillin and Clavulanic Acid.',
    category: 'antibiotics',
    dosageForm: {
      en: 'Film-Coated Tablets & Oral Suspension',
      ar: 'أقراص مغلفة بغشاء ومعلق فموي',
    },
    strength: '1g (875 mg / 125 mg) & 625 mg',
    manufacturer: {
      en: 'GlaxoSmithKline (GSK) / Distributed by Jordanian Agents',
      ar: 'جلاكسو سميث كلاين (GSK) / توزيع الوكلاء المعتمدين في الأردن',
    },
    origin: {
      en: 'United Kingdom / Licensed Internationally',
      ar: 'المملكة المتحدة / مرخص ومتداول في الأردن',
    },
    prescriptionRequired: true,
    image: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-cyan-600 to-blue-800',
    approxPriceJOD: '7.80 - 9.50 JOD',
    barcode: '5000347012395',
    jfdaRegistrationNumber: 'JFDA-DRG-00892/JO',
    pregnancyRiskCategory: 'Category B - Used when clinically indicated',
    maxSafeDailyDose: {
      en: '1 tablet (1g) twice daily (every 12 hours) as prescribed',
      ar: 'قرص واحد (1 غرام) مرتين يومياً (كل 12 ساعة) حسب وصفة الطبيب',
    },
    description: {
      en: 'Augmentin is a broad-spectrum antibacterial antibiotic widely prescribed by Jordanian physicians and dentists. It combines amoxicillin with clavulanic acid, an enzyme inhibitor that overcomes bacterial resistance to treat tough respiratory, ENT, and dental bacterial infections.',
      ar: 'أوجمنتين هو مضاد حيوي واسع الطيف وذو ثقة عالية يصفه أطباء الباطنية والأسنان في الأردن. يجمع بين الأموكسيسيلين وحمض الكلافولانيك الذي يثبط إنزيمات البكتيريا المقاومة، مما يجعله فعالاً في القضاء على التهابات الجهاز التنفسي والجيوب الأنفية والمسالك والأسنان.',
    },
    activeIngredients: {
      en: [
        'Amoxicillin trihydrate equivalent to 875 mg amoxicillin',
        'Potassium clavulanate equivalent to 125 mg clavulanic acid (Beta-lactamase inhibitor)',
      ],
      ar: [
        'أموكسيسيلين ثلاثي الهيدرات بما يعادل 875 ملغم أموكسيسيلين',
        'كلافولانات البوتاسيوم بما يعادل 125 ملغم حمض كلافولانيك (مثبط لإنزيم بيتا لاكتاماز)',
      ],
    },
    benefitsAndIndications: {
      en: [
        'Upper and lower respiratory tract infections (bronchitis, pneumonia, acute bacterial sinusitis).',
        'Ear, nose, and throat infections including acute otitis media and tonsillitis.',
        'Dental and periodontal infections, severe alveolar abscesses.',
        'Urinary tract infections (cystitis, pyelonephritis).',
        'Bacterial skin, soft tissue, and post-surgical wound infections.',
      ],
      ar: [
        'التهابات الجهاز التنفسي العلوي والسفلي (التهاب الشعب الهوائية، ذات الرئة، والتهاب الجيوب الأنفية الحاد).',
        'التهابات الأذن والأنف والحنجرة مثل التهاب الأذن الوسطى الحاد والتهاب اللوزتين القيحي.',
        'خراجات الأسنان والتهابات الأنسجة المحيطة بالأسنان بعد العمليات الجراحية.',
        'عدوى المسالك البولية والتناسلية (التهاب المثانة وحوض الكلى).',
        'التهابات الجلد والأنسجة الرخوة والعدوى البكتيرية بعد الجراحة.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Common: Gastrointestinal distress, diarrhea, nausea, loose stools, and cramping.',
        'Oral thrush or vaginal candidiasis due to disruption of intestinal normal flora.',
        'Allergic hypersensitivity: Skin rash or anaphylaxis in penicillin-allergic patients.',
        'Uncommon: Reversible cholestatic jaundice or liver enzyme elevation.',
      ],
      ar: [
        'شائع: اضطرابات في الجهاز الهضمي، إسهال، غثيان، ألم بالمعدة.',
        'ظهور فطريات الفم أو التهابات فطرية بسبب تأثر البكتيريا النافعة.',
        'تحسس جلدي: طفح جلدي، حكة شديدة، وصدمة تحسسية لمن يعانون من حساسية البنسلين.',
        'غير شائع: يرقان انسدادي مؤقت أو ارتفاع عابر في إنزيمات الكبد.',
      ],
    },
    dosageAndUsage: {
      en: 'Take strictly according to physician prescription. Usually 1 tablet (1g) every 12 hours (twice daily) at the start of a meal to enhance absorption and minimize stomach upset. Complete the entire prescribed course.',
      ar: 'يؤخذ حصراً وفقاً لوصفة الطبيب. الجرعة المعتادة للبالغين قرص واحد (1 غرام) كل 12 ساعة (مرتين يومياً) في بداية الوجبة لتقليل اضطرابات الجهاز الهضمي وزيادة الامتصاص. يجب إكمال كورس العلاج كاملاً.',
    },
    warningsAndPrecautions: {
      en: [
        'Contraindicated in individuals with known hypersensitivity to penicillin or cephalosporin antibiotics.',
        'Must not be used for viral infections (common cold or viral flu).',
        'Take with plenty of water and food to protect the stomach.',
      ],
      ar: [
        'ممنوع تماماً لمرضى حساسية البنسلين أو مشتقات السيفالوسبورين.',
        'لا يستخدم لعلاج العدوى الفيروسية مثل نزلات البرد أو الإنفلونزا الموسمية.',
        'ينصح بشرب كميات وافرة من الماء وتناوله مع الطعام لحماية المعدة.',
      ],
    },
    storage: {
      en: 'Store below 25°C in dry conditions inside the original moisture-resistant packaging.',
      ar: 'يحفظ بدرجة حرارة أقل من 25 مئوية داخل شريط التغليف الأصلي المقاوم للرطوبة.',
    },
  },
  {
    id: 'voltaren',
    name: {
      en: 'Voltaren (Retard / Emulgel)',
      ar: 'فولتارين (ريتارد / جل)',
    },
    genericName: {
      en: 'Diclofenac Sodium',
      ar: 'ديكلوفيناك الصوديوم',
    },
    englishPhonetic: '[VOL-tah-ren]',
    englishPronunciationGuide: {
      en: 'Pronounced as: VOL-tah-ren (soft "v", clear "ren")',
      ar: 'يُنطق بالإنجليزية: فول-تَا-رين بوضوح النبرة',
    },
    audioEnglishText: 'Voltaren. Active ingredient: Diclofenac sodium sustained release and topical gel.',
    category: 'painkillers',
    dosageForm: {
      en: 'Sustained-Release Retard Tablets & Emulgel',
      ar: 'أقراص ممتدة المفعول (ريتارد) وجل موضعي',
    },
    strength: '100 mg (Retard) / 50 mg / 1.16% Gel',
    manufacturer: {
      en: 'Novartis / Haleon Consumer Healthcare',
      ar: 'نوفارتس العالمية / هاليون للرعاية الصحية',
    },
    origin: {
      en: 'Switzerland / Supplied in Jordan',
      ar: 'سويسرا / معتمد ومتوفر في مستشفيات وصيدليات الأردن',
    },
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1585435557343-3b092031a831?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-orange-600 to-amber-700',
    approxPriceJOD: '3.20 - 4.10 JOD',
    barcode: '7680398410214',
    jfdaRegistrationNumber: 'JFDA-DRG-01298/JO',
    pregnancyRiskCategory: 'Category C (Do not use in 3rd trimester)',
    maxSafeDailyDose: {
      en: '150 mg maximum daily dose (e.g., 1 tablet of 100mg once daily)',
      ar: '150 ملغم كحد أقصى يومياً (مثلاً قرص واحد 100 ملغم يومياً)',
    },
    description: {
      en: 'Voltaren is the premier non-steroidal anti-inflammatory medication (NSAID) known for treating severe chronic musculoskeletal pain, spinal osteoarthritis, degenerative disk disease, and acute joint inflammation.',
      ar: 'فولتارين هو أحد أشهر مضادات الالتهاب غير الستيرويدية الموثوقة عالمياً ومحلياً. بفضل مفعوله الممتد، يقضي بفعالية على آلام المفاصل والفقرات والديسك، والتهابات العمود الفقري والروماتويد، والتورم المصاحب للإصابات.',
    },
    activeIngredients: {
      en: ['Diclofenac Sodium 100 mg (in sustained-release matrix)', 'Hypromellose, sucrose, magnesium stearate'],
      ar: ['ديكلوفيناك الصوديوم 100 ملغم (في تركيبة ممتدة التحرر)', 'هيبروميلوز، سكروز، ستيرات المغنيسيوم'],
    },
    benefitsAndIndications: {
      en: [
        'Long-lasting 24-hour relief of osteoarthritis and degenerative spine pain.',
        'Rheumatoid arthritis and ankylosing spondylitis.',
        'Post-traumatic swelling, soft tissue sprains, and bursitis.',
        'Severe acute sciatica and lower back nerve compression discomfort.',
      ],
      ar: [
        'تسكين ممتد المفعول على مدار 24 ساعة لخشونة الركبة والتهاب المفاصل.',
        'التهاب المفاصل الروماتويدي والتهاب الفقار اللاصق.',
        'علاج التورم والالتهاب بعد العمليات والالتواءات والأوتار.',
        'تسكين آلام عرق النسا والتهاب أعصاب أسفل الظهر.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Gastrointestinal distress: Heartburn, stomach ache, potential ulceration.',
        'Peripheral fluid retention and mild blood pressure elevation.',
        'Caution in patients with coronary heart disease or prior stroke.',
      ],
      ar: [
        'حموضة المعدة، عسر هضم، وخطر حدوث قرحة عند الاستخدام المزمن.',
        'احتباس السوائل وتورم خفيف في القدمين.',
        'يجب الحذر لمرضى القلب والشرايين والجلطات السابقة.',
      ],
    },
    dosageAndUsage: {
      en: 'Adults: For 100mg Retard tablets, take 1 tablet once daily swallowed whole with water, preferably with evening meals. Never chew or crush.',
      ar: 'للبالغين: قرص واحد من عيار 100 ملغم ممتد المفعول مرة واحدة يومياً مع وجبة العشاء، يُبلع كاملاً مع الماء دون كسر أو مضغ.',
    },
    warningsAndPrecautions: {
      en: [
        'Do not take simultaneously with Cataflam or Profinal.',
        'Strictly contraindicated in patients with active gastrointestinal ulcer or bleeding.',
      ],
      ar: [
        'يمنع تناوله تزامناً مع كاتافلام أو بروفينال لتفادي تراكم مضادات الالتهاب.',
        'ممنوع لمرضى قرحة المعدة أو الاثني عشر النشطة.',
      ],
    },
    storage: {
      en: 'Store below 25°C in a dry environment protected from direct sunlight.',
      ar: 'يحفظ بدرجة حرارة أقل من 25 مئوية في مكان جاف ومحمي من أشعة الشمس.',
    },
  },
  {
    id: 'amoxil',
    name: {
      en: 'Amoxil',
      ar: 'أموكسيل',
    },
    genericName: {
      en: 'Amoxicillin',
      ar: 'أموكسيسيلين',
    },
    englishPhonetic: '[uh-MOK-sil]',
    englishPronunciationGuide: {
      en: 'Pronounced as: uh-MOK-sil (accent on the MOK)',
      ar: 'يُنطق بالإنجليزية: اَ-موك-سِل مع الضغط على المقطع الأوسط',
    },
    audioEnglishText: 'Amoxil. Active ingredient: Amoxicillin five hundred milligrams capsule.',
    category: 'antibiotics',
    dosageForm: {
      en: 'Hard Gelatin Capsules & Oral Dry Powder for Suspension',
      ar: 'كبسولات جيلاتينية صلبة ومعلق جاف للأطفال',
    },
    strength: '500 mg & 250mg per 5ml',
    manufacturer: {
      en: 'GlaxoSmithKline / Licensed & Manufactured by Hikma Jordan',
      ar: 'جلاكسو سميث كلاين / تصنيع وترخيص الحكمة الأردنية',
    },
    origin: {
      en: 'Jordan / United Kingdom',
      ar: 'الأردن / المملكة المتحدة',
    },
    prescriptionRequired: true,
    image: 'https://images.unsplash.com/photo-1577401239170-897942555fb3?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-amber-600 to-red-800',
    approxPriceJOD: '2.40 - 3.10 JOD',
    barcode: '5000347040985',
    jfdaRegistrationNumber: 'JFDA-DRG-00311/JO',
    pregnancyRiskCategory: 'Category B - Generally considered safe in pregnancy under doctor care',
    maxSafeDailyDose: {
      en: '500 mg every 8 hours (1500 mg daily) up to 3g daily in severe infections',
      ar: '500 ملغم كل 8 ساعات (1500 ملغم يومياً) وحتى 3 غرام في العدوى الشديدة',
    },
    description: {
      en: 'Amoxil is a classic broad-spectrum aminopenicillin antibiotic trusted in Jordanian clinical practice for treating ear infections, bacterial chest infections, pharyngitis, and uncomplicated dental abscesses.',
      ar: 'أموكسيل هو أحد أعرق المضادات الحيوية التابعة لعائلة البنسلين في الأردن. يتميز بامتصاصه الهضمي الممتاز وفعاليته في القضاء على بكتيريا الجهاز التنفسي والتهاب الأذن الوسطى واللوزتين وخراجات الأسنان.',
    },
    activeIngredients: {
      en: ['Amoxicillin trihydrate equivalent to 500 mg amoxicillin per capsule', 'Magnesium stearate, gelatin shell'],
      ar: ['أموكسيسيلين ثلاثي الهيدرات بما يعادل 500 ملغم أموكسيسيلين للكبسولة', 'ستيرات المغنيسيوم وغلاف كبسولة جيلاتيني'],
    },
    benefitsAndIndications: {
      en: [
        'Acute otitis media (middle ear infection) and acute bacterial sinusitis.',
        'Streptococcal pharyngitis and bacterial tonsillitis.',
        'Community-acquired pneumonia and acute exacerbations of bronchitis.',
        'Uncomplicated urinary tract bacterial infections (cystitis).',
        'Eradication of Helicobacter pylori in triple-therapy regimens.',
      ],
      ar: [
        'التهاب الأذن الوسطى الحاد والتهاب الجيوب الأنفية البكتيري.',
        'التهاب الحلق واللوزتين البكتيري الناجم عن المكورات العقدية.',
        'التهاب الشعب الهوائية والالتهاب الرئوي المكتسب من المجتمع.',
        'التهابات المسالك البولية البكتيرية غير المعقدة.',
        'جزء أساسي من العلاج الثلاثي للقضاء على جرثومة المعدة (H. Pylori).',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Mild diarrhea, nausea, indigestion, and stomach gassiness.',
        'Allergic reactions: Urticaria, itchy rash, or severe anaphylaxis in penicillin allergy.',
        'Secondary candidiasis (oral or vaginal yeast infection).',
      ],
      ar: [
        'إسهال خفيف، غثيان، عسر هضم بسيط، وغازات.',
        'أعراض حساسية: طفح جلدي، حكة، أو صدمة تحسسية لمن لديهم حساسية البنسلين.',
        'ظهور فطريات خفيفة في الفم أو المناطق الحساسة.',
      ],
    },
    dosageAndUsage: {
      en: 'Adults: 500 mg every 8 hours (3 times daily) or 875 mg every 12 hours. Can be taken with or without food. Ensure drinking adequate fluids.',
      ar: 'للبالغين: كبسولة 500 ملغم كل 8 ساعات (3 مرات يومياً) أو حسب إرشادات الطبيب المعالج. يمكن تناوله قبل أو بعد الوجبات مع كوب ماء كامل.',
    },
    warningsAndPrecautions: {
      en: [
        'Strictly contraindicated in anyone with history of penicillin hypersensitivity.',
        'Do not discontinue prematurely upon feeling better to avoid antibiotic resistance.',
      ],
      ar: [
        'ممنوع نهائياً لمن لديهم حساسية سابقة تجاه البنسلين.',
        'يجب عدم إيقاف الدواء فور الشعور بالتحسن بل إكمال الكورس المقرر لمنع نشوء سلالات بكتيرية مقاومة.',
      ],
    },
    storage: {
      en: 'Store below 25°C in a dry environment. Keep capsules in original blister pack.',
      ar: 'يحفظ في مكان جاف في درجة حرارة دون 25 مئوية داخل شريط التغليف.',
    },
  },
  {
    id: 'zithromax',
    name: {
      en: 'Zithromax / Azimycin',
      ar: 'زيثروماكس / أزيميسين',
    },
    genericName: {
      en: 'Azithromycin',
      ar: 'أزيثرومايسين',
    },
    englishPhonetic: '[ZITH-roh-maks]',
    englishPronunciationGuide: {
      en: 'Pronounced as: ZITH-roh-maks (or az-ee-MY-sin for local brand)',
      ar: 'يُنطق بالإنجليزية: زِث-رُو-ماكس بنطق واضح للثاء',
    },
    audioEnglishText: 'Zithromax Azimycin. Three-day macrolide antibiotic containing Azithromycin five hundred milligrams.',
    category: 'antibiotics',
    dosageForm: {
      en: 'Film-Coated Tablets (3-Day Short Course Pack)',
      ar: 'أقراص مغلفة (عبوة 3 أيام سريعة المفعول)',
    },
    strength: '500 mg (3 tablets pack)',
    manufacturer: {
      en: 'Pfizer / Hikma Pharmaceuticals (Brand: Azimycin)',
      ar: 'فايزر العالمية / الحكمة الأردنية (الاسم التجاري: أزيميسين)',
    },
    origin: {
      en: 'United States / Manufactured locally in Jordan by Hikma',
      ar: 'الولايات المتحدة / ويصنع محلياً في الأردن بواسطة الحكمة',
    },
    prescriptionRequired: true,
    image: 'https://images.unsplash.com/photo-1550572017-ed2300b0e5bc?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-blue-600 to-cyan-800',
    approxPriceJOD: '4.90 - 6.20 JOD',
    barcode: '6251004100789',
    jfdaRegistrationNumber: 'JFDA-DRG-01764/JO',
    pregnancyRiskCategory: 'Category B - Safe alternative for penicillin-allergic pregnant patients under supervision',
    maxSafeDailyDose: {
      en: '500 mg once daily for 3 consecutive days (total course: 1500 mg)',
      ar: '500 ملغم مرة واحدة يومياً لمدة 3 أيام متتالية (إجمالي الكورس: 1500 ملغم)',
    },
    description: {
      en: 'Zithromax (and Jordanian equivalent Azimycin by Hikma) is a high-potency macrolide antibiotic known for its convenient once-daily 3-day dosing schedule. It achieves high intracellular concentrations in respiratory tissues and persists in the body for days to wipe out infections.',
      ar: 'زيثروماكس (ومثيله الأردني الشهير أزيميسين من شركة الحكمة) هو مضاد حيوي واسع المدى من فئة الماكروليد. يتميز بجرعته المريحة: قرص واحد يومياً لمدة 3 أيام فقط، حيث يتغلغل بعمق داخل أنسجة الرئة والجهاز التنفسي ويستمر مفعوله لأيام بعد انتهاء الحبوب.',
    },
    activeIngredients: {
      en: ['Azithromycin dihydrate equivalent to 500 mg azithromycin', 'Pregelatinized starch, anhydrous calcium phosphate, magnesium stearate'],
      ar: ['أزيثرومايسين ثنائي الهيدرات بما يعادل 500 ملغم أزيثرومايسين', 'نشاء مهلمن، فوسفات الكالسيوم اللامائي، ستيرات المغنيسيوم'],
    },
    benefitsAndIndications: {
      en: [
        'Atypical pneumonia and community-acquired lower respiratory tract infections.',
        'Acute bacterial exacerbation of chronic bronchitis and severe sinusitis.',
        'Streptococcal pharyngitis in patients allergic to penicillins.',
        'Bacterial skin and soft tissue infections.',
        'Non-gonococcal urethritis and cervicitis.',
      ],
      ar: [
        'الالتهاب الرئوي اللانمطي والتهابات الجهاز التنفسي السفلي.',
        'التهاب الجيوب الأنفية الحاد وتفاقم التهاب الشعب الهوائية.',
        'التهاب الحلق واللوزتين لمرضى حساسية البنسلين.',
        'التهابات الجلد البكتيرية والأنسجة الرخوة.',
        'علاج التهابات الجهاز التناسلي البكتيرية غير السيلانية.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Abdominal cramps, loose stools, nausea, and vomiting.',
        'Rare: Transient elevation of liver transaminases.',
        'Precaution in patients with known cardiac QT-interval prolongation.',
      ],
      ar: [
        'تقلصات بالمعدة، إسهال أو غثيان بسيط.',
        'نادر: ارتفاع عابر في إنزيمات الكبد.',
        'تحذير لمرضى اضطراب نبضات القلب وتطاول فترة QT.',
      ],
    },
    dosageAndUsage: {
      en: 'Adults: 1 tablet (500 mg) once daily at the same time each day for 3 consecutive days. Can be taken with or without food. Do not skip doses.',
      ar: 'للبالغين: قرص واحد (500 ملغم) مرة واحدة يومياً في نفس الموعد بالضبط لمدة 3 أيام متتالية فقط. يمكن تناوله مع الطعام أو بدونه.',
    },
    warningsAndPrecautions: {
      en: [
        'Do not take with aluminum or magnesium-containing antacids at the same time.',
        'Consult physician if experiencing irregular heart rhythms or history of heart arrhythmias.',
      ],
      ar: [
        'يمنع تناوله تزامناً مع أدوية حموضة المعدة المحتوية على الألمنيوم أو المغنيسيوم في نفس اللحظة.',
        'يجب استشارة الطبيب لمن يعانون من اضطراب في نظم ضربات القلب.',
      ],
    },
    storage: {
      en: 'Store below 30°C in a cool and dry location.',
      ar: 'يحفظ في درجة حرارة دون 30 مئوية في مكان جاف وبارد.',
    },
  },
  {
    id: 'neurobion',
    name: {
      en: 'Neurobion',
      ar: 'نيوروبيون',
    },
    genericName: {
      en: 'Vitamin B1 + B6 + B12 Complex',
      ar: 'فيتامين ب1 + ب6 + ب12 المركب',
    },
    englishPhonetic: '[NOO-roh-by-on]',
    englishPronunciationGuide: {
      en: 'Pronounced as: NOO-roh-by-on (Nerve + bio)',
      ar: 'يُنطق بالإنجليزية: نُيورُو-بَاي-أُون بدقة الحروف',
    },
    audioEnglishText: 'Neurobion. Vitamin B1, B6, and B12 neurotropic complex for nerve health.',
    category: 'vitamins',
    dosageForm: {
      en: 'Coated Tablets & Ampoules for Injection',
      ar: 'أقراص مغلفة وأمبولات للحقن العضلي',
    },
    strength: 'B1 100mg + B6 200mg + B12 200mcg',
    manufacturer: {
      en: 'P&G Health / Merck KGaA',
      ar: 'بروكتر آند جامبل هيلث / ميرك الألمانية',
    },
    origin: {
      en: 'Germany / Distributed widely across Jordan',
      ar: 'ألمانيا / متوفر ومعتمد في الأردن',
    },
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1577401239170-897942555fb3?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-rose-600 to-red-800',
    approxPriceJOD: '3.10 - 4.50 JOD',
    barcode: '4027457000124',
    jfdaRegistrationNumber: 'JFDA-DRG-00542/JO',
    pregnancyRiskCategory: 'Category A/B - Safe for supplemental needs under physician guidance',
    maxSafeDailyDose: {
      en: '1 tablet daily (up to 3 tablets daily for acute nerve crisis under doctor advice)',
      ar: 'قرص واحد يومياً (وحتى 3 أقراص في الحالات الحادة تحت إشراف الطبيب)',
    },
    description: {
      en: 'Neurobion is the gold standard neurotropic B-vitamin formula trusted in Jordan for treating peripheral neuropathy, nerve regeneration, tingling, and chronic numbness in the hands and feet, particularly in diabetic patients.',
      ar: 'نيوروبيون هو التركيبة العلاجية الرائدة لمجموعة فيتامينات ب المقوية للأعصاب في الأردن. يساعد في تغذية وتجديد الألياف العصبية وتخفيف التنميل وخدران الأطراف، خاصة لمرضى السكري وكبار السن.',
    },
    activeIngredients: {
      en: [
        'Vitamin B1 (Thiamine disulfide) 100 mg - energizes nerve cells',
        'Vitamin B6 (Pyridoxine hydrochloride) 200 mg - neurotransmitter synthesis',
        'Vitamin B12 (Cyanocobalamin) 200 mcg - myelin sheath restoration',
      ],
      ar: [
        'فيتامين ب1 (ثيامين) 100 ملغم - يمد الخلايا العصبية بالطاقة الحيوية',
        'فيتامين ب6 (بيريدوكسين) 200 ملغم - يدعم النواقل العصبية',
        'فيتامين ب12 (سيانوكوبالامين) 200 ميكروغرام - يعيد بناء غلاف المايلين الواقي للأعصاب',
      ],
    },
    benefitsAndIndications: {
      en: [
        'Peripheral neuropathy and diabetic nerve pain.',
        'Sensation of numbness, pins and needles, and burning feet.',
        'Sciatica pain, lumbago, and neck/spinal nerve impingement.',
        'Supportive treatment for facial palsy (Bell\'s palsy).',
        'Replenishing vital vitamin B reserves in deficiency states.',
      ],
      ar: [
        'علاج اعتلال الأعصاب المحيطية والتهاب الأعصاب لدى مرضى السكري.',
        'التخلص من الشعور بالتنميل، الوخز، والحرقة في باطن القدمين واليدين.',
        'تخفيف آلام عرق النسا، ألم أسفل الظهر، وضغط فقرات الرقبة على الأعصاب.',
        'علاج داعم لمرضى شلل العصب السابع (شلل الوجه النصفي).',
        'تعويض نقص فيتامينات ب الناتجة عن سوء التغذية أو بعض الأدوية مثل الميتفورمين.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Well tolerated with minimal adverse effects.',
        'Occasionally mild gastrointestinal discomfort or mild sweating.',
        'Chromaturia (harmless reddish tint in urine due to B2/B12 excretion).',
      ],
      ar: [
        'دواء آمن وجيد التحمل مع ندرة الآثار الجانبية.',
        'أحياناً اضطراب خفيف في المعدة أو تعرق بسيط.',
        'تغير غير ضار في لون البول إلى الأصفر الداكن أو الوردي نتيجة طرح الفيتامين الزائد.',
      ],
    },
    dosageAndUsage: {
      en: 'Take 1 tablet daily with or after food, swallowed whole with water. For severe symptoms, physician may recommend up to 3 tablets daily or switching to injectable ampoules.',
      ar: 'تناول قرصاً واحداً يومياً مع الطعام أو بعده مع كمية مناسبة من الماء دون مضغ. في الحالات الشديدة قد يوصي الطبيب بجرعة تصل إلى 3 أقراص يومياً أو استخدام الحقن العضلي.',
    },
    warningsAndPrecautions: {
      en: [
        'Do not exceed recommended doses to prevent peripheral sensory neuropathy with high-dose B6 over very prolonged periods.',
        'Contains lactose; inform your doctor if you have lactose intolerance.',
      ],
      ar: [
        'لا تتجاوز الجرعة المقررة لفترات طويلة جداً دون متابعة طبية.',
        'يحتوي على اللاكتوز، يرجى إخبار الطبيب في حال وجود حساسية سكر الحليب.',
      ],
    },
    storage: {
      en: 'Store below 25°C in a cool and dry location, protected from light.',
      ar: 'يحفظ بدرجة حرارة أقل من 25 مئوية في مكان جاف ومحمي من الضوء.',
    },
  },
  {
    id: 'nexium',
    name: {
      en: 'Nexium',
      ar: 'نيكسيوم',
    },
    genericName: {
      en: 'Esomeprazole Magnesium',
      ar: 'إيزوميبرازول المغنيسيوم',
    },
    englishPhonetic: '[NEK-see-um]',
    englishPronunciationGuide: {
      en: 'Pronounced as: NEK-see-um (Next - ee - um)',
      ar: 'يُنطق بالإنجليزية: نِك-سِي-يُم بنعومة',
    },
    audioEnglishText: 'Nexium. Proton pump inhibitor containing Esomeprazole for GERD and stomach acid.',
    category: 'digestive',
    dosageForm: {
      en: 'Delayed-Release Gastro-Resistant Tablets',
      ar: 'أقراص مقاومة لإفرازات المعدة متأخرة التحرر',
    },
    strength: '20 mg & 40 mg',
    manufacturer: {
      en: 'AstraZeneca / Distributed in Jordan Pharmacies',
      ar: 'أسترازينيكا العالمية / متوفر في صيدليات ومستشفيات الأردن',
    },
    origin: {
      en: 'Sweden / United Kingdom',
      ar: 'السويد / المملكة المتحدة',
    },
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-purple-600 to-indigo-800',
    approxPriceJOD: '6.50 - 11.20 JOD',
    barcode: '7321430005432',
    jfdaRegistrationNumber: 'JFDA-DRG-01980/JO',
    pregnancyRiskCategory: 'Category B - Consult doctor before treatment',
    maxSafeDailyDose: {
      en: '40 mg once daily (or up to 80mg divided in severe Zollinger-Ellison syndrome)',
      ar: '40 ملغم مرة واحدة يومياً على الريق قبل الإفطار',
    },
    description: {
      en: 'Nexium is a proton pump inhibitor (PPI) widely used in Jordan for the rapid and sustained healing of gastroesophageal reflux disease (GERD), acid reflux, heartburn, and stomach ulcers caused by painkillers or H. pylori.',
      ar: 'نيكسيوم هو أحد أفضل وأقوى مثبطات مضخة البروتون (PPI) في الأردن لعلاج حموضة المعدة الشديدة، ارتجاع المريء وحرقة الفؤاد، وقرحة المعدة والاثني عشر، وحماية جدار المعدة عند تناول المسكنات القوية.',
    },
    activeIngredients: {
      en: ['Esomeprazole magnesium trihydrate equivalent to 20 mg (or 40 mg) esomeprazole', 'Glycerol monostearate, hydroxypropyl cellulose, crospovidone'],
      ar: ['إيزوميبرازول المغنيسيوم ثلاثي الهيدرات بما يعادل 20 ملغم (أو 40 ملغم) إيزوميبرازول', 'أحادي ستيرات الجلسرين، هيدروكسي بروبيل سليلوز'],
    },
    benefitsAndIndications: {
      en: [
        'Gastroesophageal reflux disease (GERD) and erosive reflux esophagitis healing.',
        'Immediate relief of acid regurgitation and painful retrosternal heartburn.',
        'Prevention and healing of NSAID-induced gastric ulcers.',
        'Part of combination therapy for Helicobacter pylori eradication.',
      ],
      ar: [
        'علاج مرض الارتجاع المعدي المريئي (GERD) والتهاب المريء التآكلي.',
        'تسكين فوري لحرقة الصدر والحموضة وصعود العصارة الحامضية للحلق.',
        'وقاية وعلاج قرحة المعدة الناتجة عن مسكنات الألم (NSAIDs).',
        'علاج قرحة الاثني عشر والمشاركة في استئصال جرثومة المعدة.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Generally well tolerated; potential mild headache, nausea, diarrhea, or flatulence.',
        'Prolonged use (> 1 year) may decrease magnesium and vitamin B12 absorption.',
      ],
      ar: [
        'جيد التحمل إجمالاً، قد يحدث أحياناً صداع خفيف، إسهال، أو غازات.',
        'الاستخدام المطول جداً لسنوات قد يقلل امتصاص المغنيسيوم وفيتامين ب12.',
      ],
    },
    dosageAndUsage: {
      en: 'Take 1 tablet (20mg or 40mg) once daily in the morning at least 30 to 60 minutes before breakfast with a glass of water. Swallow whole; do not chew or crush the tablet.',
      ar: 'قرص واحد (20 ملغم أو 40 ملغم) مرة واحدة صباحاً قبل الإفطار بنصف ساعة إلى ساعة مع كوب ماء. يجب بلع القرص كاملاً دون مضغ أو تكسير.',
    },
    warningsAndPrecautions: {
      en: [
        'Do not take simultaneously with clopidogrel without consulting your cardiologist.',
        'Inform your doctor if alarming symptoms occur (unintended weight loss, difficulty swallowing, persistent vomiting).',
      ],
      ar: [
        'يجب استشارة طبيب القلب قبل الجمع بينه وبين مميع الدم كلوبيدوجريل (بلافيكس).',
        'أبلغ الطبيب فوراً إذا كان هناك فقدان وزن غير مبرر أو صعوبة في البلع.',
      ],
    },
    storage: {
      en: 'Store below 30°C in the original blister pack to protect from moisture.',
      ar: 'يحفظ بدرجة حرارة أقل من 30 مئوية داخل العبوة الأصلية لحمايته من الرطوبة.',
    },
  },
  {
    id: 'spasmonore',
    name: {
      en: 'Spasmonore / Buscopan',
      ar: 'سباسمونور / بسكوبان',
    },
    genericName: {
      en: 'Hyoscine Butylbromide',
      ar: 'هيوسين بيوتيل بروميد',
    },
    englishPhonetic: '[SPAZ-moh-nor]',
    englishPronunciationGuide: {
      en: 'Pronounced as: SPAZ-moh-nor (rhymes with spasm - oh - nor)',
      ar: 'يُنطق بالإنجليزية: سْبَاز-مُو-نُور بنعومة',
    },
    audioEnglishText: 'Spasmonore Buscopan. Antispasmodic containing Hyoscine butylbromide ten milligrams.',
    category: 'digestive',
    dosageForm: {
      en: 'Sugar-Coated Tablets & Ampoules',
      ar: 'أقراص مغلفة بالسكر وأمبولات للحقن',
    },
    strength: '10 mg',
    manufacturer: {
      en: 'Hikma Pharmaceuticals (Spasmonore) / Sanofi (Buscopan)',
      ar: 'شركة أدوية الحكمة الأردنية (سباسمونور) / سانوفي (بسكوبان)',
    },
    origin: {
      en: 'Jordan (Hikma Amman) / France',
      ar: 'الأردن (الحكمة - عمّان) / فرنسا',
    },
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-emerald-600 to-teal-800',
    approxPriceJOD: '1.30 - 2.10 JOD',
    barcode: '6251004100654',
    jfdaRegistrationNumber: 'JFDA-DRG-00621/JO',
    pregnancyRiskCategory: 'Category C - Use with caution under medical supervision',
    maxSafeDailyDose: {
      en: 'Up to 2 tablets (20 mg) four times daily (max 80 mg daily)',
      ar: 'قرص إلى قرصين حتى 4 مرات يومياً (بحد أقصى 80 ملغم باليوم)',
    },
    description: {
      en: 'Spasmonore (manufactured locally by Hikma) and Buscopan are targeted antispasmodics that relax the smooth muscles of the digestive tract, biliary system, and urinary system. Highly popular in Jordan for irritable bowel syndrome (IBS) cramps and renal colic.',
      ar: 'سباسمونور (المنتج الأردني من الحكمة) وبسكوبان هو مضاد تقلصات نوعي يعمل مباشرة على إرخاء العضلات الملساء في المعدة والأمعاء والمسالك البولية والمرارة. الدواء المفضل في الأردن لمغص القولون العصبي، المغص الكلوي وآلام الطمث.',
    },
    activeIngredients: {
      en: ['Hyoscine Butylbromide 10 mg per tablet', 'Calcium hydrogen phosphate, maize starch, soluble starch, colloidal silica'],
      ar: ['هيوسين بيوتيل بروميد 10 ملغم لكل قرص', 'فوسفات هيدروجين الكالسيوم، نشاء الذرة، سيليكا غروية'],
    },
    benefitsAndIndications: {
      en: [
        'Fast relief of painful abdominal spasms, colic, and cramps in Irritable Bowel Syndrome (IBS).',
        'Biliary colic and gallbladder spasms.',
        'Renal and ureteral spasms associated with kidney gravel/stones.',
        'Spasmodic dysmenorrhea (painful period cramping).',
      ],
      ar: [
        'تسكين سريع لتقلصات ومغص البطن المصاحب للقولون العصبي (IBS).',
        'علاج المغص المراري وتقلصات القنوات الصفراوية.',
        'المغص الكلوي وحصوات وتشنجات الحالب والمسالك البولية.',
        'علاج تقلصات وتشنجات الدورة الشهرية المؤلمة.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Dry mouth, reduced sweating, or mild constipation.',
        'Temporary visual accommodation disturbance in sensitive patients.',
        'Contraindicated in narrow-angle glaucoma or prostate enlargement with urinary retention.',
      ],
      ar: [
        'جفاف خفيف في الفم، قلة التعرق، أو إمساك بسيط.',
        'زغللة مؤقتة في الرؤية للأشخاص شديدي الحساسية.',
        'ممنوع لمرضى الجلوكوما (المياه الزرقاء) أو تضخم البروستاتا مع احتباس البول.',
      ],
    },
    dosageAndUsage: {
      en: 'Adults: 1 to 2 tablets (10 mg - 20 mg) 3 to 4 times daily swallowed with water as needed. Do not exceed 80 mg per day.',
      ar: 'للبالغين: قرص إلى قرصين (10 - 20 ملغم) 3 إلى 4 مرات يومياً مع كوب ماء عند الشعور بالمغص. لا تتجاوز 8 أقراص يومياً.',
    },
    warningsAndPrecautions: {
      en: [
        'Consult physician if severe abdominal pain persists or is accompanied by high fever or rectal bleeding.',
        'Caution in tachycardia or cardiac arrhythmias.',
      ],
      ar: [
        'استشر الطبيب إذا استمر المغص الحاد أو كان مصحوباً بحرارة عالية أو قيء متكرر.',
        'يحذر لمرضى تسارع نبضات القلب الحاد.',
      ],
    },
    storage: {
      en: 'Store below 25°C in a dry place away from heat.',
      ar: 'يحفظ بدرجة حرارة دون 25 مئوية في مكان جاف.',
    },
  },
  {
    id: 'otrivin',
    name: {
      en: 'Otrivin',
      ar: 'أوتريفين',
    },
    genericName: {
      en: 'Xylometazoline Hydrochloride',
      ar: 'زايلوميتازولين هيدروكلوريد',
    },
    englishPhonetic: '[OH-trih-vin]',
    englishPronunciationGuide: {
      en: 'Pronounced as: OH-trih-vin (stress on OH)',
      ar: 'يُنطق بالإنجليزية: أُو-تري-فِن بوضوح الحروف',
    },
    audioEnglishText: 'Otrivin. Fast acting nasal decongestant spray containing Xylometazoline zero point one percent.',
    category: 'cold_flu',
    dosageForm: {
      en: 'Metered-Dose Nasal Spray & Drops',
      ar: 'بخاخ أنفي مدروس الجرعات ونقاط للأنف',
    },
    strength: '0.1% (Adults) / 0.05% (Pediatric)',
    manufacturer: {
      en: 'Haleon / GSK Consumer Healthcare',
      ar: 'هاليون / جلاكسو سميث كلاين للرعاية الصحية',
    },
    origin: {
      en: 'Switzerland / Distributed in Jordan',
      ar: 'سويسرا / متوفر في صيدليات المملكة',
    },
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-cyan-600 to-blue-700',
    approxPriceJOD: '2.10 - 2.80 JOD',
    barcode: '7611600001092',
    jfdaRegistrationNumber: 'JFDA-DRG-00431/JO',
    pregnancyRiskCategory: 'Category C - Use saline spray instead during pregnancy if possible',
    maxSafeDailyDose: {
      en: '1 spray in each nostril up to 3 times daily; MAX 5 to 7 consecutive days only',
      ar: 'بخة واحدة في كل فتحة أنف حتى 3 مرات يومياً، ولمدة أقصاها 5 إلى 7 أيام متتالية فقط',
    },
    description: {
      en: 'Otrivin is a fast-acting topical nasal decongestant that constricts dilated nasal blood vessels within 2 to 5 minutes, clearing congested sinuses and obstructed breathing for up to 10-12 hours.',
      ar: 'أوتريفين هو بخاخ الأنف السريع والأوسع انتشاراً في الأردن لفتح انسداد الجيوب الأنفية والرشح. يعمل خلال دقيقتين إلى خمس دقائق على تضييق الأوعية الدموية المحتقنة، مما يتيح تنفساً حراً ومريحاً يدوم حتى 12 ساعة.',
    },
    activeIngredients: {
      en: ['Xylometazoline Hydrochloride 1 mg/ml (0.1%)', 'Sodium chloride, disodium phosphate, benzalkonium chloride'],
      ar: ['زايلوميتازولين هيدروكلوريد 1 ملغم/مل (0.1%)', 'كلوريد الصوديوم، فوسفات ثنائي الصوديوم، بنزالكونيوم كلوريد'],
    },
    benefitsAndIndications: {
      en: [
        'Immediate opening of blocked nasal passages in viral colds and flu.',
        'Relief of sinus pressure and congestion in acute bacterial or viral sinusitis.',
        'Facilitating drainage of nasal secretions in ear infections (otitis media).',
      ],
      ar: [
        'فتح فوري لمجرى التنفس وانسداد الأنف في نزلات البرد والإنفلونزا.',
        'تخفيف ضغط واحتقان الجيوب الأنفية الحاد.',
        'تسهيل تصريف الإفرازات في حالات التهاب الأذن الوسطى.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Local transient burning, stinging, or dryness of the nasal mucosa.',
        'Critical: Rebound congestion (Rhinitis Medicamentosa) if used for more than 7 days.',
      ],
      ar: [
        'حرقان موضعي عابر أو جفاف في بطانة الأنف.',
        'تحذير هام: الإفراط في استخدامه لأكثر من 5-7 أيام يسبب احتقاناً ارتدادياً مزمناً (إدمان البخاخ).',
      ],
    },
    dosageAndUsage: {
      en: 'Adults: 1 spray into each nostril 2 to 3 times daily as needed. Blow nose gently before application. Strictly avoid exceeding 7 consecutive days of usage.',
      ar: 'للبالغين: بخة واحدة في كل فتحة أنف 2 إلى 3 مرات يومياً عند الحاجة. يُنظف الأنف برفق قبل الرش. يمنع منعاً باتاً استخدامه لأكثر من 5 إلى 7 أيام متتالية لتفادي اعتياد الأنف.',
    },
    warningsAndPrecautions: {
      en: [
        'Do not use continuously for more than 5-7 days.',
        'Caution in patients with hypertension, hyperthyroidism, or narrow-angle glaucoma.',
      ],
      ar: [
        'لا تستخدمه أبداً لأكثر من 7 أيام متتالية لتجنب تلف بطانة الأنف.',
        'يجب الحذر لمرضى الضغط المرتفع ونشاط الغدة الدرقية.',
      ],
    },
    storage: {
      en: 'Store below 30°C. Keep bottle upright and do not share with others to prevent infection.',
      ar: 'يحفظ بدرجة حرارة دون 30 مئوية. لا تشارك العبوة مع شخص آخر منعاً لنقل العدوى.',
    },
  },
  {
    id: 'concor',
    name: {
      en: 'Concor',
      ar: 'كونكور',
    },
    genericName: {
      en: 'Bisoprolol Fumarate',
      ar: 'بيسوبرولول فيومارات',
    },
    englishPhonetic: '[KON-kor]',
    englishPronunciationGuide: {
      en: 'Pronounced as: KON-kor (Clear hard K and O)',
      ar: 'يُنطق بالإنجليزية: كُون-كُور بنبرة قوية',
    },
    audioEnglishText: 'Concor. Selective beta-blocker containing Bisoprolol fumarate five milligrams for blood pressure and heart rate.',
    category: 'chronic',
    dosageForm: {
      en: 'Heart-Shaped Film-Coated Tablets',
      ar: 'أقراص مغلفة بشكل قلب مميز',
    },
    strength: '2.5 mg & 5 mg & 10 mg',
    manufacturer: {
      en: 'Merck KGaA Germany / Distributed across Jordan',
      ar: 'ميرك الألمانية / متوفر في صيدليات ومراكز القلب بالأردن',
    },
    origin: {
      en: 'Germany / Registered with JFDA',
      ar: 'ألمانيا / مسجل ومعتمد رسمياً في الأردن',
    },
    prescriptionRequired: true,
    image: 'https://images.unsplash.com/photo-1550572017-ed2300b0e5bc?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-amber-600 to-orange-700',
    approxPriceJOD: '4.20 - 6.80 JOD',
    barcode: '4027457002341',
    jfdaRegistrationNumber: 'JFDA-DRG-01511/JO',
    pregnancyRiskCategory: 'Category C - Use only under strict cardiologist instruction',
    maxSafeDailyDose: {
      en: 'Usually 5 mg to 10 mg once daily (max 20 mg daily under medical supervision)',
      ar: 'عادة 5 ملغم إلى 10 ملغم مرة واحدة يومياً حسب وصفة طبيب القلب',
    },
    description: {
      en: 'Concor is a selective beta-1 adrenergic blocker widely prescribed by Jordanian cardiologists. It gently slows the resting heart rate, decreases myocardial oxygen demand, and reliably normalizes elevated arterial blood pressure.',
      ar: 'كونكور هو دواء منظم لضربات القلب وخافض لضغط الدم المرتفع من فئة حاصرات بيتا-1 الانتقائية. يصفه أطباء القلب في الأردن لتهدئة خفقان وتسارع القلب، تقليل المجهود على عضلة القلب، والوقاية من الجلطات والذبحة الصدرية.',
    },
    activeIngredients: {
      en: ['Bisoprolol Fumarate 5 mg (or 2.5 mg) per heart-shaped scored tablet', 'Colloidal anhydrous silica, magnesium stearate, crospovidone, microcrystalline cellulose'],
      ar: ['بيسوبرولول فيومارات 5 ملغم (أو 2.5 ملغم) لكل قرص قلب مقسوم', 'سيليكا غروية لامائية، ستيرات المغنيسيوم، كروسبوفيدون'],
    },
    benefitsAndIndications: {
      en: [
        'Management of essential arterial hypertension (high blood pressure).',
        'Treatment of chronic stable angina pectoris (chest pain).',
        'Controlling resting sinus tachycardia and uncomfortable heart palpitations.',
        'Adjunctive therapy in stable chronic heart failure with reduced ejection fraction.',
      ],
      ar: [
        'علاج ومراقبة ضغط الدم الشرياني المرتفع.',
        'علاج الذبحة الصدرية المستقرة وآلام نقص تروية القلب.',
        'تنظيم ضربات القلب وعلاج الخفقان وتسارع النبض في الراحة أو مع القلق.',
        'علاج داعم لقصور وضعف عضلة القلب المزمن.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Bradycardia (unusually slow heart rate) and dizziness when standing up suddenly.',
        'Feeling of coldness or numbness in extremities (hands and feet).',
        'Fatigue, sleep disturbances, or mild lightheadedness.',
      ],
      ar: [
        'تباطؤ ملحوظ في نبضات القلب وشعور بالدوخة عند الوقوف المفاجئ.',
        'برودة أو تنميل في أصابع اليدين والقدمين.',
        'إرهاق وشعور بالخمول أو اضطراب بسيط في النوم.',
      ],
    },
    dosageAndUsage: {
      en: 'Take strictly as prescribed by your physician. Usually 1 tablet (2.5 mg or 5 mg) once daily in the morning with or without food. Swallow with water at the same time each day. Never discontinue abruptly.',
      ar: 'يؤخذ حصراً وفقاً لوصفة الطبيب المعالج. الجرعة المعتادة قرص واحد (2.5 أو 5 ملغم) مرة واحدة صباحاً مع كوب ماء. لا توقف الدواء فجأة أبداً منعاً لارتفاع الضغط الارتدادي.',
    },
    warningsAndPrecautions: {
      en: [
        'Never stop taking Concor abruptly without consulting your cardiologist to prevent dangerous rebound hypertension.',
        'Contraindicated in severe bronchial asthma, severe bradycardia, or cardiogenic shock.',
      ],
      ar: [
        'يمنع إيقاف الدواء فجأة دون استشارة الطبيب لتفادي الارتفاع المفاجئ في الضغط أو تسارع القلب.',
        'ممنوع لمرضى الربو القصبي الشديد أو تباطؤ القلب الشديد.',
      ],
    },
    storage: {
      en: 'Store below 25°C in a dry location protected from heat and moisture.',
      ar: 'يحفظ في درجة حرارة أقل من 25 مئوية بعيداً عن الحرارة والرطوبة.',
    },
  },
  {
    id: 'glucophage',
    name: {
      en: 'Glucophage',
      ar: 'جلوكوفاج',
    },
    genericName: {
      en: 'Metformin Hydrochloride',
      ar: 'ميتفورمين هيدروكلوريد',
    },
    englishPhonetic: '[GLOO-ko-fazh]',
    englishPronunciationGuide: {
      en: 'Pronounced as: GLOO-ko-fazh (soft french-style "zh" at the end)',
      ar: 'يُنطق بالإنجليزية: جلُو-كُو-فَاج بنطق الجيم المعطشة',
    },
    audioEnglishText: 'Glucophage. First-line oral antidiabetic medicine containing Metformin hydrochloride.',
    category: 'chronic',
    dosageForm: {
      en: 'Film-Coated Tablets & XR (Extended Release)',
      ar: 'أقراص مغلفة وأقراص ممتدة المفعول (XR)',
    },
    strength: '500 mg & 850 mg & 1000 mg',
    manufacturer: {
      en: 'Merck Santé / Distributed in Jordan Pharmacies & Royal Medical Services',
      ar: 'ميرك العالمية / متوفر بصيدليات المملكة والخدمات الطبية الملكية',
    },
    origin: {
      en: 'France / Distributed Internationally',
      ar: 'فرنسا / معتمد ومتوفر في جميع قطاعات الصحة بالأردن',
    },
    prescriptionRequired: true,
    image: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-blue-700 to-slate-800',
    approxPriceJOD: '2.80 - 4.50 JOD',
    barcode: '3400933758921',
    jfdaRegistrationNumber: 'JFDA-DRG-00214/JO',
    pregnancyRiskCategory: 'Category B - Frequently prescribed under endocrinologist guidance for gestational diabetes & PCOS',
    maxSafeDailyDose: {
      en: 'Up to 2,000 mg to 2,550 mg daily divided with meals as prescribed',
      ar: 'من 2000 ملغم إلى 2550 ملغم كحد أقصى مقسمة مع الوجبات حسب وصفة الطبيب',
    },
    description: {
      en: 'Glucophage is the undisputed first-line oral medication for type-2 diabetes mellitus in Jordan and worldwide. It decreases hepatic glucose production, enhances peripheral insulin sensitivity, and aids in body weight management without causing hypoglycemia.',
      ar: 'جلوكوفاج هو حجر الأساس الأول المعتمد في الأردن والعالم لعلاج مرض السكري من النوع الثاني وتنظيم السكر التراكمي (HbA1c). يقلل تصنيع السكر في الكبد، ويزيد حساسية خلايا الجسم للأنسولين، ويساعد في إنقاص الوزن وعلاج تكيس المبايض دون التسبب في هبوط مفاجئ للسكر.',
    },
    activeIngredients: {
      en: ['Metformin Hydrochloride 500 mg, 850 mg, or 1000 mg', 'Povidone, magnesium stearate, hypromellose'],
      ar: ['ميتفورمين هيدروكلوريد 500 ملغم، 850 ملغم، أو 1000 ملغم', 'بوفيدون، ستيرات المغنيسيوم، هيبروميلوز'],
    },
    benefitsAndIndications: {
      en: [
        'First-line treatment of Type 2 Diabetes Mellitus in adults and overweight patients.',
        'Lowering glycated hemoglobin (HbA1c) and fasting blood glucose.',
        'Polycystic Ovary Syndrome (PCOS) management to restore ovulatory function.',
        'Does not induce clinical hypoglycemia when used alone.',
      ],
      ar: [
        'العلاج الأول المفضل لمرضى السكري من النوع الثاني وخاصة مع زيادة الوزن.',
        'تخفيض السكر التراكمي (HbA1c) وضبط قراءات السكر الصباحي.',
        'علاج متلازمة تكيس المبايض (PCOS) وتنظيم الإباضة لدى السيدات.',
        'لا يسبب هبوطاً خطيراً في السكر عند استخدامه بمفرده.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Gastrointestinal symptoms in early weeks: Diarrhea, bloating, metallic taste, nausea.',
        'Long-term therapy may reduce vitamin B12 absorption (periodic monitoring advised).',
        'Rare but serious: Lactic acidosis in severe renal or hepatic failure.',
      ],
      ar: [
        'اضطراب الجهاز الهضمي في الأسابيع الأولى: إسهال، انتفاخ، طعم معدني بالفم، وغثيان.',
        'الاستخدام الطويل قد يقلل امتصاص فيتامين ب12 (ينصح بفحصه دورياً).',
        'نادر وخطير: الحماض اللبني (Lactic Acidosis) عند مرضى الفشل الكلوي المتقدم.',
      ],
    },
    dosageAndUsage: {
      en: 'Take strictly according to physician advice. Always take during or immediately after meals with plenty of water to minimize stomach upset. Start with low doses and titrate gradually.',
      ar: 'يؤخذ وفقاً لإرشادات الطبيب. يجب دائماً تناوله أثناء الوجبة أو بعدها مباشرة مع كمية وافرة من الماء لتفادي اضطرابات المعدة. يتم التدرج بالجرعة تدريجياً.',
    },
    warningsAndPrecautions: {
      en: [
        'Must be paused 48 hours prior to radiocontrast imaging procedures.',
        'Contraindicated in patients with severe renal impairment (eGFR < 30 ml/min).',
      ],
      ar: [
        'يجب إيقافه قبل 48 ساعة من إجراء الفحوصات الطبية الملونة بالأشعة (الصبغة الوريدية).',
        'ممنوع لمرضى القصور الكلوي الشديد.',
      ],
    },
    storage: {
      en: 'Store below 25°C away from heat and moisture.',
      ar: 'يحفظ بدرجة حرارة دون 25 مئوية بعيداً عن الرطوبة.',
    },
  },
  {
    id: 'cecon-vitaminc',
    name: {
      en: 'C-Vit 1000mg Effervescent',
      ar: 'سي-فيت 1000 ملغم فوار',
    },
    genericName: {
      en: 'Ascorbic Acid (Vitamin C)',
      ar: 'حمض الأسكوربيك (فيتامين ج)',
    },
    englishPhonetic: '[SEE-vit]',
    englishPronunciationGuide: {
      en: 'Pronounced as: SEE-vit (rhymes with see - fit)',
      ar: 'يُنطق بالإنجليزية: سِي-فِت بخفة ونقاء',
    },
    audioEnglishText: 'C-Vit Effervescent. Vitamin C Ascorbic Acid one thousand milligrams orange flavour.',
    category: 'vitamins',
    dosageForm: {
      en: 'Effervescent Tablets (Orange Flavour)',
      ar: 'أقراص فوارة بنكهة البرتقال المنعشة',
    },
    strength: '1000 mg',
    manufacturer: {
      en: 'Dar Al Dawa Pharma / Jordan',
      ar: 'دار الدواء للتنمية والاستثمار / الأردن',
    },
    origin: {
      en: 'Jordan (Na\'ur / Amman)',
      ar: 'الأردن (ناعور / عمّان)',
    },
    prescriptionRequired: false,
    image: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?auto=format&fit=crop&w=800&q=80',
    fallbackColor: 'from-orange-500 to-amber-600',
    approxPriceJOD: '2.20 - 2.80 JOD',
    barcode: '6251001004121',
    jfdaRegistrationNumber: 'JFDA-DRG-00192/JO',
    pregnancyRiskCategory: 'Category C - Safe within recommended dietary allowances',
    maxSafeDailyDose: {
      en: '1 effervescent tablet (1000 mg) once daily (upper safe daily intake is 2000mg)',
      ar: 'قرص فوار واحد (1000 ملغم) مرة واحدة يومياً',
    },
    description: {
      en: 'C-Vit is a locally manufactured Jordanian effervescent vitamin C tablet that dissolves instantly in cold water. Formulated by Dar Al Dawa, it provides potent antioxidant defense, stimulates collagen synthesis, and boosts white blood cell defense against winter infections.',
      ar: 'سي-فيت هو مكمل فيتامين سي فوار مصنع محلياً في الأردن من شركة دار الدواء العريقة. يذوب بسرعة في الماء ليعطي مشروباً منعشاً بنكهة البرتقال، يمد الجسم بمضادات أكسدة قوية تدعم المناعة وتحفز إنتاج الكولاجين للوقاية من نزلات البرد.',
    },
    activeIngredients: {
      en: ['Ascorbic Acid (Vitamin C) 1000 mg', 'Sodium bicarbonate, citric acid, natural orange flavour'],
      ar: ['حمض الأسكوربيك (فيتامين سي) بتركيز 1000 ملغم', 'بيكربونات الصوديوم، حمض الستريك، ونكهة البرتقال الطبيعية'],
    },
    benefitsAndIndications: {
      en: [
        'Strengthens the immune response against viruses and seasonal colds.',
        'Accelerates wound healing and post-operative tissue repair.',
        'Powerful antioxidant that neutralizes cellular free radicals.',
        'Significantly enhances non-heme iron absorption from the digestive tract.',
        'Vital cofactor for skin collagen formation and vascular integrity.',
      ],
      ar: [
        'تقوية الجهاز المناعي ومقاومة نزلات البرد والإنفلونزا الموسمية.',
        'تسريع التئام الجروح وتجديد الأنسجة بعد العمليات أو الإصابات.',
        'مضاد أكسدة فائق الفعالية لحماية خلايا الجسم من الجذور الحرة.',
        'تعزيز امتصاص عنصر الحديد من الطعام لعلاج فقر الدم.',
        'ضروري لتصنيع الكولاجين الطبيعي لنضارة البشرة وصحة الأوعية الدموية.',
      ],
    },
    sideEffectsAndComplications: {
      en: [
        'Generally very safe when consumed with sufficient hydration.',
        'High doses may occasionally cause mild osmotic diarrhea or stomach cramps.',
        'Daily consumption (>2000mg) may increase risk of calcium oxalate kidney stones in predisposed individuals.',
      ],
      ar: [
        'آمن جداً عند شربه مع كمية كافية من الماء.',
        'الجرعات العالية قد تسبب إسهالاً خفيفاً أو تقلصات بالمعدة.',
        'الاستهلاك المفرط طويل الأمد قد يزيد احتمال تكون حصوات الكلى من نوع أوكسالات الكالسيوم لدى المعرضين لذلك.',
      ],
    },
    dosageAndUsage: {
      en: 'Dissolve 1 effervescent tablet completely in half a glass of cold water (approx 150-200 ml) and drink immediately once daily, preferably in the morning.',
      ar: 'يُذاب قرص فوار واحد تماماً في نصف كوب ماء بارد (حوالي 150-200 مل) ويُشرب فوراً مرة واحدة يومياً، ويفضل صباحاً.',
    },
    warningsAndPrecautions: {
      en: [
        'Patients on a strictly salt-restricted diet should note the sodium bicarbonate content.',
        'Individuals with history of recurrent kidney stones should consult their doctor.',
      ],
      ar: [
        'يجب على مرضى الضغط الذين يتبعون حمية قليلة الصوديوم الانتباه لمحتوى الصوديوم في الفوار.',
        'يجب استشارة الطبيب لمن لديهم تاريخ مع حصوات الكلى المتكررة.',
      ],
    },
    storage: {
      en: 'Keep tube tightly closed in a dry place below 25°C to protect from ambient moisture.',
      ar: 'يجب إغلاق العبوة بإحكام بعد كل استخدام وحفظها في مكان جاف دون 25 مئوية لحمايتها من الرطوبة.',
    },
  },
];

// Merge flagship detailed medicines with the full OTC catalog (over 1,000 OTC items)
const fullOTCDirectory = generateFullOTCDirectory();
const existingIds = new Set(FLAGSHIP_MEDICINES.map((m) => m.id.toLowerCase()));
const nonDuplicateOTC = fullOTCDirectory.filter((m) => !existingIds.has(m.id.toLowerCase()));

export const MEDICINES_DATA: Medicine[] = [...FLAGSHIP_MEDICINES, ...nonDuplicateOTC];

