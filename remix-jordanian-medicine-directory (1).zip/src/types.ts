export type Language = 'ar' | 'en';

export type CategoryKey =
  | 'all'
  | 'painkillers'
  | 'antibiotics'
  | 'vitamins'
  | 'chronic'
  | 'cold_flu'
  | 'digestive';

export interface LocalizedString {
  en: string;
  ar: string;
}

export interface LocalizedStringArray {
  en: string[];
  ar: string[];
}

export interface Medicine {
  id: string;
  name: LocalizedString;
  genericName: LocalizedString;
  category: 'painkillers' | 'antibiotics' | 'vitamins' | 'chronic' | 'cold_flu' | 'digestive';
  dosageForm: LocalizedString;
  strength: string;
  manufacturer: LocalizedString;
  origin: LocalizedString;
  prescriptionRequired: boolean;
  image: string;
  fallbackColor: string;
  description: LocalizedString;
  activeIngredients: LocalizedStringArray;
  benefitsAndIndications: LocalizedStringArray;
  sideEffectsAndComplications: LocalizedStringArray;
  dosageAndUsage: LocalizedString;
  warningsAndPrecautions: LocalizedStringArray;
  storage: LocalizedString;
  barcode?: string;
  approxPriceJOD?: string;
  // Literal English phonetic pronunciation & safety details
  englishPhonetic: string;
  englishPronunciationGuide?: LocalizedString;
  audioEnglishText?: string;
  maxSafeDailyDose?: LocalizedString;
  pregnancyRiskCategory?: string;
  jfdaRegistrationNumber?: string;
}
